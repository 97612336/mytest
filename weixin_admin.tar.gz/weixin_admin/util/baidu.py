#!/usr/bin/python
# coding=utf-8

import yaml
try:
    import httplib
except ImportError:
    import http.client as httplib
from tornado.httputil import urlencode
from math import radians, cos, sin, asin, sqrt

ak = '36ae05190aee1247a0eafb4cb06fa43b'


def ip2location(ip, coor='bd09ll'):
    headers = {
        "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        "Accept": "*/*",
    }
    params = {
        'ip': ip,
        'ak': ak,
        'coor': coor,
    }
    data = urlencode(params)
    host = 'api.map.baidu.com'
    url = '/location/ip'
    try:
        conn = httplib.HTTPSConnection(host)
        conn.request('POST', url, data, headers)
        response = conn.getresponse()
        data = response.read()
        res = yaml.load(data)
        conn.close()
        return res
    except BaseException:
        pass
    return None


def geo2location(location, coor='wgs84ll'):
    headers = {
        "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        "Accept": "*/*",
    }
    params = {
        'location': location,
        'ak': ak,
        'coordtype': coor,
        'output': 'json',
    }
    data = urlencode(params)
    host = 'api.map.baidu.com'
    url = '/geocoder/v2/'
    try:
        conn = httplib.HTTPSConnection(host)
        conn.request('POST', url, data, headers)
        response = conn.getresponse()
        data = response.read()
        res = yaml.load(data)
        conn.close()
        return res
    except BaseException:
        pass
    return None


def haversine(lon1, lat1, lon2, lat2):
    lon1, lat1, lon2, lat2 = map(radians, [lon1, lat1, lon2, lat2])
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = sin(dlat / 2)**2 + cos(lat1) * cos(lat2) * sin(dlon / 2)**2
    c = 2 * asin(sqrt(a))
    r = 6371
    return c * r * 1000


if __name__ == "__main__":
    print(haversine(116.319181, 39.976446, 116.454286, 39.935297))
