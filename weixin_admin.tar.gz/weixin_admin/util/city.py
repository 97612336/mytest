#!/usr/bin/python
# coding=utf-8

import sys
import time
import datetime
import os
import logging
import random


def random_city():
    with open('../conf/city.txt', 'r') as f:
        data = f.readlines()
        for line in data:
            words = line.split("：、")
            print(words)


def random_city_name():
    return random.choice(['北京', '上海', '广州', '深圳', '天津', '重庆'])


if __name__ == "__main__":
    random_city()
