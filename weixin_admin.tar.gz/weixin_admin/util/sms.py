# coding=utf-8

import sys
import time
import datetime
import os
import logging
import random
import top.api
import json

appkey = '23494034'
appsecret = '46849bc8398425c7942f5c5131ae5278'


def request_dayu(req):
    """ example return from alidayu
    {
      "alibaba_aliqin_fc_sms_num_send_response": {
        "result":{
          "err_code":"0",
          "model":"104295191956^1105831459670",
          "success":true
        },
        "request_id":"3gtr3v7l2o3f"
      }
    }
    """
    try:
        resp = req.getResponse()
        logging.debug("alidayu %s", resp)
        return resp.get('alibaba_aliqin_fc_sms_num_send_response', {}).\
            get('result', {}).\
            get('success', False)
    except Exception as e:
        logging.error("alidayu error %s", e)
        return False


def request_af_login_verifycode(phone, params):
    req = top.api.AlibabaAliqinFcSmsNumSendRequest()
    req.set_app_info(top.appinfo(appkey, appsecret))

    req.extend = ""
    req.sms_type = "normal"
    req.sms_free_sign_name = "车势科技"
    req.sms_param = json.dumps(params)
    req.rec_num = phone
    req.sms_template_code = "SMS_40810142"

    return request_dayu(req)


def request_changan_coupon(phone, params):
    for k in ('order_id', 'order_info', 'order_place',):
        if k not in params:
            return False
    req = top.api.AlibabaAliqinFcSmsNumSendRequest()
    req.set_app_info(top.appinfo(appkey, appsecret))

    req.extend = ""
    req.sms_type = "normal"
    req.sms_free_sign_name = "车势科技"
    req.sms_param = json.dumps(params)
    req.rec_num = phone
    req.sms_template_code = "SMS_61405052"

    return request_dayu(req)
