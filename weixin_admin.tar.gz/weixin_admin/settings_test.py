# coding=utf-8

from __future__ import absolute_import, print_function
import os
import datetime
import tornado.options
from tornado.options import define, options

define("debug", default=False, help="debug", group='app')
define("static_path", default="", help="web static path", group='app')
define("template_path", default="", help="template path", group='app')
define("xsrf_cookies", default=True, help="xsrf_cookies", group='app')

define("mysql_uri",
       default="mysql+pymysql://root@localhost/test?charset=utf8mb4")

tornado.options.parse_command_line(final=False)

settings = options.group_dict('app')
if not settings['static_path']:
    settings['static_path'] = os.path.join(os.path.dirname(__file__), "static")
if not settings['template_path']:
    settings['template_path'] = os.path.join(
        os.path.dirname(__file__), "templates")
if not settings.get('upload_path', ''):
    settings['upload_path'] = "upload"
