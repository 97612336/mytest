from __future__ import absolute_import, print_function
from app import Application
from settings_test import settings
from tornado.testing import AsyncHTTPTestCase
from tornado.httputil import url_concat
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm import scoped_session
from apis.models import Models
from apis import Base
from torndsession.session import SessionManager


orig_session_get = SessionManager.get


def dbSetUp():
    app = Application(**settings)
    engine = app._engine
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)


def dbTearDown():
    app = Application(**settings)
    engine = app._engine
    Base.metadata.drop_all(engine)


class BaseTestCase(AsyncHTTPTestCase):

    def setUp(self):
        app = self.get_app()
        engine = app._engine
        self.connection = engine.connect()

        self.trans = self.connection.begin()
        app._Session = scoped_session(
                sessionmaker(bind=self.connection, autoflush=False))
        app.db = Models(app._Session)
        super(BaseTestCase, self).setUp()
        self.fake_session = {}

        def fake_get(context, name, *args):
            if name in self.fake_session:
                return self.fake_session[name]
            return orig_session_get(context, name, *args)
        SessionManager.get = fake_get

        self.dbSetUp()
        self.sessionSetUp()

    def tearDown(self):
        self.trans.rollback()
        self.connection.close()
        super(BaseTestCase, self).tearDown()
        self.dbTearDown()
        self.sessionTearDown()
        SessionManager.get = orig_session_get

    def sessionSetUp(self): pass

    def sessionTearDown(self): pass

    def dbSetUp(self): pass

    def dbTearDown(self): pass

    def get_app(self):
        if not hasattr(self, '_app'):
            settings['xsrf_cookies'] = False
            self._app = Application(**settings)
        return self._app

    def _url(self, path, **kwargs):
        return url_concat(path, kwargs)
