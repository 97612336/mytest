# coding=utf-8

from __future__ import absolute_import, print_function
import os
import datetime
import tornado.options
from tornado.options import define, options

define("debug", default=True, help="debug", group='app')
define("prod", default=False, help="production env", group='app')
define("port", default=23000, help="listen port", type=int)
define("static_path", default="", help="web static path", group='app')
define("template_path", default="", help="template path", group='app')
define("cookie_secret", default="", help="cookie_secret", group='app')
define("xsrf_cookies", default=True, help="xsrf_cookies", group='app')
define("config", default="./conf/server.conf", help="config file path")

default_mysql_uri = "mysql+pymysql:///cheyixiao?" + \
        "read_default_file=~/.afsaas.cnf&charset=utf8mb4"
define("mysql_uri", default=default_mysql_uri)

define("cmd", default="", help="run cmd")

tornado.options.parse_command_line(final=False)
if options.config:
    tornado.options.parse_config_file(options.config)


if options.prod:
    options.debug = False

settings = options.group_dict('app')
if not settings['static_path']:
    settings['static_path'] = os.path.join(os.path.dirname(__file__), "static")
if not settings['template_path']:
    settings['template_path'] = os.path.join(
            os.path.dirname(__file__), "templates")
if len(settings.get('upload_path', '')) < 1:
    settings['upload_path'] = "upload"

if options.prod:
    settings['compress_response'] = True
else:
    settings['template_whitespace'] = 'all'

session_settings = dict(
        driver="redis",
        driver_settings=dict(
            host='localhost',
            port=6379,
            db=0,
            max_connections=1024,
            ),
        cookie_config=dict(
            expires_days=30,
            ),
        )
settings.update(session=session_settings)
