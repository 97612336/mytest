#cs15
ename,name,url

showroom,展厅场景,pocket/images/showroom.png
mountainroad,山路场景,pocket/images/mountainroad.png
airport,机场场景,pocket/images/airport.png

#hanlanda
ename,name,url

showroom,展厅场景,pocket/images/showroom.png
mountainroad,山路场景,pocket/images/mountainroad.png
airport,机场场景,pocket/images/airport.png
