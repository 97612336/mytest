# cs15
ename,name,color

orange,闪光炫彩橙黄,#9c2f10,
red,闪光宝石红,#710a0d
blue,闪光深海蓝#0a3f86
black,闪光珠光黑,#121214
white,雪域白,#b9bdc6
grey,闪光星河银灰,#6f737c
green,闪光璀璨金黄,#696644 
golden,闪光璀璨金黄,#696644


#汉兰达
ename,name,color

black,炫晶黑,#030303,
white,珍珠白,#dde2e0,
grey,水晶银,#9ba8ab,
red,翡钻红,#701A1B,
