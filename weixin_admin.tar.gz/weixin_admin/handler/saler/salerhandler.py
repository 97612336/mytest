# coding=utf-8

from __future__ import absolute_import, print_function
from .basehandler import BaseHandler
import logging
import datetime
import os
from tornado.httputil import urlencode
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest, HTTPClient)
from tornado.escape import (json_encode, json_decode)
import tornado.gen
import qrcode
import json
from collections import Counter
import random
import time
import hashlib
import xml.etree.ElementTree as ET
from wechatpy.pay.api import WeChatOrder
from wechatpy.client import BaseWeChatClient

try:
    from StringIO import StringIO
except ImportError:
    from io import BytesIO as StringIO


def __handlers(settings):
    return [
        (r"/v1/saler/login", LoginHandler),
        (r"/v1/saler/expire/verify", ExpireVerifyHandler),
        (r"/v1/saler/uid", SalerUserIdHandler),
        (r"/v2/saler/look", SalerLookHandler),
        (r"/v1/saler/bill", SalerBillHandler),
        (r"/v1/saler/qrcode/url", SalerQrcodeUrlHandler),
        (r"/v1/saler/config", SalerConfigHandler),
        (r"/v1/saler/config/detail", SalerConfigDetailHandler),
        (r"/v1/saler/full/payment", FullPaymentHandler),
        (r"/v1/saler/logout", LogoutHandler),
        (r"/v2/sms/user/focus", UserFocusHandler),
        (r"/v2/sms/user/focus/del", UserFocusDelHandler),
        (r"/v2/sms/car/schemes", CarSchemesSelcetHandler),
        (r"/v2/sms/user/info/insert", UserInfoInsertHandler),
        (r"/v3/saler/bill", V3SalerBillHandler),
        (r"/v3/saler/payment/qrcode/url", SalerPaymentQrcodeUrlHandler),
    ]


class LoginHandler(BaseHandler):
    tokenpass = True

    def check_xsrf_cookie(self):
        pass

    def get(self):
        username = self.get_argument('username', '')
        passwd = self.get_argument('passwd', '')
        passwd_md5 = self.db.salers.to_password(username, passwd)
        self.render_json({'passwd': passwd_md5})

    def post(self):
        username = self.get_argument('username', '')
        passwd = self.get_argument('passwd', '')
        passwd_md5 = passwd
        passwd = self.db.salers.to_password(username, passwd)
        if not all((username, passwd)):
            self.render_json({'code': 403, 'msg': '账号或密码错误'})
            return
        query = {'username': username, 'password': passwd}
        saler = self.db.salers.find_one(query)
        utype = 0
        if saler:
            device_id = saler.get('device_id', 0)
            device = self.db.devices.find_one({'id': device_id})
            utype = saler.perm
            name = saler.name
        else:
            query = {'username': username, 'password': passwd_md5}
            saler = self.db.salers.find_one(query)
            if saler:
                device_id = saler.get('device_id', 0)
                device = self.db.devices.find_one({'id': device_id})
                utype = saler.perm
                name = saler.name
            else:
                self.render_json({'code': 406, 'msg': '账号或密码错误'})
                return
        if device:
            token = self.gen_token()
            expire_at = device.expire_at
            now = datetime.datetime.now()
            delta = (expire_at - now).days
            if delta < 0:
                self.render_json({'code': 201, 'msg': ' 账号已到期!'})
                return
            elif 0 < delta < 15:
                self.render_json({'code': 200,
                                  'msg': '账号还剩{}天到期'.format(delta),
                                  'expire': True, 'utype': utype,
                                  'name': name, 'avatar': saler.avatar,
                                  'Cyx_token': token, 'Cyx_saler': saler.id})
            else:
                self.render_json({'code': 200, 'msg': '登录成功',
                                  'expire': False, 'utype': utype,
                                  'name': name, 'avatar': saler.avatar,
                                  'Cyx_token': token, 'Cyx_saler': saler.id})

            self.login_session_update(saler.id, saler.to_dict())
            redis = self.redis
            hkey = 'one:login:saler:id:{}'.format(saler.id)
            cur_time = str(datetime.datetime.now().replace(microsecond=0))
            msid = token
            ip = self.request.remote_ip
            dic = {"msid": msid, "ip": str(ip), "time": cur_time}
            redis.hmset(hkey, dic)

            self.update_user_token(saler.id, token)


class ExpireVerifyHandler(BaseHandler):
    def not_login(self):
        self.render_json({'code': 403, 'msg': '您还没登录', 'url_type': 'ok'})
        self.finish()
        return

    def get(self):
        saler = self.session.get('Saler', False)
        if saler:
            device_id = saler.get('device_id', 0)
            device = self.db.devices.find_one({'id': device_id})
            if device:
                expire_at = device.expire_at
                if expire_at:
                    now = datetime.datetime.now()
                    delta = (expire_at - now).days
                    if 0 < delta < 15:
                        self.render_json(
                            {'code': 202,
                             'msg': ' 账号还剩{}天到期!'.format(delta),
                             'url_type': 'ok'})
                    else:
                        self.render_json({'code': 200, 'url_type': 'ok'})


class SalerUserIdHandler(BaseHandler):
    def get(self):
        user = self.db.users.insert_one({})
        user_id = user.id
        saler_id = self.session_saler_info('id', 0)
        info = {'saler_id': saler_id, 'user_id': user_id, 'status': 1}
        try:
            user_status = self.db.user_status.find_one(
                {'saler_id': saler_id, 'user_id': user_id})
            if not user_status:
                self.db.user_status.insert_one(info)
        except Exception as e:
            logging.debug('insert into user_status error:%s', e)
        self.render_json({'code': 200, 'uid': user_id})


class SalerLookHandler(BaseHandler):
    def check_xsrf_cookie(self):
        pass

    def get(self):
        user_id = self.get_argument('uid', 0)
        car_id = self.get_argument('carid', 0)
        action = self.get_argument('action', '')
        avalue = self.get_argument('avalue', '')
        lon = self.get_argument('lon', '')
        lat = self.get_argument('lat', '')
        ip = self.request.remote_ip
        saler_id = self.session_saler_info('id', 0)
        info = dict(user_id=user_id,
                    car_id=car_id,
                    action=action,
                    avalue=avalue,
                    saler_id=saler_id,
                    ip=ip,
                    lon=lon,
                    lat=lat)
        focus_car_info = {'user_id': user_id, 'car_id': car_id,
                          'saler_id': saler_id}
        focus_car = self.db.focus_car.find_one(focus_car_info)
        if focus_car:
            pass
        else:
            self.db.focus_car.insert_one(focus_car_info)
        self.db.look.insert_one(info)
        self.render_json({'code': 200, 'url_type': 'ok'})


class SalerBillHandler(BaseHandler):
    def check_xsrf_cookie(self):
        pass

    def post(self):
        car_id = self.get_argument('car_id', 0)
        user_id = self.get_argument('user_id', 0)
        color = self.get_argument('color', '')
        hub = self.get_argument('hub', '')
        total_cost = self.get_argument('total_cost', 0)
        i1 = self.get_argument_int('i1')
        i2 = self.get_argument_int('i2')
        i3 = self.get_argument_int('i3')
        i4 = self.get_argument_int('i4')
        i5 = self.get_argument_int('i5')
        i6 = self.get_argument_int('i6')
        i7 = self.get_argument_int('i7')
        i8 = self.get_argument_int('i8')
        i9 = self.get_argument_int('i9')
        i10 = self.get_argument_int('i10')
        i11 = self.get_argument_int('i11')
        i12 = self.get_argument_int('i12')
        i13 = self.get_argument_int('i13')
        i14 = self.get_argument_int('i14')
        i15 = self.get_argument_int('i15')
        i16 = self.get_argument_int('i16')
        parts = self.get_argument('parts', '')
        saler_id = self.session_saler_info('id', 0)
        info = {'user_id': user_id, 'saler_id': saler_id, 'car_id': car_id,
                'total_cost': total_cost, 'color': color, 'hub': hub,
                'i1': i1, 'i2': i2, 'i3': i3, 'i4': i4, 'i5': i5, 'i6': i6,
                'i7': i7, 'i8': i8, 'i9': i9, 'i10': i10, 'i11': i11,
                'i12': i12, 'i13': i13, 'i14': i14, 'i15': i15, 'i16': i16}
        try:
            bill = self.db.bills.insert_one(info)
        except Exception as e:
            logging.debug('insert into bills error:%s', e)
            self.render_json({'code': 500, 'msg': '服务器异常'})
            return
        else:
            bill_id = bill.id
            part_list = parts.split(',')
            for cartegory_id in part_list:
                if cartegory_id:
                    try:
                        info = {'bill_id': bill_id,
                                'scheme_id': int(cartegory_id)}
                        self.db.bill_schemes.insert_one(info)
                    except Exception as e:
                        pass
            token = self.token
            self.render_json({'code': 200,
                              'url': 'https://cheyixiao.autoforce.net/v1/saler'
                                     '/qrcode/url?billid={}&Cyx_saler={}&'
                                     'Cyx_token={}'.format(bill_id, saler_id,
                                                           token),
                              'bill_id': bill_id})


class V3SalerBillHandler(BaseHandler):
    def check_xsrf_cookie(self):
        pass

    def post(self):
        car_id = self.get_argument_int('car_id')
        user_id = self.get_argument_int('user_id')
        if not car_id or not user_id:
            self.render_json({'code': 500, 'msg': '服务器异常'})
            return
        color = self.get_argument('color', '')
        hub = self.get_argument('hub', '')
        total_cost = self.get_argument_int('total_cost')
        i1 = self.get_argument_int('i1')
        i2 = self.get_argument_int('i2')
        i3 = self.get_argument_int('i3')
        i4 = self.get_argument_int('i4')
        i5 = self.get_argument_int('i5')
        i6 = self.get_argument_int('i6')
        i7 = self.get_argument_int('i7')
        i8 = self.get_argument_int('i8')
        i9 = self.get_argument_int('i9')
        i10 = self.get_argument_int('i10')
        i11 = self.get_argument_int('i11')
        i12 = self.get_argument_int('i12')
        i13 = self.get_argument_int('i13')
        i14 = self.get_argument_int('i14')
        i15 = self.get_argument_int('i15')
        i16 = self.get_argument_int('i16')
        parts = self.get_argument('parts', '')
        is_test = self.get_argument_int('is_test', 0)
        saler_id = self.session_saler_info('id', 0)
        info = {'user_id': user_id, 'saler_id': saler_id, 'car_id': car_id,
                'total_cost': total_cost, 'color': color, 'hub': hub,
                'i1': i1, 'i2': i2, 'i3': i3, 'i4': i4, 'i5': i5, 'i6': i6,
                'i7': i7, 'i8': i8, 'i9': i9, 'i10': i10, 'i11': i11,
                'i12': i12, 'i13': i13, 'i14': i14, 'i15': i15, 'i16': i16, 'is_test': is_test}
        try:
            bill = self.db.bills.insert_one(info)
        except Exception as e:
            logging.debug('insert into bills error:%s', e)
            self.render_json({'code': 500, 'msg': '服务器异常'})
            return
        else:
            bill_id = bill.id
            part_list = parts.split(',')
            for cartegory_id in part_list:
                if cartegory_id:
                    try:
                        info = {'bill_id': bill_id,
                                'scheme_id': int(cartegory_id)}
                        self.db.bill_schemes.insert_one(info)
                    except Exception as e:
                        pass
            token = self.token

            redis = self.redis
            hkey = 'count'
            order_num = redis.hget(hkey, key="bill_num")
            new_order_num = ''
            try:
                new_order_num = int(order_num) + 1
            except Exception as e:
                pass
            redis.hmset("count", {"bill_num": new_order_num})

            hkey2 = 'today_bill'
            now = datetime.datetime.now()
            hour = int(str(now).split(' ')[1][0:2])
            num = self.redis.hget(hkey2, key=hour)
            if num:
                num = int(num)
            else:
                num = 0
            for h in range(6, 24):
                if h == hour:
                    num += 1
            self.redis.hset(hkey2, hour, num)

            self.render_json({'code': 200,
                              'url': 'https://cheyixiao.autoforce.net/v3/saler/payment/qrcode/url?bill_id={}&'
                                     'Cyx_saler={}&Cyx_token={}'.
                             format(bill_id, saler_id, token),
                              'bill_id': bill_id})


class SalerPaymentQrcodeUrlHandler(BaseHandler, WeChatOrder):

    @tornado.gen.coroutine
    def get(self):
        bill_id = self.get_argument_int('bill_id')
        session = self.DB
        Bills = self.model('bills')
        Users = self.model("users")
        bill = session.query(Bills).filter(Bills.id == bill_id).first()
        if bill:
            car_id = bill.car_id
            appid = os.getenv('CheXiaoYiAppID', '')
            mch_id = os.getenv('CheXiaoYiMchId', '')
            device_info = "WEB"
            nonce_str = self.get_wx_pay_nonce_str()
            connection = self.get_afsaas_connection()
            car_name = ''
            with connection.cursor() as cursor:
                query_sql = 'select i1 from specs where id="%s"' % car_id
                cursor.execute(query_sql)
                spec = cursor.fetchone()
                if spec:
                    car_name = spec.get('i1', '')
            user_name = session.query(Users.name).filter(Users.id == bill.user_id).scalar()
            if not user_name:
                user_name = ''
            body = user_name + ' 购车定金支付 ' + car_name + '(车易销)'
            total_fee = 10000
            ip = os.getenv('CheXiaoYiServerIp', '114.240.58.31')
            spbill_create_ip = ip
            notify_url = 'https://cheyixiao.autoforce.net/v3/wx/payment/notice'
            trade_type = 'NATIVE'
            out_trade_no = str(int(time.time())) + '_' + str(bill_id)
            product_id = str(int(time.time())) + '_' + str(car_id)
            time_start = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
            time_expire_temp = datetime.datetime.now() + datetime.timedelta(minutes=5)
            time_expire = time_expire_temp.strftime('%Y%m%d%H%M%S')
            params = dict(
                appid=appid,
                mch_id=mch_id,
                device_info=device_info,
                nonce_str=nonce_str,
                body=body,
                total_fee=total_fee,
                spbill_create_ip=spbill_create_ip,
                notify_url=notify_url,
                trade_type=trade_type,
                out_trade_no=out_trade_no,
                product_id=product_id,
                time_start=time_start,
                time_expire=time_expire
            )
            sign = self.get_wx_pay_sign(params)
            params['sign'] = sign
            url = 'https://api.mch.weixin.qq.com/pay/unifiedorder'
            headers = {"content-type": "text/xml"}
            data = '<xml>'
            for key, value in params.items():
                data = '%s<%s>%s</%s>' % (data, key, value, key)
            data = '%s</xml>' % data
            logging.debug('data:%s', data)
            request = HTTPRequest(
                url=url,
                method='POST',
                headers=headers,
                body=data.encode('utf-8'),
                connect_timeout=60,
                request_timeout=60,
            )
            client = AsyncHTTPClient()
            response = yield client.fetch(request)
            if response.error:
                logging.debug('request 统一下单接口出错:%s', response.error)
                return None
            else:
                body = response.body.decode('utf-8')
                logging.debug('body:%s', body)
                data = ET.fromstring(body)
                return_code = data.find('return_code').text
                if return_code == 'SUCCESS':
                    trade_type = data.find('trade_type').text
                    prepay_id = data.find('prepay_id').text
                    code_url = data.find('code_url').text
                    unifiedorder_info = dict(
                        bill_id=bill_id,
                        saler_id=self.saler_id,
                        prepay_id=prepay_id,
                        device_info=device_info,
                        trade_type=trade_type,
                        out_trade_no=out_trade_no,
                        product_id=product_id,
                        time_start=time_start,
                        time_expire=time_expire,
                        total_fee=total_fee,
                        code_url=code_url
                    )
                    try:
                        self.db.unifiedorder.insert_one(unifiedorder_info)
                    except Exception as e:
                        logging.debug('insert into unifiedorder error:%s', e)
                    else:
                        qr = qrcode.QRCode(
                            version=1,
                            error_correction=qrcode.constants.ERROR_CORRECT_L,
                            box_size=10,
                            border=4,
                        )
                        qr.add_data(code_url)
                        qr.make(fit=True)
                        img = qr.make_image()
                        mstream = StringIO()
                        img.save(mstream, 'PNG')
                        self.set_header('Content-Type', 'image/png')
                        self.write(mstream.getvalue())


class SalerConfigHandler(BaseHandler):
    def get(self):
        car_id = self.get_argument_int('car_id')
        connection = self.get_afsaas_connection()
        with connection.cursor() as cursor:
            query_sql = 'select * from specs where id="%s"' % car_id
            cursor.execute(query_sql)
            data = cursor.fetchone()
            if data:
                i1 = data.get('i1', '')
                i2 = data.get('i2', '')
                i6 = data.get('i6', '')
                i7 = data.get('i7', '')
                i9 = data.get('i9', '')
                i10 = data.get('i10', '')
                i12 = data.get('i12', '')
                i14 = data.get('i14', '')
                config = data.get('config')
                config = json_decode(config)
                i20 = config.get('i20', '')
                i29 = config.get('i29', '')
                i30 = config.get('i30', '')
                i31 = config.get('i31', '')
                i42 = config.get('i42', '')
                i44 = config.get('i44', '')
                i48 = config.get('i48', '')
                i66 = config.get('i66', '')
                up = [{'排量': i31 or '-'}, {'功率': i42 or '-'},
                      {'油耗': i14 or '-'}, {'驱动方式': i66 or '-'},
                      {'变速箱': i6 or '-'}, {'燃油标号': i48 or '-'},
                      {'最大扭矩': i44 or '-'}, {'加速时间': i10 or '-'},
                      {'制动': i12 or '-'}, {'最高时速': i9 or '-'}
                      ]
                down = [{'发动机类型': i30 or '-'}, {'车身尺寸': i7 or '-'},
                        {'轴距': i20 or '-'}, {'行李箱容积': i29 or '-'}]
                self.render_json({'code': 200,
                                  'results': {'up': up, 'down': down,
                                              'name': i1, 'price': i2}})
            else:
                self.render_json({'code': 500, 'msg': '未找到匹配信息'})


class FullPaymentHandler(BaseHandler):
    def get(self):
        car_id = self.get_argument_int('car_id')
        price = self.get_argument('price', None)
        if car_id:
            connection = self.get_afsaas_connection()
            with connection.cursor() as cursor:
                query_sql = 'select i1, i2, config from specs where ' \
                            'id="%s"' % car_id
                cursor.execute(query_sql)
                query = cursor.fetchone()
                price = float(query.get('i2').split('~')[0].strip('万'))
                price = price * 10000
                car_name = query.get('i1')
            i3_cost = int(price * 0.1 / 1.17)  # 购置税
            i4_cost = 500  # 上牌费用
            i6_cost = 0  # 车船使用费
            config = json_decode(query.get('config', '{}'))
            try:
                i32 = float(config.get('i32', '0'))
            except Exception:
                i32 = 0
            if i32 <= 1.0:
                i6 = 0
                i6_cost = 300
            elif 1.0 < i32 <= 1.6:
                i6 = 1
                i6_cost = 420
            elif 1.6 < i32 <= 2.0:
                i6 = 2
                i6_cost = 480
            elif 2.5 >= i32 > 2.0:
                i6 = 3
                i6_cost = 900
            elif 3.0 >= i32 > 2.5:
                i6 = 4
                i6_cost = 1920
            elif 4.0 >= i32 > 3.0:
                i6 = 5
                i6_cost = 3480
            else:
                i6 = 6
                i6_cost = 5280
            i27_tem = config.get('i27', '0')
            i27_one = i27_tem.split('/')[0]
            try:
                i27 = int(i27_one)
            except Exception as e:
                logging.debug('process i27 error:%s', e)
                i27 = 0
            if i27 < 6:
                i5 = 0  # 交通强制保险
                i5_cost = 950
            else:
                i5 = 1
                i5_cost = 1100
            i2_cost = i3_cost + i4_cost + i5_cost + i6_cost  # 必要花费
            necessary = {'i1': int(price), 'i2': i2_cost,
                         'i3': i3_cost, 'i4': i4_cost, 'i5': [i5, [950, 1100]],
                         'i6': [i6, [300, 420, 480, 900, 1920, 3480, 5280]]}
            # 第三方责任险
            i8 = [516, 746, 924, 1252, 1630]
            i8_default = 0
            i8_cost = i8[i8_default]
            i9_cost = int(459 + price * 0.01088)  # 车辆损失险
            i9 = i9_cost
            i10_cost = int(102 + price * 0.00451)  # 全车盗抢险
            i10 = i10_cost
            # 玻璃单独破碎险
            i11 = [int(price * 0.25 / 100), int(price * 0.15 / 100)]
            i11_default = 1
            i11_cost = i11[i11_default]
            i12_cost = int(price * 0.0015)  # 自燃损失险
            i12 = i12_cost
            i13_cost = int((i9_cost + i8_cost) * 0.2)  # 不计免赔特约险
            i13 = i13_cost
            i14_cost = int(i8_cost * 0.2)  # 无过责任险
            i14 = i14_cost
            # 车上人员责任险
            i15 = [50, 100, 150, 200, 250, 300, 350]
            i15_default = 1
            i15_cost = i15[i15_default]
            if price < 300000:
                one = 400
                two = 570
                three = 760
                four = 1140
            elif 300000 <= price < 500000:
                one = 585
                two = 900
                three = 1170
                four = 1780
            else:
                one = 850
                two = 1100
                three = 1500
                four = 2250
            # 车身划痕险
            i16 = [one, two, three, four]
            i16_default = 1
            i16_cost = i16[i16_default]
            i7_cost = i8_cost + i9_cost + i10_cost + i11_cost + i12_cost + \
                      i13_cost + i14_cost + i15_cost + i16_cost
            i7 = i7_cost
            total_cost = i2_cost + i7_cost
            commercial = {'i7': i7,
                          'i8': [i8_default, i8],
                          'i9': i9, 'i10': i10,
                          'i11': [i11_default, i11],
                          'i12': i12, 'i13': i13, 'i14': i14,
                          'i15': [i15_default, i15],
                          'i16': [i16_default, i16]}
            self.render_json({'code': 200,
                              'results': {'commercial': commercial,
                                          'necessary': necessary,
                                          'name': car_name,
                                          'total_cost': total_cost}})
        elif price is not None:
            price = int(price)
            i3_cost = int(price * 0.1 / 1.17)  # 购置税
            i8 = self.get_argument_int('i8')
            i8_cost = 0
            if i8 == 0:
                i8_cost = 516
            elif i8 == 1:
                i8_cost = 746
            elif i8 == 2:
                i8_cost = 924
            elif i8 == 3:
                i8_cost = 1252
            elif i8 == 4:
                i8_cost = 1630
            i9_cost = int(459 + price * 0.01088)  # 车辆损失险
            i10_cost = int(102 + price * 0.00451)  # 全车盗抢险
            i11 = self.get_argument_int('i11')  # 玻璃单独破碎险
            i11_cost = 0
            if i11 == 0:
                i11_cost = int(price * 0.25 / 100)
            elif i11 == 1:
                i11_cost = int(price * 0.15 / 100)
            i11_list = [int(price * 0.25 / 100), int(price * 0.15 / 100)]
            i12_cost = int(price * 0.0015)  # 自燃损失险
            i13_cost = int((i9_cost + i8_cost) * 0.2)  # 不计免赔特约险
            i14_cost = int(i8_cost * 0.2)  # 无过责任险
            i16 = self.get_argument_int('i16')  # 车身划痕险
            i16_cost = 0
            if price < 300000:
                if i16 == 0:
                    i16_cost = 400
                elif i16 == 1:
                    i16_cost = 570
                elif i16 == 2:
                    i16_cost = 760
                elif i16 == 3:
                    i16_cost = 1140
                i16_list = [400, 570, 760, 1140]
            elif 300000 <= price < 500000:
                if i16 == 0:
                    i16_cost = 585
                elif i16 == 1:
                    i16_cost = 900
                elif i16 == 2:
                    i16_cost = 1170
                elif i16 == 3:
                    i16_cost = 1780
                i16_list = [585, 900, 1170, 1780]
            else:
                if i16 == 0:
                    i16_cost = 850
                elif i16 == 1:
                    i16_cost = 1100
                elif i16 == 2:
                    i16_cost = 1500
                elif i16 == 3:
                    i16_cost = 2250
                i16_list = [850, 1100, 1500, 2250]
            necessary = {'i3': i3_cost}
            commercial = {'i9': i9_cost, 'i10': i10_cost,
                          'i11': [i11, i11_list], 'i12': i12_cost,
                          'i13': i13_cost, 'i14': i14_cost,
                          'i16': [i16, i16_list]}
            self.render_json({'code': 200,
                              'results': {'commercial': commercial,
                                          'necessary': necessary}})


class LogoutHandler(BaseHandler):
    def get(self):
        self.session.delete("Saler")
        self.render_json({"code": 200, "msg": "已退出登录！"})


class UserFocusHandler(BaseHandler):

    def get(self):
        Look = self.model("look")

        user_id = self.get_argument_int("user_id", 0)
        if not user_id:
            self.render_json({"code": 406, "msg": "请传入user_id !"})
            return
        saler_id = self.session_saler_info("id", "")
        fcars = self.db.focus_car.query(). \
            filter_by(user_id=user_id, saler_id=saler_id).all()
        car_ids = [c.car_id for c in fcars]
        looks = self.db.look.query(). \
            filter_by(user_id=user_id, saler_id=saler_id). \
            filter(Look.car_id.in_(car_ids)).all()
        dict_cars = {}
        for look in looks:
            car_id_str = str(look.car_id)
            if car_id_str not in dict_cars.keys():
                dict_cars[car_id_str] = [look]
            else:
                dict_cars[car_id_str].append(look)
        results = []
        for cid_str in dict_cars.keys():
            car_id = int(cid_str)
            tmp_dict = {}
            colors = []
            wheels = []
            for l in dict_cars[cid_str]:
                if l.action == "outer_color":
                    colors.append(l.avalue)
                if l.action == "lungu":
                    wheels.append(l.avalue)
            if colors:
                dic_colors = dict(Counter(colors))
                max_color = max(dic_colors.items(), key=lambda x: x[1])
                max_color_list = []
                max_num = max_color[1]
                for k, v in dic_colors.items():
                    if v == max_num:
                        max_color_list.append(k)
                if len(max_color_list) == 1:
                    love_color = max_color[0]
                else:
                    win_color = self.db.look.query(). \
                        filter_by(user_id=user_id, saler_id=saler_id). \
                        filter(Look.avalue.in_(max_color_list)). \
                        order_by(Look.created_at.desc()).first()
                    love_color = win_color.avalue
                car_color = self.db.car_color. \
                    find_one({"car_id": car_id, "ename": love_color})
            else:
                car_color = self.db.car_color. \
                    find_one({"car_id": car_id})
            if car_color:
                tmp_dict["color"] = car_color.name
                tmp_dict["color_img"] = car_color.color
            if not car_color:
                tmp_dict["color"] = '暂无'
                tmp_dict["color_img"] = ''

            if wheels:
                dic_wheels = dict(Counter(wheels))
                max_wheel = max(dic_wheels.items(), key=lambda x: x[1])
                max_wheel_list = []
                max_num = max_wheel[1]
                for k, v in dic_wheels.items():
                    if v == max_num:
                        max_wheel_list.append(k)
                if len(max_wheel_list) == 1:
                    love_wheel = max_wheel[0]
                else:
                    win_wheel = self.db.look.query(). \
                        filter_by(user_id=user_id, saler_id=saler_id). \
                        filter(Look.avalue.in_(max_wheel_list)). \
                        order_by(Look.created_at.desc()).first()
                    love_wheel = win_wheel.avalue
                car_wheel = self.db.car_wheels. \
                    find_one({"car_id": car_id, "ename": love_wheel})
            else:
                car_wheel = self.db.car_wheels. \
                    find_one({"car_id": car_id})
            if car_wheel:
                tmp_dict["wheel"] = car_wheel.name
                tmp_dict["wheel_img"] = car_wheel.logo
            if not car_wheel:
                tmp_dict["wheel"] = '暂无'
                tmp_dict["wheel_img"] = ''
            tmp_dict["car_id"] = cid_str
            car = self.db.specs.find_one({"id": car_id})
            if car:
                tmp_dict["car_img"] = car.logo
                tmp_dict["car_name"] = car.name
            results.append(tmp_dict)
        self.render_json({"code": 200, "res": results})


class UserFocusDelHandler(BaseHandler):

    def get(self):
        saler_id = self.session_saler_info("id", "")
        car_id = self.get_argument_int("car_id", 0)
        if not car_id:
            self.render_json({"code": 406, "msg": "请传入car_id !"})
            return
        user_id = self.get_argument_int("user_id", 0)
        if not user_id:
            self.render_json({"code": 406, "msg": "请传入user_id !"})
            return
        self.db.focus_car.query().filter_by(car_id=car_id, user_id=user_id,
                                            saler_id=saler_id). \
            delete(synchronize_session='fetch')
        self.DB.commit()
        self.render_json({"code": 200, "msg": "操作成功 ！"})


class CarSchemesSelcetHandler(BaseHandler):

    # provide choose page
    def get(self):
        car_id = self.get_argument_int("car_id")
        if not car_id:
            self.render_json({"code": 400, "msg": "缺少必要参数car_id"})
            return
        saler_id = self.session_saler_info("id", '')
        dealer_id = self.db.salers.find_one({"id": saler_id}).dealer_id
        car_scheme = self.db.car_scheme.find_one({"car_id": car_id,
                                                  "dealer_id": dealer_id,
                                                  "status": 2})
        if not car_scheme:
            self.render_json({"code": 200, "res": []})
            return
        cs_id = car_scheme.id
        schemes = self.db.schemes.query().filter_by(cs_id=cs_id).all()
        res_list = []
        for scheme in schemes:
            tmp_dict = {}
            scheme_id = scheme.id
            tmp_dict["scheme_id"] = scheme.id
            tmp_dict["name"] = scheme.name
            tmp_dict["price"] = scheme.price
            tmp_dict["img"] = ''
            if scheme.img_id:
                scheme_img = self.db.imgs.find_one({"id": scheme.img_id})
                if scheme_img:
                    tmp_dict['img'] = scheme_img.url
            options = self.db.scheme_options.query(). \
                filter_by(scheme_id=scheme_id).all()
            op_list = []
            for op in options:
                tmp_op_dict = {}
                tmp_op_dict["op_id"] = op.id
                tmp_op_dict["name"] = op.name
                tmp_op_dict["price"] = op.price
                tmp_op_dict['img'] = ''
                if op.img_id:
                    op_img = self.db.imgs.find_one({"id": op.img_id})
                    if op_img:
                        tmp_op_dict['img'] = op_img.url
                op_list.append(tmp_op_dict)
            tmp_dict["options"] = op_list
            res_list.append(tmp_dict)
        self.render_json({"code": 200, "res": res_list})


class UserInfoInsertHandler(BaseHandler):

    def check_xsrf_cookie(self):
        pass

    def post(self):
        name = self.get_argument('name', '')
        phone = self.get_argument_int('phone', '')
        user_id = self.get_argument_int('user_id', '')
        customer_type = self.get_argument('customer_type', '')
        note = self.get_argument('note', '')
        info = {}
        info['name'] = name
        info['phone'] = phone
        if customer_type:
            info['utype'] = customer_type
        if note:
            info['note'] = note
        try:
            self.db.users.update_one({'id': user_id}, {'$set': info})
            self.render_json({'code': 200, 'msg': '更新成功'})
        except Exception as e:
            logging.debug('error:%s', e)
            self.render_json({'code': 203, 'msg': '更新失败'})
            return


class SalerQrcodeUrlHandler(BaseHandler):
    tokenpass = True

    @tornado.gen.coroutine
    def get(self):
        bill_id = self.get_argument('billid', '')
        redis = self.redis
        access_token_key = 'Chexiaoyi:access_token'
        access_token = redis.get(access_token_key)
        if access_token:
            pass
        else:
            access_token = yield self.get_access_token()
        url = yield self.get_qrcode_by_access_token(
            access_token, bill_id)
        if not url:
            access_token = yield self.get_access_token()
            url = yield self.get_qrcode_by_access_token(
                access_token, bill_id)

        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(url)
        qr.make(fit=True)
        img = qr.make_image()
        mstream = StringIO()
        img.save(mstream, 'PNG')
        self.set_header('Content-Type', 'image/png')
        self.write(mstream.getvalue())

    @tornado.gen.coroutine
    def get_qrcode_by_access_token(self, access_token, bill_id):
        url = 'https://api.weixin.qq.com/cgi-bin/qrcode/create?' \
              'access_token={}'.format(access_token)
        headers = {"content-type": "application/json"}
        body = json_encode({"expire_seconds": 86400,
                            "action_name": "QR_SCENE",
                            "action_info": {"scene": {"scene_id": bill_id}}})
        request = HTTPRequest(
            url=url,
            method='POST',
            headers=headers,
            body=body,
            connect_timeout=60,
            request_timeout=60,
        )
        client = AsyncHTTPClient()
        response = yield client.fetch(request)
        if response.error:
            logging.debug('qrcode response.error:%s', response.error)
        else:
            body = json_decode(response.body)
            logging.debug('body:%s', body)
            qrcode_url = body.get('url', '')
            return qrcode_url


class SalerConfigDetailHandler(BaseHandler):

    def get(self):
        car_id = self.get_argument_int('car_id')
        connection = self.get_afsaas_connection()
        with connection.cursor() as cursor:
            query_sql = 'select * from specs where id="%s"' % car_id
            cursor.execute(query_sql)
            spec = cursor.fetchone()
            config = spec.get('config', None)
            if config:
                config = json_decode(config)
                i1 = spec.get('i1', '')
                i2 = spec.get('i2', '')
                i3 = spec.get('i3', '')
                i4 = spec.get('i4', '')
                i5 = spec.get('i5', '')
                i6 = spec.get('i6', '')
                i7 = spec.get('i7', '')
                i8 = spec.get('i8', '')
                i9 = spec.get('i9', '')
                i10 = spec.get('i10', '')
                i11 = spec.get('i11', '')
                i12 = spec.get('i12', '')
                i13 = spec.get('i13', '')
                i14 = spec.get('i14', '')
                i15 = spec.get('i15', '')
                basic_para_map = dict(
                    i1='车型名称',
                    i2='厂商指导价(元)',
                    i3='厂商',
                    i4='级别',
                    i5='发动机',
                    i6='变速箱',
                    i7='长*宽*高(mm)',
                    i8='车身结构',
                    i9='最高车速(km/h)',
                    i10='官方0-100km/h加速(s)',
                    i11='实测0-100km/h加速(s)',
                    i12='实测100-0km/h制动(m)',
                    i13='实测油耗(L/100km)',
                    i14='工信部综合油耗(L/100km)',
                    i15='实测离地间隙(mm)',
                )
                car_body_map = dict(
                    i16='整车质保',
                    i17='长度(mm)',
                    i18='宽度(mm)',
                    i19='高度(mm)',
                    i20='轴距(mm)',
                    i21='前轮距(mm)',
                    i22='后轮距(mm)',
                    i23='最小离地间隙(mm)',
                    i24='整备质量(kg)',
                    i25='车身结构',
                    i26='车门数(个)',
                    i27='座位数(个)',
                    i28='油箱容积(L)',
                    i29='行李厢容积(L)',
                )
                engine_map = dict(
                    i30='发动机型号',
                    i31='排量(mL)',
                    i32='排量(L)',
                    i33='进气形式',
                    i34='气缸排列形式',
                    i35='气缸数(个)',
                    i36='每缸气门数(个)',
                    i37='压缩比',
                    i38='配气机构',
                    i39='缸径(mm)',
                    i40='行程(mm)',
                    i41='最大马力(Ps)',
                    i42='最大功率(kW)',
                    i43='最大功率转速(rpm)',
                    i44='最大扭矩(N·m)',
                    i45='最大扭矩转速(rpm)',
                    i46='发动机特有技术',
                    i47='燃料形式',
                    i48='燃油标号',
                    i49='供油方式',
                    i50='缸盖材料',
                    i51='缸体材料',
                    i52='环保标准',
                )
                electric_map = dict(
                    i53='电动机总功率(kW)',
                    i54='电动机总扭矩(N·m)',
                    i55='前电动机最大功率(kW)',
                    i56='前电动机最大扭矩(N·m)',
                    i57='后电动机最大功率(kW)',
                    i58='后电动机最大扭矩(N·m)',
                    i59='工信部续航里程(km)',
                    i60='电池容量(kWh)',
                    i61='电池充电时间',
                    i62='充电桩价格',
                )
                gear_map = dict(
                    i63='简称',
                    i64='挡位个数',
                    i65='变速箱类型',
                )

                bottom_map = dict(
                    i66='驱动方式',
                    i67='四驱形式',
                    i68='中央差速器结构',
                    i69='前悬架类型',
                    i70='后悬架类型',
                    i71='助力类型',
                    i72='车体结构',
                )
                brake_map = dict(
                    i73='前制动器类型',
                    i74='后制动器类型',
                    i75='驻车制动类型',
                    i76='前轮胎规格',
                    i77='后轮胎规格',
                    i78='备胎规格',
                )
                safe_map = dict(
                    i79='主/副驾驶座安全气囊',
                    i80='前/后排侧气囊',
                    i81='前/后排头部气囊(气帘)',
                    i82='膝部气囊',
                    i83='胎压监测装置',
                    i84='零胎压继续行驶',
                    i85='安全带未系提示',
                    i86='ISOFIX儿童座椅接口',
                    i87='发动机电子防盗',
                    i88='车内中控锁',
                    i89='遥控钥匙',
                    i90='无钥匙启动系统',
                    i91='无钥匙进入系统',
                )
                handle_map = dict(
                    i92='ABS防抱死',
                    i93='制动力分配(EBD/CBC等)',
                    i94='刹车辅助(EBA/BAS/BA等)',
                    i95='牵引力控制(ASR/TCS/TRC等)',
                    i96='车身稳定控制(ESC/ESP/DSC等)',
                    i97='上坡辅助',
                    i98='自动驻车',
                    i99='陡坡缓降',
                    i100='可变悬架',
                    i101='空气悬架',
                    i102='可变转向比',
                    i103='前桥限滑差速器/差速锁',
                    i104='中央差速器锁止功能',
                    i105='后桥限滑差速器/差速锁',
                )
                outer_map = dict(
                    i106='电动天窗',
                    i107='全景天窗',
                    i108='运动外观套件',
                    i109='铝合金轮圈',
                    i110='电动吸合门',
                    i111='侧滑门',
                    i112='电动后备厢',
                    i113='感应后备厢',
                    i114='车顶行李架',
                )
                inner_map = dict(
                    i115='真皮方向盘',
                    i116='方向盘调节',
                    i117='方向盘电动调节',
                    i118='多功能方向盘',
                    i119='方向盘换挡',
                    i120='方向盘加热',
                    i121='方向盘记忆',
                    i122='定速巡航',
                    i123='前/后驻车雷达',
                    i124='倒车视频影像',
                    i125='行车电脑显示屏',
                    i126='全液晶仪表盘',
                    i127='HUD抬头数字显示',
                )
                chair_map = dict(
                    i128='座椅材质',
                    i129='运动风格座椅',
                    i130='座椅高低调节',
                    i131='腰部支撑调节',
                    i132='肩部支撑调节',
                    i133='主/副驾驶座电动调节',
                    i134='第二排靠背角度调节',
                    i135='第二排座椅移动',
                    i136='后排座椅电动调节',
                    i137='电动座椅记忆',
                    i138='前/后排座椅加热',
                    i139='前/后排座椅通风',
                    i140='前/后排座椅按摩',
                    i141='第三排座椅',
                    i142='后排座椅放倒方式',
                    i143='前/后中央扶手',
                    i144='后排杯架',
                )
                video_map = dict(
                    i145='GPS导航系统',
                    i146='定位互动服务',
                    i147='中控台彩色大屏',
                    i148='蓝牙/车载电话',
                    i149='车载电视',
                    i150='后排液晶屏',
                    i151='220V/230V电源',
                    i152='外接音源接口',
                    i153='CD支持MP3/WMA',
                    i154='多媒体系统',
                    i155='扬声器品牌',
                    i156='扬声器数量',
                )
                light_map = dict(
                    i157='近光灯',
                    i158='远光灯',
                    i159='日间行车灯',
                    i160='自适应远近光',
                    i161='自动头灯',
                    i162='转向辅助灯',
                    i163='转向头灯',
                    i164='前雾灯',
                    i165='大灯高度可调',
                    i166='大灯清洗装置',
                    i167='车内氛围灯',
                )
                glass_map = dict(
                    i168='前/后电动车窗',
                    i169='车窗防夹手功能',
                    i170='防紫外线/隔热玻璃',
                    i171='后视镜电动调节',
                    i172='后视镜加热',
                    i173='内/外后视镜自动防眩目',
                    i174='后视镜电动折叠',
                    i175='后视镜记忆',
                    i176='后风挡遮阳帘',
                    i177='后排侧遮阳帘',
                    i178='后排侧隐私玻璃',
                    i179='遮阳板化妆镜',
                    i180='后雨刷',
                    i181='感应雨刷',
                )
                air_condition_map = dict(
                    i182='空调控制方式',
                    i183='后排独立空调',
                    i184='后座出风口',
                    i185='温度分区控制',
                    i186='车内空气调节/花粉过滤',
                    i187='车载冰箱',
                )
                tech_maps = dict(
                    i188='自动泊车入位',
                    i189='发动机启停技术',
                    i190='并线辅助',
                    i191='车道偏离预警系统',
                    i192='主动刹车/主动安全系统',
                    i193='整体主动转向系统',
                    i194='夜视系统',
                    i195='中控液晶屏分屏显示',
                    i196='自适应巡航',
                    i197='全景摄像头',
                )
                param_return = dict()
                basic_para = []
                for part in ['i1', 'i2', 'i3', 'i4', 'i5', 'i6', 'i7', 'i8',
                             'i9', 'i10', 'i11', 'i12', 'i13', 'i14', 'i15']:
                    if eval(part):
                        tem_dict = dict()
                        tem_dict[basic_para_map[part]] = eval(part)
                        basic_para.append(tem_dict)
                param_return['基本信息'] = basic_para
                car_body = []
                engine = []
                electric = []
                gear = []
                bottom = []
                brake = []
                safe = []
                handle = []
                outer = []
                inner = []
                chair = []
                video = []
                light = []
                glass = []
                air_condition = []
                tech = []
                for part in config:
                    tem_dict = dict()
                    if part in car_body_map:
                        tem_dict[car_body_map[part]] = \
                            self.strip_nbsp(config[part])
                        car_body.append(tem_dict)
                    elif part in engine_map:
                        tem_dict[engine_map[part]] = \
                            self.strip_nbsp(config[part])
                        engine.append(tem_dict)
                    elif part in gear_map:
                        tem_dict[gear_map[part]] = \
                            self.strip_nbsp(config[part])
                        gear.append(tem_dict)
                    elif part in electric_map:
                        tem_dict[electric_map[part]] = \
                            self.strip_nbsp(config[part])
                        electric.append(tem_dict)
                    elif part in bottom_map:
                        tem_dict[bottom_map[part]] = \
                            self.strip_nbsp(config[part])
                        bottom.append(tem_dict)
                    elif part in brake_map:
                        tem_dict[brake_map[part]] = \
                            self.strip_nbsp(config[part])
                        brake.append(tem_dict)
                    elif part in safe_map:
                        tem_dict[safe_map[part]] = \
                            self.strip_nbsp(config[part])
                        safe.append(tem_dict)
                    elif part in handle_map:
                        tem_dict[handle_map[part]] = \
                            self.strip_nbsp(config[part])
                        handle.append(tem_dict)
                    elif part in outer_map:
                        tem_dict[outer_map[part]] = \
                            self.strip_nbsp(config[part])
                        outer.append(tem_dict)
                    elif part in inner_map:
                        tem_dict[inner_map[part]] = \
                            self.strip_nbsp(config[part])
                        inner.append(tem_dict)
                    elif part in chair_map:
                        tem_dict[chair_map[part]] = \
                            self.strip_nbsp(config[part])
                        chair.append(tem_dict)
                    elif part in video_map:
                        tem_dict[video_map[part]] = \
                            self.strip_nbsp(config[part])
                        video.append(tem_dict)
                    elif part in light_map:
                        tem_dict[light_map[part]] = \
                            self.strip_nbsp(config[part])
                        light.append(tem_dict)
                    elif part in glass_map:
                        tem_dict[glass_map[part]] = \
                            self.strip_nbsp(config[part])
                        glass.append(tem_dict)
                    elif part in air_condition_map:
                        tem_dict[air_condition_map[part]] = \
                            self.strip_nbsp(config[part])
                        air_condition.append(tem_dict)
                    elif part in tech_maps:
                        tem_dict[tech_maps[part]] = \
                            self.strip_nbsp(config[part])
                        tech.append(tem_dict)
                if car_body:
                    param_return['车身'] = car_body
                if engine:
                    param_return['发动机'] = engine
                if electric:
                    param_return['电动机'] = electric
                if gear:
                    param_return['变速箱'] = gear
                if bottom:
                    param_return['底盘转向'] = bottom
                if brake:
                    param_return['车轮制动'] = brake
                if safe:
                    param_return['安全装备'] = safe
                if handle:
                    param_return['操控配置'] = handle
                if outer:
                    param_return['外部配置'] = outer
                if inner:
                    param_return['内部配置'] = inner
                if chair:
                    param_return['座椅配置'] = chair
                if video:
                    param_return['多媒体配置'] = video
                if light:
                    param_return['灯光配置'] = light
                if glass:
                    param_return['玻璃/后视镜'] = glass
                if air_condition:
                    param_return['空调/冰箱'] = air_condition
                if tech:
                    param_return['高科技配置'] = tech
                return self.render_json({'code': 200, 'results': param_return})
            else:
                param_return = dict()
                param_return['车身'] = {}
                param_return['发动机'] = {}
                param_return['电动机'] = {}
                param_return['变速箱'] = {}
                param_return['底盘转向'] = {}
                param_return['车轮制动'] = {}
                param_return['安全装备'] = {}
                param_return['操控配置'] = {}
                param_return['外部配置'] = {}
                param_return['内部配置'] = {}
                param_return['座椅配置'] = {}
                param_return['多媒体配置'] = {}
                param_return['灯光配置'] = {}
                param_return['玻璃/后视镜'] = {}
                param_return['空调/冰箱'] = {}
                param_return['高科技配置'] = {}
                return self.render_json({'code': 200, 'results': param_return})
