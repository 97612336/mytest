# coding=utf-8

from __future__ import absolute_import, print_function
from .basehandler import BaseHandler
import logging
import demjson


def __handlers(settings):
    return [
        (r"/v3B/saler/full/payment", FullPaymentHandler),
    ]


class FullPaymentHandler(BaseHandler):

    def _color_list(self, car_id):
        CarColor = self.model("car_color")
        this = self.db.specs.find_one({"id": car_id})
        if not this:
            return []
        series_id = this.series_id
        series_cars = self.db.specs.query(). \
            filter_by(series_id=series_id).all()
        series_car_ids = [car.id for car in series_cars]
        colors = self.db.car_color.query(). \
            filter(CarColor.car_id.in_(series_car_ids)).all()
        res_list = []
        for color in colors:
            tmp_dict = {}
            tmp_dict["id"] = color.id
            tmp_dict["name"] = color.name
            tmp_dict["color"] = color.color
            res_list.append(tmp_dict)
        return res_list

    def _wheel_list(self, car_id):
        CarWheels = self.model("car_wheels")
        this = self.db.specs.find_one({"id": car_id})
        if not this:
            return []
        series_id = this.series_id
        series_cars = self.db.specs.query().\
            filter_by(series_id=series_id).all()
        series_car_ids = [car.id for car in series_cars]
        wheels = self.db.car_wheels.query().\
            filter(CarWheels.car_id.in_(series_car_ids)).all()
        res_list = []
        for wheel in wheels:
            tmp_dict = {}
            tmp_dict["id"] = wheel.id
            tmp_dict["name"] = wheel.name
            tmp_dict["img"] = wheel.logo
            res_list.append(tmp_dict)
        return res_list

    def _spec_list(self, car_id):
        connection = self.get_afsaas_connection()
        with connection.cursor() as cursor:
            query_sql = 'select id,i1,i2 from specs where ' \
                        'series_id= ' \
                        '(select series_id from specs where id=%s)' % car_id
            cursor.execute(query_sql)
            query_list = cursor.fetchall()
        res_list = []
        for query in query_list:
            if not query.get('i2') or not query.get("i1"):
                continue
            prc = int(float(query.get('i2').
                                      split('~')[0].strip('万'))*100)*100
            if not prc:
                continue
            tmp_dict = dict()
            tmp_dict["id"] = query.get("id")
            tmp_dict["name"] = query.get("i1")
            tmp_dict["price"] = prc
            if query.get("id") == car_id:
                continue
            res_list.append(tmp_dict)
        this_car = self.db.specs.find_one({"id": car_id})
        this_price = int(float(this_car.guide_price.
                  split('~')[0].strip('万'))*100)*100
        this_car_info = dict(id=this_car.id,
                             name=this_car.name,
                             price=this_price)
        res_list.insert(0, this_car_info)
        return res_list

    def get(self):
        car_id = self.get_argument_int('car_id')
        price = self.get_argument('price', None)
        if car_id:
            specs = self._spec_list(car_id)
            connection = self.get_afsaas_connection()
            with connection.cursor() as cursor:
                query_sql = 'select i1, i2, config from specs where ' \
                            'id="%s"' % car_id
                cursor.execute(query_sql)
                query = cursor.fetchone()

            price = specs[0]["price"]
            car_name = specs[0]["name"]

            i3_cost = int(price * 0.1 / 1.17)  # 购置税
            i4_cost = 500  # 上牌费用
            i6_cost = 0  # 车船使用费
            config = demjson.decode(query.get('config', '{}'))
            try:
                i32 = float(config.get('i32', '0'))
            except Exception:
                i32 = 0
            if i32 <= 1.0:
                i6 = 0
                i6_cost = 300
            elif 1.0 < i32 <= 1.6:
                i6 = 1
                i6_cost = 420
            elif 1.6 < i32 <= 2.0:
                i6 = 2
                i6_cost = 480
            elif 2.5 >= i32 > 2.0:
                i6 = 3
                i6_cost = 900
            elif 3.0 >= i32 > 2.5:
                i6 = 4
                i6_cost = 1920
            elif 4.0 >= i32 > 3.0:
                i6 = 5
                i6_cost = 3480
            else:
                i6 = 6
                i6_cost = 5280
            i27_tem = config.get('i27', '0')
            i27_one = i27_tem.split('/')[0]
            try:
                i27 = int(i27_one)
            except Exception as e:
                logging.debug('process i27 error:%s', e)
                i27 = 0
            if i27 < 6:
                i5 = 0  # 交通强制保险
                i5_cost = 950
            else:
                i5 = 1
                i5_cost = 1100
            i2_cost = i3_cost + i4_cost + i5_cost + i6_cost  # 必要花费
            necessary = {'i1': int(price), 'i2': i2_cost,
                         'i3': i3_cost, 'i4': i4_cost, 'i5': [i5, [950, 1100]],
                         'i6': [i6, [300, 420, 480, 900, 1920, 3480, 5280]]}
            # 第三方责任险
            i8 = [516, 746, 924, 1252, 1630]
            i8_default = 0
            i8_cost = i8[i8_default]
            i9_cost = int(459 + price * 0.01088)  # 车辆损失险
            i9 = i9_cost
            i10_cost = int(102 + price * 0.00451)  # 全车盗抢险
            i10 = i10_cost
            # 玻璃单独破碎险
            i11 = [int(price * 0.25 / 100), int(price * 0.15 / 100)]
            i11_default = 1
            i11_cost = i11[i11_default]
            i12_cost = int(price * 0.0015)  # 自燃损失险
            i12 = i12_cost
            i13_cost = int((i9_cost + i8_cost) * 0.2)  # 不计免赔特约险
            i13 = i13_cost
            i14_cost = int(i8_cost * 0.2)  # 无过责任险
            i14 = i14_cost
            # 车上人员责任险
            i15 = [50, 100, 150, 200, 250, 300, 350]
            i15_default = 1
            i15_cost = i15[i15_default]
            if price < 300000:
                one = 400
                two = 570
                three = 760
                four = 1140
            elif 300000 <= price < 500000:
                one = 585
                two = 900
                three = 1170
                four = 1780
            else:
                one = 850
                two = 1100
                three = 1500
                four = 2250
            # 车身划痕险
            i16 = [one, two, three, four]
            i16_default = 1
            i16_cost = i16[i16_default]
            i7_cost = i8_cost + i9_cost + i10_cost + i11_cost + i12_cost + \
                      i13_cost + i14_cost + i15_cost + i16_cost
            i7 = i7_cost
            total_cost = i2_cost + i7_cost
            commercial = {'i7': i7,
                          'i8': [i8_default, i8],
                          'i9': i9, 'i10': i10,
                          'i11': [i11_default, i11],
                          'i12': i12, 'i13': i13, 'i14': i14,
                          'i15': [i15_default, i15],
                          'i16': [i16_default, i16]}
            wheels = self._wheel_list(car_id)
            colors = self._color_list(car_id)
            self.render_json({'code': 200,
                              'results': {'commercial': commercial,
                                          'necessary': necessary,
                                          'name': car_name,
                                          'total_cost': total_cost,
                                          'wheels': wheels,
                                          'colors': colors,
                                          'specs': specs
                                          }})
        elif price is not None:
            price = int(price)
            i3_cost = int(price * 0.1 / 1.17)  # 购置税
            i8 = self.get_argument_int('i8')
            i8_cost = 0
            if i8 == 0:
                i8_cost = 516
            elif i8 == 1:
                i8_cost = 746
            elif i8 == 2:
                i8_cost = 924
            elif i8 == 3:
                i8_cost = 1252
            elif i8 == 4:
                i8_cost = 1630
            i9_cost = int(459 + price * 0.01088)  # 车辆损失险
            i10_cost = int(102 + price * 0.00451)  # 全车盗抢险
            i11 = self.get_argument_int('i11')  # 玻璃单独破碎险
            i11_cost = 0
            if i11 == 0:
                i11_cost = int(price * 0.25 / 100)
            elif i11 == 1:
                i11_cost = int(price * 0.15 / 100)
            i11_list = [int(price * 0.25 / 100), int(price * 0.15 / 100)]
            i12_cost = int(price * 0.0015)  # 自燃损失险
            i13_cost = int((i9_cost + i8_cost) * 0.2)  # 不计免赔特约险
            i14_cost = int(i8_cost * 0.2)  # 无过责任险
            i16 = self.get_argument_int('i16')  # 车身划痕险
            i16_cost = 0
            if price < 300000:
                if i16 == 0:
                    i16_cost = 400
                elif i16 == 1:
                    i16_cost = 570
                elif i16 == 2:
                    i16_cost = 760
                elif i16 == 3:
                    i16_cost = 1140
                i16_list = [400, 570, 760, 1140]
            elif 300000 <= price < 500000:
                if i16 == 0:
                    i16_cost = 585
                elif i16 == 1:
                    i16_cost = 900
                elif i16 == 2:
                    i16_cost = 1170
                elif i16 == 3:
                    i16_cost = 1780
                i16_list = [585, 900, 1170, 1780]
            else:
                if i16 == 0:
                    i16_cost = 850
                elif i16 == 1:
                    i16_cost = 1100
                elif i16 == 2:
                    i16_cost = 1500
                elif i16 == 3:
                    i16_cost = 2250
                i16_list = [850, 1100, 1500, 2250]
            necessary = {'i3': i3_cost}
            commercial = {'i9': i9_cost, 'i10': i10_cost,
                          'i11': [i11, i11_list], 'i12': i12_cost,
                          'i13': i13_cost, 'i14': i14_cost,
                          'i16': [i16, i16_list]}
            self.render_json({'code': 200,
                              'results': {'commercial': commercial,
                                          'necessary': necessary}})


