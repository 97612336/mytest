# coding=utf-8

from __future__ import absolute_import, print_function
import basehandler
import os
import logging
from apis import func
import math
from tornado.escape import json_encode
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest)
from tornado.escape import json_decode
import datetime
from tornado.gen import coroutine


class BaseHandler(basehandler.BaseHandler):

	def prepare(self):
		super(BaseHandler, self).prepare()
		if hasattr(self, 'tokenpass'):
			if self.tokenpass:
				return
		tk = self.token
		logging.debug('parameter of token:%s', tk)
		if len(tk) < 1:
			logging.debug("no token argument")
			self.not_login()
			return

		if self.saler_id < 1:
			logging.debug("uid < 1")
			self.not_login()
			return
		# r = self.redis
		# key = self.ukey(self.saler_id)
		# token = r.hget(key, "token")
		saler_id = self.saler_id
		# if token != tk:
		# 	logging.debug("token changed %s => %s", tk, token)
		# 	self.not_login()
		# 	return
		self.session = dict()
		saler = self.db.salers.find_one({'id': saler_id})
		if saler:
			saler = saler.to_dict()
			self.session['Saler'] = saler

			saler_id = saler.get('id', 0)
			device_id = saler.get('device_id', 0)
			device = self.db.devices.find_one({'id': device_id})
			is_pay = saler.get('is_pay', 0)
			if is_pay != 1:
				self.render_json({'code': 403, 'msg': '您还未交费，请付款后重新登陆！'})
				self.finish()
			if device:
				expire_at = device.expire_at
				if expire_at:
					now = datetime.datetime.now()
					delta = (expire_at - now).days
					if delta < 0:
						self.render_json({'code': 201, 'msg': ' 账号已到期!'})
						self.finish()
						return
			redis = self.redis
			hkey = 'one:login:saler:id:{}'.format(saler_id)
			msid = self.token
			try:
				session_msid = redis.hget(hkey, 'msid')
			except Exception as e:
				logging.debug('error:%s', e)
			else:
				if session_msid == msid:
					pass
				else:
					del self.session['Saler']
					self.render_json({'code': 302,
									  'msg': '账号已在别处登录，请重新登录'})
					self.finish()
		else:
			self.not_login()
			return
