# coding=utf-8

from __future__ import absolute_import, print_function
from .basehandler import BaseHandler
import logging
import datetime
import os
from tornado.httputil import urlencode
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest, HTTPClient)
from tornado.escape import (json_encode, json_decode)
import tornado.gen
import qrcode
import json


def __handlers(settings):
    return [
        (r"/v5/saler/brands", V5SalerBrandHandler),
    ]


class V5SalerBrandHandler(BaseHandler):
    tokenpass = True
    def _get_banner(self):
        session = self.DB
        connection = self.get_afsaas_connection()
        with connection.cursor() as cursor:
            cursor.execute("select id,title,url,car_id,img_url "
                           "from cheyixiao.swiper where status=1")
            swipers = cursor.fetchall()
        results = []
        for sw in swipers:
            tmp_dict = dict()
            tmp_dict["id"] = sw["id"]
            tmp_dict["img_url"] = sw["img_url"]
            tmp_dict["car"] = None
            tmp_dict["url"] = None
            if sw["car_id"] and not sw["url"]:
                car_sql = "select name,look_way,bg from cheyixiao.specs where id=%s" % sw["car_id"]
                res_obj = session.execute(car_sql)
                car = res_obj.fetchone()
                tmp_dict["car"] = [sw["car_id"], car[0], car[1], car[2]]
            if sw["url"] and not sw["car_id"]:
                tmp_dict["url"] = sw["url"]
            if sw["url"] and sw["car_id"]:
                logging.debug('WARINING: id %s banner has double goal !'
                              , sw["id"])
                continue
            results.append(tmp_dict)
        return results

    def _get_hot_cars(self):
        connection = self.get_afsaas_connection()
        with connection.cursor() as cursor:
            cursor.execute(
                "select id,name,look_way,bg,logo from cheyixiao.specs where is_hot=1")
            res = cursor.fetchall()
        results = []
        for item in res:
            tmp_dict = dict()
            tmp_dict["car"] = [item["id"], item["name"], item["look_way"], item["bg"]]
            tmp_dict["img_url"] = item["logo"]
            results.append(tmp_dict)
        return results

    def get(self):
        session = self.DB()
        Brands = self.model('brands')
        DealerBrand = self.model('dealer_brand')
        dealer_id = self.session_saler_info('dealer_id', '')
        dealer_id = 5000
        brands = session.query(Brands, DealerBrand.onsell).join(
            DealerBrand, DealerBrand.brand_id == Brands.id).\
            filter(DealerBrand.dealer_id == dealer_id, Brands.status == 1).all()
        results = dict()
        open_list = []
        close_list = []
        for item in brands:
            brand = item[0]
            onsell = item[1]
            tem_list = []
            tem_list.append(brand.id)
            tem_list.append(brand.name)
            tem_list.append(brand.logo)
            if onsell == 1:
                if tem_list not in open_list:
                    open_list.append(tem_list)
            elif onsell == 0:
                if tem_list not in close_list:
                    close_list.append(tem_list)
        results['open'] = open_list
        results['close'] = close_list
        banner = self._get_banner()
        hot_cars = self._get_hot_cars()
        results['banner'] = banner
        results['hot_cars'] = hot_cars
        self.render_json({'code': 200, 'results': results})
