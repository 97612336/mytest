# coding=utf-8

from __future__ import absolute_import, print_function
from .basehandler import BaseHandler
import logging
import datetime
import os
from tornado.httputil import urlencode
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest, HTTPClient)
from tornado.escape import (json_encode, json_decode)
import tornado.gen
import qrcode
import json


def __handlers(settings):
    return [
        (r"/v3/saler/look/test", V3SalerLookHandler),
        (r"/v3/saler/brand/series", V3BrandSeriesHandler),
        (r"/v3/saler/expire/verify", ExpireVerifyHandler),
    ]


class V3SalerLookHandler(BaseHandler):

    def get(self):
        user_id = self.get_argument('uid', 0)
        car_id = self.get_argument('carid', 0)
        action = self.get_argument('action', '')
        avalue = self.get_argument('avalue', '')
        lon = self.get_argument('lon', '')
        lat = self.get_argument('lat', '')
        updated_at = self.get_argument('updated_at', '')
        created_at = self.get_argument('created_at', '')
        ip = self.get_argument('ip')
        saler_id = self.session_saler_info('id', 0)
        info = dict(user_id=user_id,
                    car_id=car_id,
                    action=action,
                    avalue=avalue,
                    saler_id=saler_id,
                    ip=ip,
                    lon=lon,
                    lat=lat,
                    updated_at=updated_at,
                    created_at=created_at)
        focus_car_info = {'user_id': user_id, 'car_id': car_id,
                          'saler_id': saler_id, 'is_test': 1}
        focus_car = self.db.focus_car.find_one(focus_car_info)
        if focus_car:
            pass
        else:
            self.db.focus_car.insert_one(focus_car_info)
        self.db.look.insert_one(info)

        hkey = 'count'
        look_num = self.redis.hget(hkey, key="look_num")
        new_look_num = ''
        try:
            new_look_num = int(look_num) + 1
        except Exception as e:
            pass
        self.redis.hmset("count", {"look_num": new_look_num})

        hkey2 = 'today_look'
        now = datetime.datetime.now()
        hour = int(str(now).split(' ')[1][0:2])
        num = self.redis.hget(hkey2, key=hour)
        if num:
            num = int(num)
        else:
            num = 0
        for h in range(6, 24):
            if h == hour:
                num += 1
        self.redis.hset(hkey2, hour, num)

        self.render_json({'code': 200, 'url_type': 'ok'})


class V3BrandSeriesHandler(BaseHandler):
    def get(self):
        brand_id = self.get_argument_int('brand_id')
        dealer_id = self.session_saler_info('dealer_id', '')
        session = self.DB()
        DealerSpec = self.model('dealer_spec')
        Series = self.model('series')
        Specs = self.model('specs')
        serial_id_query = session.query(Specs.series_id).\
            join(DealerSpec, DealerSpec.car_id == Specs.id).\
            filter(DealerSpec.dealer_id == dealer_id, DealerSpec.status == 2)
        series = session.query(Series).filter(
            Series.id.in_(serial_id_query), Series.brand_id == brand_id).all()
        results = []
        for item in series:
            tem_list = []
            tem_list.append(item.id)
            tem_list.append(item.name)
            tem_list.append(item.logo)
            resource_url = item.resource_url
            tem_list.append(resource_url)
            series_id = item.id
            specs = session.query(Specs).join(
                DealerSpec, DealerSpec.car_id == Specs.id).\
                filter(Specs.series_id == series_id,
                       DealerSpec.dealer_id == dealer_id).all()
            spec_list = []
            for spec in specs:
                tem_list1 = []
                tem_list1.append(spec.id)
                tem_list1.append(spec.name)
                tem_list1.append(spec.look_way)
                tem_list1.append(spec.bg)
                spec_list.append(tem_list1)
            tem_list.append(spec_list)
            results.append(tem_list)
        self.render_json({'code': 200, 'results': results})


class ExpireVerifyHandler(BaseHandler):
    def not_login(self):
        self.render_json({'code': 403, 'msg': '您还没登录', 'url_type': 'ok'})
        self.finish()
        return

    def get(self):
        saler_id = self.saler_id
        saler_obj = self.db.salers.find_one({"id": saler_id})
        cert_code = saler_obj.cert_code
        role = saler_obj.role
        ip = self.request.remote_ip
        style = 2
        login_info = dict(saler_id=saler_id,
                          ip=ip,
                          style=style)
        try:
            self.db.login_record.insert_one(login_info)
        except Exception as e:
            logging.debug("error:%s", e)
        self.render_json({'code': 200, 'url_type': 'ok',
                          "cert_code": cert_code, "role": role})
