# coding=utf-8

from __future__ import absolute_import, print_function
from .basehandler import BaseHandler
import logging
import datetime
import os
from tornado.httputil import urlencode
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest, HTTPClient)
from tornado.escape import (json_encode, json_decode)
import tornado.gen
import qrcode
import json


def __handlers(settings):
	return [
		(r"/v2/saler/brands", SalerBrandHandler),
		(r"/v2/saler/brand/series", BrandSeriesHandler),
	]


class SalerBrandHandler(BaseHandler):
	def get(self):
		session = self.DB()
		Brands = self.model('brands')
		DealerBrand = self.model('dealer_brand')
		dealer_id = self.session_saler_info('dealer_id', '')
		brands = session.query(Brands, DealerBrand.onsell).join(
			DealerBrand, DealerBrand.brand_id == Brands.id).\
			filter(DealerBrand.dealer_id == dealer_id, Brands.status == 1).all()
		results = dict()
		open_list = []
		close_list = []
		for item in brands:
			brand = item[0]
			onsell = item[1]
			tem_list = []
			tem_list.append(brand.id)
			tem_list.append(brand.name)
			tem_list.append(brand.logo)
			if onsell == 1:
				if tem_list not in open_list:
					open_list.append(tem_list)
			elif onsell == 0:
				if tem_list not in close_list:
					close_list.append(tem_list)
		results['open'] = open_list
		results['close'] = close_list
		self.render_json({'code': 200, 'results': results})


class BrandSeriesHandler(BaseHandler):
	def get(self):
		brand_id = self.get_argument_int('brand_id')
		dealer_id = self.session_saler_info('dealer_id', '')
		session = self.DB()
		DealerSpec = self.model('dealer_spec')
		Series = self.model('series')
		Specs = self.model('specs')
		serial_id_query = session.query(Specs.series_id).\
			join(DealerSpec, DealerSpec.car_id == Specs.id).\
			filter(DealerSpec.dealer_id == dealer_id, DealerSpec.status == 2)
		series = session.query(Series).filter(
			Series.id.in_(serial_id_query), Series.brand_id == brand_id).all()
		results = []
		for item in series:
			tem_list = []
			tem_list.append(item.id)
			tem_list.append(item.name)
			tem_list.append(item.logo)
			resource_url = item.resource_url
			tem_list.append(resource_url)
			series_id = item.id
			specs = session.query(Specs).join(
				DealerSpec, DealerSpec.car_id == Specs.id).\
				filter(Specs.series_id == series_id,
					   DealerSpec.dealer_id == dealer_id).all()
			spec_list = []
			for spec in specs:
				tem_list1 = []
				tem_list1.append(spec.id)
				tem_list1.append(spec.name)
				spec_list.append(tem_list1)
			if resource_url.startswith('https://cheyixiao.autoforce.net/'):
				file_suffix_dir = \
					resource_url.split('https://cheyixiao.autoforce.net/')[1]
				file_dir = os.path.join(file_suffix_dir, 'config/count.json')
				if os.path.exists(file_dir):
					counts = json.load(open(file_dir, 'r'))
				else:
					counts = ''
			else:
				counts = ''
			tem_list.append(spec_list)
			tem_list.append(counts)
			results.append(tem_list)
		self.render_json({'code': 200, 'results': results})

