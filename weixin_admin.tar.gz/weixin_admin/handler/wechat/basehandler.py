from __future__ import absolute_import, print_function
import basehandler
import os
import logging
from apis import func
import math
from tornado.escape import json_encode
import datetime
import pymysql.cursors
import configparser
from tornado.gen import coroutine
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest)
from tornado.escape import json_decode


class BaseHandler(basehandler.BaseHandler):
	def prepare(self):
		super(BaseHandler, self).prepare()

	@coroutine
	def get_openid(self, code):
		appid = os.getenv('CheXiaoYiAppID', '')
		secret = os.getenv('CheXiaoYiAppSecret')
		openid_url = 'https://api.weixin.qq.com/sns/oauth2/access_token?' \
					 'appid={}&secret={}&code={}&grant_type=' \
					 'authorization_code'.format(appid, secret, code)
		request = HTTPRequest(
			url=openid_url,
			method='GET',
			connect_timeout=60,
			request_timeout=60,
		)
		client = AsyncHTTPClient()
		response = yield client.fetch(request)
		if response.error:
			logging.debug('access_token response.error:%s',
						  response.error)
			return None
		else:
			body = json_decode(response.body)
			logging.debug("body:%s", body)
			openid = body.get('openid', '')
			return openid

	def reply_text(self, FromUserName, ToUserName, CreateTime, Content):
		"""回复文本消息模板"""
		textTpl = """
		<xml> 
		<ToUserName><![CDATA[%s]]></ToUserName> 
		<FromUserName><![CDATA[%s]]></FromUserName> 
		<CreateTime>%s</CreateTime> 
		<MsgType><![CDATA[%s]]></MsgType> 
		<Content><![CDATA[%s]]></Content>
		</xml>
		"""
		out = textTpl % (FromUserName, ToUserName, CreateTime, 'text', Content)
		self.write(out)

	@property
	def get_from_user_name(self):
		return 'gh_23636d052c49'

	def price_int2str(self, price):
		price = str(price)
		if price:
			len_total_cost = len(price)
			num = 0
			tem_list = []
			for index in range(len_total_cost - 1, -1, -1):
				num += 1
				tem_list.insert(0, price[index])
				if num % 3 == 0:
					tem_list.insert(0, ',')
			total_cost = ''.join(tem_list).strip(',')
			result = '￥ ' + total_cost
			return result
		else:
			return ''