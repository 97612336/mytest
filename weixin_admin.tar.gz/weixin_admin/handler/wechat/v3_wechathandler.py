# coding=utf-8

from __future__ import absolute_import, print_function
from .basehandler import BaseHandler
import logging
import hashlib
import xml.etree.ElementTree as ET
import os
import time
from tornado.escape import json_decode
import tornado.gen
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest)
import ssl
from Crypto.Cipher import AES
from binascii import a2b_hex
import datetime
import qrcode
import base64
import re
import random
from tornado.httputil import urlencode
try:

	from StringIO import StringIO
except ImportError:
	from io import BytesIO as StringIO


def __handlers(settings):
	return [
		(r"/v3/wx/payment/notice", WechatPaymentNoticeHandler),
		# (r"/v3/wx/pay/refund", WechatPayRefund),
		(r"/v3/wx/pay/refund/notice", WechatPayRefundNotice),
		(r"/v3/wx/register/payment", SalerRegisterPayQrcodeUrlHandler),
		(r"/v3/wx/register/pay/notice", WechatRegisterPayNoticeHandler),
		(r"/v3/wx/signature", WechatSignatureHandler)
	]


class WechatPaymentNoticeHandler(BaseHandler):
	def check_xsrf_cookie(self):
		pass

	def post(self):
		body = self.request.body
		logging.debug('result_body:%s', body)
		data = ET.fromstring(body)
		params = dict()
		return_code = data.find('return_code').text
		if return_code == 'SUCCESS':
			result_code = data.find('result_code').text
			if result_code == 'SUCCESS':
				params['return_code'] = return_code
				params['result_code'] = result_code
				appid = data.find('appid').text
				mch_id = data.find('mch_id').text
				device_info = data.find('device_info').text
				nonce_str = data.find('nonce_str').text
				params['appid'] = appid
				params['mch_id'] = mch_id
				params['device_info'] = device_info
				params['nonce_str'] = nonce_str
				sign = data.find('sign').text
				if data.find('sign_type') is not None:
					sign_type = data.find('sign_type').text
					params['sign_type'] = sign_type
				else:
					sign_type = None
				if data.find('err_code') is not None:
					err_code = data.find('err_code').text
					params['err_code'] = err_code
				else:
					err_code = None
				if data.find('err_code_des') is not None:
					err_code_des = data.find('err_code_des').text
					params['err_code_des'] = err_code_des
				else:
					err_code_des = None
				if data.find('openid') is not None:
					openid = data.find('openid').text
					params['openid'] = openid
				else:
					openid = None
				if data.find('is_subscribe') is not None:
					is_subscribe = data.find('is_subscribe').text
					params['is_subscribe'] = is_subscribe
				else:
					is_subscribe = None
				if data.find('trade_type') is not None:
					trade_type = data.find('trade_type').text
					params['trade_type'] = trade_type
				else:
					trade_type = None
				if data.find('bank_type') is not None:
					bank_type = data.find('bank_type').text
					params['bank_type'] = bank_type
				else:
					bank_type = None
				if data.find('total_fee') is not None:
					total_fee = data.find('total_fee').text
					params['total_fee'] = total_fee
				else:
					total_fee = None
				if data.find('settlement_total_fee') is not None:
					settlement_total_fee = data.find('settlement_total_fee').text
					params['settlement_total_fee'] = settlement_total_fee
				else:
					settlement_total_fee = None
				if data.find('fee_type') is not None:
					fee_type = data.find('fee_type').text
					params['fee_type'] = fee_type
				else:
					fee_type = None
				if data.find('cash_fee') is not None:
					cash_fee = data.find('cash_fee').text
					params['cash_fee'] = cash_fee
				else:
					cash_fee = None
				if data.find('cash_fee_type') is not None:
					cash_fee_type = data.find('cash_fee_type').text
					params['cash_fee_type'] = cash_fee_type
				else:
					cash_fee_type = None
				if data.find('coupon_fee') is not None:
					coupon_fee = data.find('coupon_fee').text
					params['coupon_fee'] = coupon_fee
				else:
					coupon_fee = None
				if data.find('transaction_id') is not None:
					transaction_id = data.find('transaction_id').text
					params['transaction_id'] = transaction_id
				else:
					transaction_id = None
				if data.find('out_trade_no') is not None:
					out_trade_no = data.find('out_trade_no').text
					params['out_trade_no'] = out_trade_no
				else:
					out_trade_no = None
				if data.find('attach') is not None:
					attach = data.find('attach').text
					params['attach'] = attach
				else:
					attach = None
				if data.find('time_end') is not None:
					time_end = data.find('time_end').text
					params['time_end'] = time_end
				else:
					time_end = None
				sign_need = self.get_wx_pay_sign(params)
				if sign_need == sign:
					query = {'out_trade_no': out_trade_no}
					info = dict(
						openid=openid,
						bank_type=bank_type,
						transaction_id=transaction_id,
						time_end=time_end
					)
					Unifiedorder = self.model('unifiedorder')
					session = self.DB
					res = session.query(Unifiedorder).filter(Unifiedorder.out_trade_no == out_trade_no).first()
					if res:
						old_total_fee = res.total_fee
						if int(old_total_fee) == int(total_fee):
							self.db.unifiedorder.find_one_and_update(query, {'$set': info})
							session = self.DB
							Unifiedorder = self.model('unifiedorder')
							obj = session.query(Unifiedorder.bill_id).\
								filter(Unifiedorder.out_trade_no == out_trade_no).first()
							if obj:
								bill_id = obj.bill_id
								bill = self.db.bills.find_one({'id': bill_id})
								user_id = bill.user_id
								saler_id = bill.saler_id
								bill_query = {'id': bill_id}
								bill_info = {'order_fee': total_fee}
								try:
									self.db.bills.find_one_and_update(bill_query, {'$set': bill_info})
								except Exception as e:
									pass
								bill_query_test = {'id': bill_id, 'is_test': 1}
								bill_info_test = {'openid': openid}
								try:
									self.db.bills.find_one_and_update(bill_query_test, {'$set': bill_info_test})
								except Exception as e:
									pass
								us_query = dict(user_id=user_id, saler_id=saler_id)
								us_info = {'status': 2}
								try:
									self.db.user_status.find_one_and_update(us_query, {'$set': us_info})
								except Exception:
									pass
							success_xml = '''
							<xml>
							<return_code><![CDATA[SUCCESS]]></return_code>
							<return_msg><![CDATA[OK]]></return_msg>
							</xml>
							'''
							self.write(success_xml)
				return
		fail_xml = '''
		<xml>
		<return_code><![CDATA[FAIL]]></return_code>
		</xml>
		'''
		self.write(fail_xml)


class WechatPayRefund(BaseHandler):
	def check_xsrf_cookie(self):
		pass

	@tornado.gen.coroutine
	def post(self):
		bill_id = self.get_argument_int('bill_id')
		saler_id = self.get_argument_int('saler_id')
		Unifiedorder = self.model('unifiedorder')
		session = self.DB
		unifiedorder = None
		transaction_id = None
		out_trade_no = None
		if bill_id:
			unifiedorder = session.query(Unifiedorder).\
				filter(Unifiedorder.bill_id == bill_id, ~Unifiedorder.transaction_id.is_(None)).first()
		elif saler_id:
			unifiedorder = session.query(Unifiedorder). \
				filter(Unifiedorder.saler_id == saler_id, ~Unifiedorder.transaction_id.is_(None),
					   Unifiedorder.pay_type == 1, ~Unifiedorder.time_end.is_(None)).\
				order_by(Unifiedorder.id.desc()).first()
		if unifiedorder:
			total_fee = unifiedorder.total_fee
			transaction_id = unifiedorder.transaction_id
			refund_fee = total_fee
		else:
			out_trade_no = self.get_argument('out_trade_no', '')
			total_fee_get = self.get_argument_int('total_fee', 1)
			refund_fee_get = self.get_argument_int('refund_fee', 1)
			if out_trade_no:
				total_fee = total_fee_get
				refund_fee = refund_fee_get
			else:
				self.render_json({'code': 406, 'msg': "参数有误！"})
				return

		appid = os.getenv('CheXiaoYiAppID', '')
		mch_id = os.getenv('CheXiaoYiMchId', '')
		nonce_str = self.get_wx_pay_nonce_str()
		out_refund_no = str(int(time.time())) + '_' + str(bill_id)
		notify_url = 'https://cheyixiao.autoforce.net/v3/wx/pay/refund/notice'
		if transaction_id:
			params = dict(
				total_fee=total_fee,
				transaction_id=transaction_id,
				appid=appid,
				mch_id=mch_id,
				nonce_str=nonce_str,
				out_refund_no=out_refund_no,
				notify_url=notify_url,
				refund_fee=refund_fee
				)
		elif out_trade_no:
			params = dict(
				total_fee=total_fee,
				out_trade_no=out_trade_no,
				appid=appid,
				mch_id=mch_id,
				nonce_str=nonce_str,
				out_refund_no=out_refund_no,
				notify_url=notify_url,
				refund_fee=refund_fee
			)
		else:
			return
		sign = self.get_wx_pay_sign(params)
		params['sign'] = sign
		url = 'https://api.mch.weixin.qq.com/secapi/pay/refund'
		headers = {"content-type": "text/xml"}
		data = '<xml>'
		for key, value in params.items():
			data = '%s<%s>%s</%s>' % (data, key, value, key)
		data = '%s</xml>' % data
		logging.debug('data:%s', data)
		cwd = os.getcwd()
		cert_path = os.path.join(cwd, 'static/wx_cert/apiclient_cert.pem')
		key_path = os.path.join(cwd, 'static/wx_cert/apiclient_key.pem')
		context = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
		context.check_hostname = False
		context.load_cert_chain(certfile=cert_path, keyfile=key_path)

		request = HTTPRequest(
			url=url,
			method='POST',
			headers=headers,
			body=data.encode('utf-8'),
			connect_timeout=60,
			request_timeout=60,
			ssl_options=context
		)
		client = AsyncHTTPClient()
		try:
			response = yield client.fetch(request)
		except Exception as e:
			logging.debug('error:%s', e)
		else:
			if response.error:
				logging.debug('request 退款接口出错:%s', response.error)
				return None
			else:
				body = response.body.decode('utf-8')
				logging.debug('body:%s', body)
				data = self.xmlToDict(body)
				return_code = data.get('return_code', None)
				logging.debug('return_code:%s', return_code)
				if return_code == 'SUCCESS':
					result_code = data.get('result_code')
					if result_code == 'SUCCESS':
						self.render_json({'code': 200, 'msg': '申请退款已成功！'})
						return
				self.render_json({'code': 500, 'msg': '申请退款失败,请检查退款金额是否大于未退款金额！'})


class WechatPayRefundNotice(BaseHandler):
	def check_xsrf_cookie(self):
		pass

	def post(self):
		body = self.request.body
		data = self.xmlToDict(body)
		return_code = data.get('return_code', '')
		if return_code == 'SUCCESS':
			req_info = data.get('req_info', '')
			b64_req_info = base64.b64decode(req_info)
			mch_key = os.getenv('CheXiaoYiMchKey', '')
			md5_mch_key = hashlib.md5(mch_key.encode('utf-8')).hexdigest()
			try:
				cryptor = AES.new(md5_mch_key, AES.MODE_ECB)
			except Exception as e:
				cryptor = AES.new(md5_mch_key.encode('utf-8'), AES.MODE_ECB)
			plain_text = cryptor.decrypt(b64_req_info)
			plain_data1 = plain_text.decode('utf-8')
			plain_data2 = re.sub(u"[\x00-\x08\x0b-\x0c\x0e-\x1f]+", u"", plain_data1)
			plain_data = self.xmlToDict(plain_data2)
			transaction_id = plain_data.get('transaction_id', '')
			out_trade_no = plain_data.get('out_trade_no', '')
			refund_id = plain_data.get('refund_id', '')
			out_refund_no = plain_data.get('out_refund_no', '')
			total_fee = plain_data.get('total_fee', '')
			refund_fee = plain_data.get('refund_fee', '')
			refund_status = plain_data.get('refund_status', '')
			success_time = plain_data.get('success_time', '')
			refund_recv_accout = plain_data.get('refund_recv_accout', '')
			refund_account = plain_data.get('refund_account', '')
			refund_request_source = plain_data.get('refund_request_source', '')
			info = dict(transaction_id=transaction_id,
						out_trade_no=out_trade_no,
						refund_id=refund_id,
						out_refund_no=out_refund_no,
						total_fee=total_fee,
						refund_fee=refund_fee,
						refund_status=refund_status,
						success_time=success_time,
						refund_recv_account=refund_recv_accout,
						refund_account=refund_account,
						refund_request_source=refund_request_source)
			try:
				self.db.wechat_refund.insert_one(info)
			except Exception as e:
				logging.debug('insert into wechat_refund error:%s', e)
			success_xml = '''
				<xml>
				<return_code><![CDATA[SUCCESS]]></return_code>
				<return_msg><![CDATA[OK]]></return_msg>
				</xml>
				'''
			self.write(success_xml)
			return

		fail_xml = '''
				<xml>
				<return_code><![CDATA[FAIL]]></return_code>
				</xml>
				'''
		self.write(fail_xml)


class SalerRegisterPayQrcodeUrlHandler(BaseHandler):

	@tornado.gen.coroutine
	def get(self):
		saler_id = self.get_argument_int('saler_id')
		session = self.DB
		Salers = self.model("salers")
		saler = session.query(Salers).filter(Salers.id == saler_id).first()
		if saler:
			appid = os.getenv('CheXiaoYiAppID', '')
			mch_id = os.getenv('CheXiaoYiMchId', '')
			device_info = "WEB"
			nonce_str = self.get_wx_pay_nonce_str()
			username = session.query(Salers.username).filter(Salers.id == saler_id).scalar()
			body = username + ' 支付注册费用 ' + '(车易销)'
			total_fee = 288800
			ip = os.getenv('CheXiaoYiServerIp', '114.240.58.31')
			spbill_create_ip = ip
			notify_url = 'https://cheyixiao.autoforce.net/v3/wx/register/pay/notice'
			trade_type = 'NATIVE'
			out_trade_no = str(int(time.time())) + '_' + str(saler_id)
			product_id = out_trade_no
			time_start = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
			time_expire_temp = datetime.datetime.now() + datetime.timedelta(minutes=5)
			time_expire = time_expire_temp.strftime('%Y%m%d%H%M%S')
			params = dict(
				appid=appid,
				mch_id=mch_id,
				device_info=device_info,
				nonce_str=nonce_str,
				body=body,
				total_fee=total_fee,
				spbill_create_ip=spbill_create_ip,
				notify_url=notify_url,
				trade_type=trade_type,
				out_trade_no=out_trade_no,
				product_id=product_id,
				time_start=time_start,
				time_expire=time_expire
			)
			sign = self.get_wx_pay_sign(params)
			params['sign'] = sign
			url = 'https://api.mch.weixin.qq.com/pay/unifiedorder'
			headers = {"content-type": "text/xml"}
			data = '<xml>'
			for key, value in params.items():
				data = '%s<%s>%s</%s>' % (data, key, value, key)
			data = '%s</xml>' % data
			logging.debug('data:%s', data)
			request = HTTPRequest(
				url=url,
				method='POST',
				headers=headers,
				body=data.encode('utf-8'),
				connect_timeout=60,
				request_timeout=60,
			)
			client = AsyncHTTPClient()
			response = yield client.fetch(request)
			if response.error:
				logging.debug('request 统一下单接口出错:%s', response.error)
				return None
			else:
				body = response.body.decode('utf-8')
				logging.debug('body:%s', body)
				data = ET.fromstring(body)
				return_code = data.find('return_code').text
				if return_code == 'SUCCESS':
					trade_type = data.find('trade_type').text
					prepay_id = data.find('prepay_id').text
					code_url = data.find('code_url').text
					unifiedorder_info = dict(
						saler_id=saler_id,
						prepay_id=prepay_id,
						device_info=device_info,
						trade_type=trade_type,
						out_trade_no=out_trade_no,
						product_id=product_id,
						time_start=time_start,
						time_expire=time_expire,
						total_fee=total_fee,
						code_url=code_url,
						pay_type=1
					)
					try:
						self.db.unifiedorder.insert_one(unifiedorder_info)
					except Exception as e:
						logging.debug('insert into unifiedorder error:%s', e)
					else:
						qr = qrcode.QRCode(
							version=1,
							error_correction=qrcode.constants.ERROR_CORRECT_L,
							box_size=10,
							border=4,
						)
						qr.add_data(code_url)
						qr.make(fit=True)
						img = qr.make_image()
						mstream = StringIO()
						img.save(mstream, 'PNG')
						self.set_header('Content-Type', 'image/png')
						self.write(mstream.getvalue())


class WechatRegisterPayNoticeHandler(BaseHandler):
	def check_xsrf_cookie(self):
		pass

	def post(self):
		body = self.request.body
		logging.debug('result_body:%s', body)
		data = ET.fromstring(body)
		params = dict()
		return_code = data.find('return_code').text
		if return_code == 'SUCCESS':
			result_code = data.find('result_code').text
			if result_code == 'SUCCESS':
				params['return_code'] = return_code
				params['result_code'] = result_code
				appid = data.find('appid').text
				mch_id = data.find('mch_id').text
				device_info = data.find('device_info').text
				nonce_str = data.find('nonce_str').text
				params['appid'] = appid
				params['mch_id'] = mch_id
				params['device_info'] = device_info
				params['nonce_str'] = nonce_str
				sign = data.find('sign').text
				if data.find('sign_type') is not None:
					sign_type = data.find('sign_type').text
					params['sign_type'] = sign_type
				else:
					sign_type = None
				if data.find('err_code') is not None:
					err_code = data.find('err_code').text
					params['err_code'] = err_code
				else:
					err_code = None
				if data.find('err_code_des') is not None:
					err_code_des = data.find('err_code_des').text
					params['err_code_des'] = err_code_des
				else:
					err_code_des = None
				if data.find('openid') is not None:
					openid = data.find('openid').text
					params['openid'] = openid
				else:
					openid = None
				if data.find('is_subscribe') is not None:
					is_subscribe = data.find('is_subscribe').text
					params['is_subscribe'] = is_subscribe
				else:
					is_subscribe = None
				if data.find('trade_type') is not None:
					trade_type = data.find('trade_type').text
					params['trade_type'] = trade_type
				else:
					trade_type = None
				if data.find('bank_type') is not None:
					bank_type = data.find('bank_type').text
					params['bank_type'] = bank_type
				else:
					bank_type = None
				if data.find('total_fee') is not None:
					total_fee = data.find('total_fee').text
					params['total_fee'] = total_fee
				else:
					total_fee = None
				if data.find('settlement_total_fee') is not None:
					settlement_total_fee = data.find('settlement_total_fee').text
					params['settlement_total_fee'] = settlement_total_fee
				else:
					settlement_total_fee = None
				if data.find('fee_type') is not None:
					fee_type = data.find('fee_type').text
					params['fee_type'] = fee_type
				else:
					fee_type = None
				if data.find('cash_fee') is not None:
					cash_fee = data.find('cash_fee').text
					params['cash_fee'] = cash_fee
				else:
					cash_fee = None
				if data.find('cash_fee_type') is not None:
					cash_fee_type = data.find('cash_fee_type').text
					params['cash_fee_type'] = cash_fee_type
				else:
					cash_fee_type = None
				if data.find('coupon_fee') is not None:
					coupon_fee = data.find('coupon_fee').text
					params['coupon_fee'] = coupon_fee
				else:
					coupon_fee = None
				if data.find('transaction_id') is not None:
					transaction_id = data.find('transaction_id').text
					params['transaction_id'] = transaction_id
				else:
					transaction_id = None
				if data.find('out_trade_no') is not None:
					out_trade_no = data.find('out_trade_no').text
					params['out_trade_no'] = out_trade_no
				else:
					out_trade_no = None
				if data.find('attach') is not None:
					attach = data.find('attach').text
					params['attach'] = attach
				else:
					attach = None
				if data.find('time_end') is not None:
					time_end = data.find('time_end').text
					params['time_end'] = time_end
				else:
					time_end = None
				sign_need = self.get_wx_pay_sign(params)
				if sign_need == sign:
					query = {'out_trade_no': out_trade_no}
					info = dict(
						openid=openid,
						bank_type=bank_type,
						transaction_id=transaction_id,
						time_end=time_end
					)
					Unifiedorder = self.model('unifiedorder')
					Brands = self.model('brands')
					Salers = self.model('salers')
					session = self.DB
					res = session.query(Unifiedorder).filter(Unifiedorder.out_trade_no == out_trade_no).first()
					if res:
						old_total_fee = res.total_fee
						if int(old_total_fee) == int(total_fee):
							self.db.unifiedorder.find_one_and_update(query, {'$set': info})
							session = self.DB
							Unifiedorder = self.model('unifiedorder')
							obj = session.query(Unifiedorder.saler_id).\
								filter(Unifiedorder.out_trade_no == out_trade_no, Unifiedorder.pay_type == 1).first()
							if obj:
								saler_id = obj.saler_id
								saler_info = dict(is_pay=1)
								try:
									self.db.salers.find_one_and_update({'id': saler_id}, {'$set': saler_info})
								except Exception:
									pass
								# brand_id_list = session.query(Brands.id).filter(Brands.status == 1).all()
								# dealer_id = session.query(Salers.dealer_id).filter(Salers.id == saler_id).scalar()
								# if dealer_id:
								# 	for item in brand_id_list:
								# 		brand_id = item[0]
								# 		info = dict(dealer_id=dealer_id, brand_id=brand_id)
								# 		try:
								# 			dealer_brand = self.db.dealer_brand.find_one(info)
								# 			if not dealer_brand:
								# 				self.db.dealer_brand.insert_one(info)
								# 		except Exception as e:
								# 			logging.debug("error:%s", e)
							success_xml = '''
							<xml>
							<return_code><![CDATA[SUCCESS]]></return_code>
							<return_msg><![CDATA[OK]]></return_msg>
							</xml>
							'''
							self.write(success_xml)
				return
		fail_xml = '''
		<xml>
		<return_code><![CDATA[FAIL]]></return_code>
		</xml>
		'''
		self.write(fail_xml)


class WechatSignatureHandler(BaseHandler):

	@tornado.gen.coroutine
	def get(self):
		redis = self.redis
		url = self.get_argument("url", "")
		secret = os.getenv('CheXiaoYiAppSecret', '')
		appid = os.getenv('CheXiaoYiAppID', '')
		access_token_url = 'https://api.weixin.qq.com/cgi-bin/token?' + \
						   urlencode({'grant_type': "client_credential",
									  "appid": appid, "secret": secret})
		client = AsyncHTTPClient()
		access_token_cache_key = 'cheyixiao:Wechat:Signature:Access_token'
		jsapi_ticket_cache_key = 'cheyixiao:Wechat:Signature:Jsapi_ticket'
		access_token_cache = redis.get(access_token_cache_key)
		jsapi_ticket_cache = redis.get(jsapi_ticket_cache_key)
		if access_token_cache and access_token_cache != 'None':
			if not jsapi_ticket_cache or jsapi_ticket_cache == 'None':
				jsapi_ticket_url = \
					'https://api.weixin.qq.com/cgi-bin/ticket/getticket?' \
					+ urlencode({"access_token": access_token_cache,
								 "type": "jsapi"})
				jsapi_ticket_response = yield client.fetch(jsapi_ticket_url)
				if jsapi_ticket_response.error:
					logging.debug("jsapi_ticket_response error:%s",
								  jsapi_ticket_response.error)
					return
				else:
					body = json_decode(jsapi_ticket_response.body)
					jsapi_ticket = body.get("ticket", None)
					self.redis.setex(jsapi_ticket_cache_key, 7200,
									 jsapi_ticket)
			else:
				jsapi_ticket = jsapi_ticket_cache
		else:
			access_token_response = yield client.fetch(access_token_url)
			if access_token_response.error:
				logging.debug('access_token response.error:%s',
							  access_token_response.error)
				return
			else:
				body = json_decode(access_token_response.body)
				access_token = body.get('access_token')
				self.redis.setex(access_token_cache_key, 7200,
								 access_token)
				if not jsapi_ticket_cache or jsapi_ticket_cache == 'None':
					jsapi_ticket_url = \
						'https://api.weixin.qq.com/cgi-bin/ticket/getticket?' \
						+ urlencode({"access_token": access_token,
									 "type": "jsapi"})
					jsapi_ticket_response = \
						yield client.fetch(jsapi_ticket_url)
					if jsapi_ticket_response.error:
						logging.debug("jsapi_ticket_response error:%s",
									  jsapi_ticket_response.error)
						return
					else:
						body = json_decode(jsapi_ticket_response.body)
						jsapi_ticket = body.get("ticket")
						self.redis.setex(jsapi_ticket_cache_key, 7200,
										 jsapi_ticket)
				else:
					jsapi_ticket = jsapi_ticket_cache
		seed = "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
		nonce_list = []
		for i in range(16):
			nonce_list.append(random.choice(seed))
		noncestr = ''.join(nonce_list)
		timestamp = int(time.time())
		string1 = 'jsapi_ticket={}&noncestr={}&timestamp={}&url={}'.\
			format(jsapi_ticket, noncestr, timestamp, url)
		signature = hashlib.sha1(string1.encode('utf-8')).hexdigest()
		self.render_json({'code': 200, "appid": appid, "timestamp": timestamp,
							  "nonceStr": noncestr, "signature": signature})