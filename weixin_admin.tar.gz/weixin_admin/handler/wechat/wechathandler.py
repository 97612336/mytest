# coding=utf-8

from __future__ import absolute_import, print_function

from urllib.request import urlopen

from app import redis

from .basehandler import BaseHandler
import logging
import hashlib
import xml.etree.ElementTree as ET
import os
import time
from tornado.escape import json_decode
import tornado.gen


def __handlers(settings):
	return [
		(r"/wx", WechatVerifyHandler),
		(r"/v1/wx/bill", WechatBillHandler),
		(r"/v1/wx/user/bind", WechatDealerBindHandler),
		(r"/v1/wx/car/config", WechatCarConfigHandler),
		(r"/v1/wx/dealers/home", WechatDealersHomeHandler),
		(r"/v1/wx/dealers/query", WechatDealersQueryHandler),
		(r"/v1/wx/dealers/city", WechatDealersCityHandler),
		(r"/v1/wx/dealers/province", WechatDealersProvinceHandler),
		(r"/v1/wx/dealers/brand", WechatDealersBrandHandler),
	]


class WechatVerifyHandler(BaseHandler):
	def check_xsrf_cookie(self):
		pass

	def get(self):
		try:
			signature = self.get_argument('signature')
			timestamp = self.get_argument('timestamp')
			nonce = self.get_argument('nonce')
			echostr = self.get_argument('echostr')
			logging.debug(
				'微信sign校验,signature=' + signature + ',&timestamp=' +
				timestamp + '&nonce=' + nonce + '&echostr=' + echostr)
			result = self.check_signature(signature, timestamp, nonce)
			if result:
				logging.debug('微信sign校验,返回echostr=' + echostr)
				self.write(echostr)
			else:
				logging.error('微信sign校验,---校验失败')
		except Exception as e:
			logging.error('微信sign校验,---Exception' + str(e))

	def check_signature(self, signature, timestamp, nonce):
		"""校验token是否正确"""
		token = 'cheyixiao123456'
		arr = [timestamp, nonce, token]
		arr.sort()
		s = arr[0] + arr[1] + arr[2]
		sha1 = hashlib.sha1(s.encode('utf-8')).hexdigest()
		logging.debug('sha1=' + sha1 + '&signature=' + signature)
		return sha1 == signature

	def post(self):
		body = self.request.body
		logging.debug('微信消息回复中心 收到用户消息' + str(body.decode('utf-8')))
		data = ET.fromstring(body)
		MsgType = data.find('MsgType').text
		ToUserName = data.find('ToUserName').text
		FromUserName = data.find('FromUserName').text
		CreateTime = int(time.time())
		if MsgType == 'event':
			try:
				event = data.find('Event').text
				scene_id = None
				if event == 'subscribe':
					self.reply_welcome_info(FromUserName, ToUserName,
											CreateTime)
					scene_id = data.find('EventKey').text
					scene_id = scene_id.split('_')[-1]
				elif event == 'SCAN':
					self.reply_welcome_info(FromUserName, ToUserName,
											CreateTime)
					scene_id = data.find('EventKey').text
				elif event == "CLICK":
					event_key = data.find('EventKey').text
					openid = FromUserName
					query = {'openid': openid}
					bind = self.db.wechat_bind.find_one(query)
					if bind:
						if event_key == 'car_source':
							self.reply_car_source(FromUserName, ToUserName,
												  CreateTime)
							return
						elif event_key == 'try_and_buy':
							self.reply_try_and_buy(FromUserName, ToUserName,
												   CreateTime)
							return
						elif event_key == 'customer_service':
							# 如果事件的key为customer_service,则执行以下操作
							self.reply_customer_service(FromUserName, ToUserName,
														CreateTime)
							return
					else:
						self.reply_bind_info(FromUserName,
											 ToUserName, CreateTime)
						return
				if scene_id:
					openid = data.find('FromUserName').text
					query = {'id': int(scene_id)}
					bill = self.db.bills.find_one(query)
					if bill:
						user_id = bill.user_id
						saler_id = bill.saler_id
						bill_id = bill.id
						logging.debug('saler_id:%s, user_id:%s, bill_id:%s', saler_id, user_id, bill_id)
						if bill.openid:
							return
						info = {'openid': openid}
						try:
							self.db.bills.find_one_and_update(
								query, {'$set': info}, upsert=False)
						except Exception:
							pass
						user_id = bill.user_id
						saler_id = bill.saler_id
						query = {'user_id': user_id, 'saler_id': saler_id}
						info = {'status': 2, 'user_id': user_id, 'saler_id': saler_id}
						self.db.user_status.find_one_and_update(query, {'$set': info}, upsert=False)
			except Exception:
				pass
		elif MsgType == "text":
			# 将消息转发给客服系统
			response_xml = """
				 <xml>
					 <ToUserName><![CDATA[%s]]></ToUserName>
					 <FromUserName><![CDATA[%s]]></FromUserName>
					 <CreateTime>%s</CreateTime>
					 <MsgType><![CDATA[transfer_customer_service]]></MsgType>
				 </xml>
			""" % (FromUserName, ToUserName, CreateTime)
			self.write(response_xml)

	def reply_try_and_buy(self, FromUserName, ToUserName, CreateTime):
		reply_content = '''
			欢迎使用车易销，申请成为会员请联系车易销工作人员。
			
			联系人：车势科技
			联系方式：010-65066808
			
			车易销，汽车新零售利器。
			赋能车商，成就车商！
			'''
		self.reply_text(FromUserName, ToUserName, CreateTime, reply_content)

	def reply_car_source(self, FromUserName, ToUserName, CreateTime):
		reply_content = '''
			寻找车源，请联系车易销工作人员，我们会在第一时间为您匹配最优质的车源。
			
			车易销-寻车
			联系人：车势科技
			联系方式：010-65066808
			'''
		self.reply_text(FromUserName, ToUserName, CreateTime, reply_content)

	def reply_bind_info(self, FromUserName, ToUserName, CreateTime):
		appid = os.getenv('CheXiaoYiAppID', '')
		redirect_url = 'https://cheyixiao.autoforce.net/v1/wx/user/bind'
		href = 'https://open.weixin.qq.com/connect/oauth2/authorize?' \
			   'appid={}&redirect_uri={}&response_type=code&scope=snsapi_base' \
			   '&state=STATE#wechat_redirect'.format(appid, redirect_url)
		reply_content = '''
			您还没进行账号绑定，请点击下面链接前去绑定
			<a href="%s">前去绑定</a>
		''' % href
		self.reply_text(FromUserName, ToUserName, CreateTime, reply_content)

	def reply_welcome_info(self, FromUserName, ToUserName, CreateTime):
		reply_content = '欢迎来到车易销车小易'
		logging.debug('reply_content:%s', reply_content)
		self.reply_text(FromUserName, ToUserName, CreateTime, reply_content)

	def reply_customer_service(self, FromUserName, ToUserName, CreateTime):
		reply_content = '''
			感谢您关注车易销，请问您有什么问题要咨询？
			'''
		self.reply_text(FromUserName, ToUserName, CreateTime, reply_content)


class WechatBillHandler(BaseHandler):
	def check_xsrf_cookie(self):
		pass

	@tornado.gen.coroutine
	def get(self):
		code = self.get_argument('code', '')
		if code:
			openid = yield self.get_openid(code)
		else:
			openid = self.get_argument('openid', '')
		session = self.DB
		Bills = self.model('bills')
		Dealers = self.model('dealers')
		Salers = self.model('salers')
		Specs = self.model("specs")
		UserStatus = self.model('user_status')
		if openid:
			bill = session.query(Bills).filter(Bills.openid == openid). \
				order_by(Bills.id.desc()).first()

			if bill:
				user_id = bill.user_id
				saler_id = bill.saler_id
				status = session.query(UserStatus.status). \
					filter(UserStatus.saler_id == saler_id, UserStatus.user_id == user_id). \
					order_by(UserStatus.id.desc()).first()
				if status:
					status = status[0]
					if status in [5, 8]:
						self.render('no_bill.html')
						return
					dealer_info = session.query(Dealers.name, Dealers.address, Salers.name, Salers.phone, Dealers.call). \
						join(Salers, Salers.dealer_id == Dealers.id). \
						filter(Salers.id == saler_id).first()
					car_id = bill.car_id
					connection = self.get_afsaas_connection()
					with connection.cursor() as cursor:
						query_sql = 'select i1 from specs where id="%s"' % car_id
						cursor.execute(query_sql)
						data = cursor.fetchone()
						car_name = data.get('i1', '')
					dealer = dealer_info[0]
					dealer_address = dealer_info[1] or ''
					saler_name = dealer_info[2] or ''
					saler_phone = dealer_info[3] or ''
					dealer_call = dealer_info[4] or ''
					logo = session.query(Specs.logo).filter(Specs.id == bill.car_id).scalar()
					bill = bill.to_dict()
					total_cost = bill.get('total_cost', '')
					total_cost_str = self.price_int2str(total_cost)
					bill['total_cost'] = total_cost_str
					for key in bill:
						if isinstance(bill[key], int) and key.startswith('i'):
							bill[key] = self.price_int2str(bill[key])
					info = {'car_name': car_name, 'dealer': dealer, 'd_address': dealer_address,
							'logo': logo, 'saler_name': saler_name, 'saler_phone': saler_phone, 'call': dealer_call}
					bill.update(info)
					del bill['created_at']
					del bill['updated_at']
					self.render('bill.html', bile=bill)
			else:
				self.render('no_bill.html')
		else:
			self.render('no_bill.html')

	def delete(self):
		bill_id = self.get_argument_int('bill_id')
		session = self.DB
		Bills = self.model('bills')
		UserStatus = self.model('user_status')
		bill = session.query(Bills).filter(Bills.id == bill_id).first()
		if bill:
			user_id = bill.user_id
			saler_id = bill.saler_id
			status_query = session.query(UserStatus.status). \
				filter(UserStatus.user_id == user_id, UserStatus.saler_id == saler_id).first()
			if status_query:
				status = status_query[0]
			else:
				status = 0
			query = {'user_id': user_id, 'saler_id': saler_id}
			info = {'end_status': status, 'status': 5}
			try:
				self.db.user_status.find_one_and_update(query, {"$set": info})
			except Exception as e:
				logging.debug("update user_status error :%s", e)
				self.render_json({'code': 202, 'msg': '订单取消失败,请稍后重试！'})
			else:
				self.render_json({'code': 200, 'msg': '订单取消成功！'})
		else:
			logging.debug('bill id 有误！')
			self.render_json({'code': 406, 'msg': '参数有误！'})


class WechatDealerBindHandler(BaseHandler):
	def check_xsrf_cookie(self):
		pass

	@tornado.gen.coroutine
	def get(self):
		code = self.get_argument('code', '')
		openid = yield self.get_openid(code)
		self.render('bind.html', openid=openid)

	def post(self):
		openid = self.get_argument('openid', '')
		username = self.get_argument('username', '')
		passwd = self.get_argument('passwd', '')
		query = {'username': username, 'password': passwd}
		if openid:
			saler = self.db.salers.find_one(query)
			if saler:
				query = {'saler_id': saler.id}
				bind_saler = self.db.wechat_bind.find_one(query)
				if bind_saler:
					self.render_json(
						{'code': 403,
						 'msg': '该账号已被绑定，请绑定其他可用账号'}
					)
					return
				info = {'saler_id': saler.id, 'openid': openid}
				try:
					self.db.wechat_bind.insert_one(info)
				except Exception as e:
					logging.debug('error:%s', e)
					self.render_json({'code': 500, 'msg': '服务器异常，请重试！'})
				else:
					self.render_json({'code': 200, 'msg': '账号绑定成功！'})
				return
			self.render_json({'code': 403, 'msg': '请正确输入信息后，再次绑定！'})
		else:
			self.render_json({'code': 403, 'msg': '此操作禁止！'})


class WechatCarConfigHandler(BaseHandler):
	def get(self):
		car_id = self.get_argument('car_id', '')
		connection = self.get_afsaas_connection()
		with connection.cursor() as cursor:
			query_sql = 'select * from specs where id="%s"' % car_id
			cursor.execute(query_sql)
			spec = cursor.fetchone()
			config = spec.get('config', None)
			if config:
				config = json_decode(config)
				i1 = spec.get('i1', '')
				i2 = spec.get('i2', '')
				i3 = spec.get('i3', '')
				i4 = spec.get('i4', '')
				i5 = spec.get('i5', '')
				i6 = spec.get('i6', '')
				i7 = spec.get('i7', '')
				i8 = spec.get('i8', '')
				i9 = spec.get('i9', '')
				i10 = spec.get('i10', '')
				i11 = spec.get('i11', '')
				i12 = spec.get('i12', '')
				i13 = spec.get('i13', '')
				i14 = spec.get('i14', '')
				i15 = spec.get('i15', '')
				basic_para_map = dict(
					i1='车型名称',
					i2='厂商指导价(元)',
					i3='厂商',
					i4='级别',
					i5='发动机',
					i6='变速箱',
					i7='长*宽*高(mm)',
					i8='车身结构',
					i9='最高车速(km/h)',
					i10='官方0-100km/h加速(s)',
					i11='实测0-100km/h加速(s)',
					i12='实测100-0km/h制动(m)',
					i13='实测油耗(L/100km)',
					i14='工信部综合油耗(L/100km)',
					i15='实测离地间隙(mm)',
				)
				car_body_map = dict(
					i16='整车质保',
					i17='长度(mm)',
					i18='宽度(mm)',
					i19='高度(mm)',
					i20='轴距(mm)',
					i21='前轮距(mm)',
					i22='后轮距(mm)',
					i23='最小离地间隙(mm)',
					i24='整备质量(kg)',
					i25='车身结构',
					i26='车门数(个)',
					i27='座位数(个)',
					i28='油箱容积(L)',
					i29='行李厢容积(L)',
				)
				engine_map = dict(
					i30='发动机型号',
					i31='排量(mL)',
					i32='排量(L)',
					i33='进气形式',
					i34='气缸排列形式',
					i35='气缸数(个)',
					i36='每缸气门数(个)',
					i37='压缩比',
					i38='配气机构',
					i39='缸径(mm)',
					i40='行程(mm)',
					i41='最大马力(Ps)',
					i42='最大功率(kW)',
					i43='最大功率转速(rpm)',
					i44='最大扭矩(N·m)',
					i45='最大扭矩转速(rpm)',
					i46='发动机特有技术',
					i47='燃料形式',
					i48='燃油标号',
					i49='供油方式',
					i50='缸盖材料',
					i51='缸体材料',
					i52='环保标准',
				)
				electric_map = dict(
					i53='电动机总功率(kW)',
					i54='电动机总扭矩(N·m)',
					i55='前电动机最大功率(kW)',
					i56='前电动机最大扭矩(N·m)',
					i57='后电动机最大功率(kW)',
					i58='后电动机最大扭矩(N·m)',
					i59='工信部续航里程(km)',
					i60='电池容量(kWh)',
					i61='电池充电时间',
					i62='充电桩价格',
				)
				gear_map = dict(
					i63='简称',
					i64='挡位个数',
					i65='变速箱类型',
				)

				bottom_map = dict(
					i66='驱动方式',
					i67='四驱形式',
					i68='中央差速器结构',
					i69='前悬架类型',
					i70='后悬架类型',
					i71='助力类型',
					i72='车体结构',
				)
				brake_map = dict(
					i73='前制动器类型',
					i74='后制动器类型',
					i75='驻车制动类型',
					i76='前轮胎规格',
					i77='后轮胎规格',
					i78='备胎规格',
				)
				safe_map = dict(
					i79='主/副驾驶座安全气囊',
					i80='前/后排侧气囊',
					i81='前/后排头部气囊(气帘)',
					i82='膝部气囊',
					i83='胎压监测装置',
					i84='零胎压继续行驶',
					i85='安全带未系提示',
					i86='ISOFIX儿童座椅接口',
					i87='发动机电子防盗',
					i88='车内中控锁',
					i89='遥控钥匙',
					i90='无钥匙启动系统',
					i91='无钥匙进入系统',
				)
				handle_map = dict(
					i92='ABS防抱死',
					i93='制动力分配(EBD/CBC等)',
					i94='刹车辅助(EBA/BAS/BA等)',
					i95='牵引力控制(ASR/TCS/TRC等)',
					i96='车身稳定控制(ESC/ESP/DSC等)',
					i97='上坡辅助',
					i98='自动驻车',
					i99='陡坡缓降',
					i100='可变悬架',
					i101='空气悬架',
					i102='可变转向比',
					i103='前桥限滑差速器/差速锁',
					i104='中央差速器锁止功能',
					i105='后桥限滑差速器/差速锁',
				)
				outer_map = dict(
					i106='电动天窗',
					i107='全景天窗',
					i108='运动外观套件',
					i109='铝合金轮圈',
					i110='电动吸合门',
					i111='侧滑门',
					i112='电动后备厢',
					i113='感应后备厢',
					i114='车顶行李架',
				)
				inner_map = dict(
					i115='真皮方向盘',
					i116='方向盘调节',
					i117='方向盘电动调节',
					i118='多功能方向盘',
					i119='方向盘换挡',
					i120='方向盘加热',
					i121='方向盘记忆',
					i122='定速巡航',
					i123='前/后驻车雷达',
					i124='倒车视频影像',
					i125='行车电脑显示屏',
					i126='全液晶仪表盘',
					i127='HUD抬头数字显示',
				)
				chair_map = dict(
					i128='座椅材质',
					i129='运动风格座椅',
					i130='座椅高低调节',
					i131='腰部支撑调节',
					i132='肩部支撑调节',
					i133='主/副驾驶座电动调节',
					i134='第二排靠背角度调节',
					i135='第二排座椅移动',
					i136='后排座椅电动调节',
					i137='电动座椅记忆',
					i138='前/后排座椅加热',
					i139='前/后排座椅通风',
					i140='前/后排座椅按摩',
					i141='第三排座椅',
					i142='后排座椅放倒方式',
					i143='前/后中央扶手',
					i144='后排杯架',
				)
				video_map = dict(
					i145='GPS导航系统',
					i146='定位互动服务',
					i147='中控台彩色大屏',
					i148='蓝牙/车载电话',
					i149='车载电视',
					i150='后排液晶屏',
					i151='220V/230V电源',
					i152='外接音源接口',
					i153='CD支持MP3/WMA',
					i154='多媒体系统',
					i155='扬声器品牌',
					i156='扬声器数量',
				)
				light_map = dict(
					i157='近光灯',
					i158='远光灯',
					i159='日间行车灯',
					i160='自适应远近光',
					i161='自动头灯',
					i162='转向辅助灯',
					i163='转向头灯',
					i164='前雾灯',
					i165='大灯高度可调',
					i166='大灯清洗装置',
					i167='车内氛围灯',
				)
				glass_map = dict(
					i168='前/后电动车窗',
					i169='车窗防夹手功能',
					i170='防紫外线/隔热玻璃',
					i171='后视镜电动调节',
					i172='后视镜加热',
					i173='内/外后视镜自动防眩目',
					i174='后视镜电动折叠',
					i175='后视镜记忆',
					i176='后风挡遮阳帘',
					i177='后排侧遮阳帘',
					i178='后排侧隐私玻璃',
					i179='遮阳板化妆镜',
					i180='后雨刷',
					i181='感应雨刷',
				)
				air_condition_map = dict(
					i182='空调控制方式',
					i183='后排独立空调',
					i184='后座出风口',
					i185='温度分区控制',
					i186='车内空气调节/花粉过滤',
					i187='车载冰箱',
				)
				tech_maps = dict(
					i188='自动泊车入位',
					i189='发动机启停技术',
					i190='并线辅助',
					i191='车道偏离预警系统',
					i192='主动刹车/主动安全系统',
					i193='整体主动转向系统',
					i194='夜视系统',
					i195='中控液晶屏分屏显示',
					i196='自适应巡航',
					i197='全景摄像头',
				)
				param_return = dict()
				basic_para = []
				for part in ['i1', 'i2', 'i3', 'i4', 'i5', 'i6', 'i7', 'i8',
							 'i9', 'i10', 'i11', 'i12', 'i13', 'i14', 'i15']:
					if eval(part):
						tem_dict = dict()
						if part in ['i10', 'i11', 'i12', 'i13', 'i14']:
							tem_dict[basic_para_map[part]] = float(eval(part))
						else:
							tem_dict[basic_para_map[part]] = eval(part)
						basic_para.append(tem_dict)
				param_return['基本信息'] = basic_para
				car_body = []
				engine = []
				electric = []
				gear = []
				bottom = []
				brake = []
				safe = []
				handle = []
				outer = []
				inner = []
				chair = []
				video = []
				light = []
				glass = []
				air_condition = []
				tech = []
				for part in config:
					tem_dict = dict()
					if part in car_body_map:
						tem_dict[car_body_map[part]] = \
							self.strip_nbsp(config[part])
						car_body.append(tem_dict)
					elif part in engine_map:
						tem_dict[engine_map[part]] = \
							self.strip_nbsp(config[part])
						engine.append(tem_dict)
					elif part in gear_map:
						tem_dict[gear_map[part]] = \
							self.strip_nbsp(config[part])
						gear.append(tem_dict)
					elif part in electric_map:
						tem_dict[electric_map[part]] = \
							self.strip_nbsp(config[part])
						electric.append(tem_dict)
					elif part in bottom_map:
						tem_dict[bottom_map[part]] = \
							self.strip_nbsp(config[part])
						bottom.append(tem_dict)
					elif part in brake_map:
						tem_dict[brake_map[part]] = \
							self.strip_nbsp(config[part])
						brake.append(tem_dict)
					elif part in safe_map:
						tem_dict[safe_map[part]] = \
							self.strip_nbsp(config[part])
						safe.append(tem_dict)
					elif part in handle_map:
						tem_dict[handle_map[part]] = \
							self.strip_nbsp(config[part])
						handle.append(tem_dict)
					elif part in outer_map:
						tem_dict[outer_map[part]] = \
							self.strip_nbsp(config[part])
						outer.append(tem_dict)
					elif part in inner_map:
						tem_dict[inner_map[part]] = \
							self.strip_nbsp(config[part])
						inner.append(tem_dict)
					elif part in chair_map:
						tem_dict[chair_map[part]] = \
							self.strip_nbsp(config[part])
						chair.append(tem_dict)
					elif part in video_map:
						tem_dict[video_map[part]] = \
							self.strip_nbsp(config[part])
						video.append(tem_dict)
					elif part in light_map:
						tem_dict[light_map[part]] = \
							self.strip_nbsp(config[part])
						light.append(tem_dict)
					elif part in glass_map:
						tem_dict[glass_map[part]] = \
							self.strip_nbsp(config[part])
						glass.append(tem_dict)
					elif part in air_condition_map:
						tem_dict[air_condition_map[part]] = \
							self.strip_nbsp(config[part])
						air_condition.append(tem_dict)
					elif part in tech_maps:
						tem_dict[tech_maps[part]] = \
							self.strip_nbsp(config[part])
						tech.append(tem_dict)
				if car_body:
					param_return['车身'] = car_body
				if engine:
					param_return['发动机'] = engine
				if electric:
					param_return['电动机'] = electric
				if gear:
					param_return['变速箱'] = gear
				if bottom:
					param_return['底盘转向'] = bottom
				if brake:
					param_return['车轮制动'] = brake
				if safe:
					param_return['安全装备'] = safe
				if handle:
					param_return['操控配置'] = handle
				if outer:
					param_return['外部配置'] = outer
				if inner:
					param_return['内部配置'] = inner
				if chair:
					param_return['座椅配置'] = chair
				if video:
					param_return['多媒体配置'] = video
				if light:
					param_return['灯光配置'] = light
				if glass:
					param_return['玻璃/后视镜'] = glass
				if air_condition:
					param_return['空调/冰箱'] = air_condition
				if tech:
					param_return['高科技配置'] = tech
			else:
				param_return = dict()
				param_return['车身'] = {}
				param_return['发动机'] = {}
				param_return['电动机'] = {}
				param_return['变速箱'] = {}
				param_return['底盘转向'] = {}
				param_return['车轮制动'] = {}
				param_return['安全装备'] = {}
				param_return['操控配置'] = {}
				param_return['外部配置'] = {}
				param_return['内部配置'] = {}
				param_return['座椅配置'] = {}
				param_return['多媒体配置'] = {}
				param_return['灯光配置'] = {}
				param_return['玻璃/后视镜'] = {}
				param_return['空调/冰箱'] = {}
				param_return['高科技配置'] = {}
			self.render('config_detail.html', config=param_return)


class WechatDealersHomeHandler(BaseHandler):
	@tornado.gen.coroutine
	def get(self):
		code = self.get_argument('code', '')
		openid = yield self.get_openid(code)
		if openid:
			session = self.DB
			WechatBind = self.model('wechat_bind')
			bind = session.query(WechatBind). \
				filter(WechatBind.openid == openid).order_by(WechatBind.id.desc()).first()
			if bind:
				saler_id = bind.saler_id
				saler = self.db.salers.find_one({'id': saler_id, 'perm': 1, 'role': 1})
				if saler:
					NiuNiuDealers = self.model('niuniu_dealers')
					dealers_query = session.query(NiuNiuDealers). \
						filter(NiuNiuDealers.area == '北京市北京市',
							   NiuNiuDealers.brand == '广汽丰田').all()
					dealer_list = []
					for item in dealers_query:
						dealer_list.append(item.to_dict())
					self.render('dealer_query2.html', results=dealer_list)
					return
			self.render('bind.html', openid=openid)
		else:
			self.render('403.html')


class WechatDealersQueryHandler(BaseHandler):
	def get(self):
		city = self.get_argument('city', '')
		brand = self.get_argument('brand', '')
		if city and brand:
			session = self.DB
			NiuNiuDealers = self.model('niuniu_dealers')
			dealers = session.query(NiuNiuDealers). \
				filter(NiuNiuDealers.brand == brand,
					   NiuNiuDealers.area.like('%' + city + '%')).all()
			self.render_json({'code': 200, 'results': dealers})
		else:
			self.render_json({'code': 200, 'results': []})


class WechatDealersCityHandler(BaseHandler):
	def get(self):
		pid = self.get_argument_int('pid')
		connection = self.get_afsaas_connection()
		with connection.cursor() as cursor:
			query_sql = 'select name from areas where pid=%s' % pid
			cursor.execute(query_sql)
			city_list = cursor.fetchall()
		city_name_list = []
		for city in city_list:
			city_name_list.append(city['name'])
		self.render_json({'code': 200, 'results': city_name_list})


class WechatDealersProvinceHandler(BaseHandler):
	def get(self):
		connection = self.get_afsaas_connection()
		with connection.cursor() as cursor:
			query_sql = 'select id, name from areas where pid=0'
			cursor.execute(query_sql)
			province_list = cursor.fetchall()
		province_list.sort(key=lambda x: x['id'])
		self.render_json({'code': 200, 'results': province_list})


class WechatDealersBrandHandler(BaseHandler):
	def get(self):
		session = self.DB
		NiuNiuDealers = self.model('niuniu_dealers')
		brand_query = session.query(NiuNiuDealers.brand).all()
		brand_list = []
		for item in brand_query:
			brand = item[0]
			if brand:
				brand_list.append(brand)
		brand_list = list(set(brand_list))
		self.render_json({'code': 200, 'results': brand_list})
