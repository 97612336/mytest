# coding=utf-8

from __future__ import absolute_import, print_function

from .basehandler import BaseHandler
import logging
import datetime
import os
import json
from tornado.httputil import urlencode
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest)
from tornado.escape import (json_encode, json_decode)
import tornado.gen
import qrcode
from app import Application

try:
    from StringIO import StringIO
except ImportError:
    from io import BytesIO as StringIO


def __handlers(settings):
    return [
        (r"/v2/sms/car", CarManagerListHandler),
        (r"/v2/sms/car/del", CarSchemeDelHandler),
        (r"/v2/sms/car/up", UpLineHandler),
        (r"/v2/sms/car/down", DownLineHandler),
    ]


class CarManagerListHandler(BaseHandler):

    def get(self):
        page_size = self.get_argument_int("page_size", 10)
        page = self.get_argument_int("page", 1)
        if page < 1:
            page = 1
        DealerBrand = self.model("dealer_brand")
        saler_id = self.session_saler_info('id', '')
        saler = self.db.salers.find_one({"id": saler_id})
        if not saler:
            self.render_json({"code": 501, "msg": "帐号异常！"})
        dealer_id = saler.dealer_id
        brand_list = self.DB.query(DealerBrand).\
            filter_by(dealer_id=dealer_id).all()
        cars = []
        brand_ids = [brand.brand_id for brand in brand_list]
        Series = self.model("series")
        series_list = self.DB.query(Series).\
            filter(Series.brand_id.in_(brand_ids)).all()
        ser_dict = {}
        ser_ids = []
        for ser in series_list:
            ser_id = ser.id
            ser_ids.append(ser_id)
            ser_dict[str(ser_id)] = ser
        CarScheme = self.model("car_scheme")
        car_scheme_list = self.DB.query(CarScheme). \
            filter_by(dealer_id=dealer_id).all()
        cs_ids = [cs.id for cs in car_scheme_list]
        CarScheme = self.model("car_scheme")
        Specs = self.model("specs")
        specs_list = self.DB.query(Specs).\
            filter(Specs.series_id.in_(ser_ids)).all()
        dict_cars = {}
        for car in specs_list:
            sid_str = str(car.series_id)
            key_brand = str(ser_dict[sid_str].brand_id)
            if key_brand not in dict_cars.keys():
                dict_cars[key_brand] = {}
                dict_cars[key_brand][sid_str] = [car]
            if key_brand in dict_cars.keys():
                if sid_str not in dict_cars[key_brand].keys():
                    dict_cars[key_brand][sid_str] = [car]
                if sid_str in dict_cars.keys():
                    dict_cars[key_brand][sid_str].append(car)
        for k, v in dict_cars.items():
            for k0, v0 in v.items():
                car_ids = []
                for v1 in v0:
                    car_ids.append(v1.id)
                car_scheme_list = self.DB.query(CarScheme). \
                    filter(CarScheme.id.in_(cs_ids)). \
                    filter(CarScheme.car_id.in_(car_ids)).all()
                for car_scheme in car_scheme_list:
                    tmp_dict = {}
                    car_id = car_scheme.car_id
                    tmp_dict["cs_id"] = car_scheme.id
                    tmp_dict["cid"] = car_id
                    tmp_dict["time"] = str(car_scheme.created_at)[:-3]
                    tmp_dict["status"] = car_scheme.status
                    car = self.db.specs.find_one({"id": car_id})

                    tmp_dict["name"] = car.name if car else ''
                    tmp_dict["guide"] = car.guide_price \
                        if car else "暂无"
                    dealer_spec = self.db.dealer_spec.find_one(
                        {"dealer_id": dealer_id, "car_id": car_id})
                    naked = "暂无"
                    if dealer_spec:
                        if dealer_spec.naked_price:
                            naked = "%.2f" % round(dealer_spec.naked_price/10000, 2) + "万"
                    tmp_dict["naked"] = naked
                    tmp_dict["nums"] = dealer_spec.nums \
                        if dealer_spec else 0
                    cars.append(tmp_dict)
        cars.sort(key=lambda x: x.get("time"), reverse=True)
        start = (page - 1) * page_size
        end = page * page_size
        total = len(cars)

        results = cars[start:end]
        self.render_json({"code": 200, "total": total, "results": results})


class CarSchemeDelHandler(BaseHandler):

    def get(self):
        cs_id = self.get_argument_int("cs_id")
        CarScheme = self.model("car_scheme")
        self.DB.query(CarScheme).filter_by(id=cs_id).delete()
        self.DB.commit()
        self.render_json({"code": 200, "msg": "操作成功！"})


class UpLineHandler(BaseHandler):

    def get(self):
        saler_id = self.session_saler_info("id", "")
        dealer_id = self.db.salers.find_one({"id": saler_id}).dealer_id
        cs_id = self.get_argument_int("cs_id")
        car_id = self.get_argument_int("cid")
        self.db.car_scheme.update_many(
            {"car_id": car_id, "dealer_id": dealer_id},
            {"$set": {"status": 1}})
        self.db.car_scheme.find_one_and_update(
            {"id": cs_id}, {"$set": {"status": 2}})
        self.db.dealer_spec.find_one_and_update(
            {"dealer_id": dealer_id, "car_id": car_id},
            {"$set": {"status": 2}}
        )
        series_id = None
        car = self.db.specs.find_one({"id": car_id})
        if car:
            series_id = car.series_id
        fseries = self.db.series.find_one({"id": series_id})
        if fseries:
            brand_id = fseries.brand_id
        self.db.dealer_brand.\
            find_one_and_update({"brand_id": brand_id, "dealer_id": dealer_id},
                                {"$set": {"onsell": 1}})
        self.render_json({"code": 200, "msg": "操作成功！"})


class DownLineHandler(BaseHandler):

    def get(self):
        Specs = self.model("specs")
        DealerSpec = self.model("dealer_spec")
        cs_id = self.get_argument_int("cs_id")
        cs = self.db.car_scheme.find_one({"id": cs_id})
        car_id = None
        if cs:
            car_id = cs.car_id
        if not cs:
            self.render_json({"code": 402, "msg": "cs_id不存在！"})
        saler_id = self.session_saler_info("id", "")
        dealer_id = self.db.salers.find_one({"id": saler_id}).dealer_id
        self.db.car_scheme.find_one_and_update(
            {"id": cs_id}, {"$set": {"status": 1}})
        series_id = None
        car = self.db.specs.find_one({"id": car_id})
        if car:
            series_id = car.series_id
        fseries = self.db.series.find_one({"id": series_id})
        brand_id = None
        if fseries:
            brand_id = fseries.brand_id
        series_list = self.db.series.query().filter_by(brand_id=brand_id).all()
        series_ids = [s.id for s in series_list]
        car_list = self.DB.query(Specs).\
            filter(Specs.series_id.in_(series_ids)).all()
        self.db.dealer_spec.find_one_and_update(
            {"dealer_id": dealer_id, "car_id": car_id},
            {"$set": {"status": 1}}
        )
        car_ids = [c.id for c in car_list]
        leave_brand_specs = self.DB.query(DealerSpec).\
            filter_by(dealer_id=dealer_id, status=2).\
            filter(DealerSpec.car_id.in_(car_ids)).all()
        if len(leave_brand_specs) == 0:
            self.db.dealer_brand.\
                find_one_and_update({"brand_id": brand_id,
                                     "dealer_id": dealer_id},
                                    {"$set": {"onsell": 0}})
        self.render_json({"code": 200, "msg": "操作成功！"})
