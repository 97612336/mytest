# coding=utf-8

from __future__ import absolute_import, print_function
from .basehandler import BaseHandler


def __handlers(settings):
    return [
        (r"/v4/sms/car/specs/add", addSpecHandler),
    ]


class addSpecHandler(BaseHandler):
    tokenpass = True
    def get(self):
        # saler_id = self.saler_id
        saler_id = self.get_argument("saler_id")
        dealer_id = self.db.salers.find_one({"id": saler_id}).dealer_id
        session = self.DB
        count_car_scheme_sql = "select id, car_id,status from " \
                               "cheyixiao.car_scheme where " \
                               "dealer_id=%s and car_id in " \
                               "(select t2.car_id from cheyixiao.specs " \
                               "as t1 join cheyixiao.car_scheme as t2 on " \
                               "t1.id=t2.car_id where t2.dealer_id=%s " \
                               "group by t2.car_id  " \
                               "having count(t2.car_id) > 1);" \
                               % (dealer_id, dealer_id)
        res = session.execute(count_car_scheme_sql)
        res_list = res.fetchall()
        if res_list:
            id_set = set()
            repe_id_list = []
            for item in res_list:
                if item[1] in id_set:
                    repe_id_list.append(item[0])
                    continue
                id_set.add(item[1])
            str_ids = ",".join(str(i) for i in repe_id_list)
            del_sql = "delete from cheyixiao.car_scheme where `id` in(%s);" \
                      % str_ids
            session.execute(del_sql)
            session.commit()

        new_cars_sql = "select id,guide_price from cheyixiao.specs " \
                       "where id not in (select t1.id  FROM " \
                       "cheyixiao.specs as t1 join " \
                       "cheyixiao.dealer_spec as t2 on t1.id=t2.car_id " \
                       "where t2.dealer_id=%s);" % dealer_id
        new_cars_res = session.execute(new_cars_sql)
        new_cars_res_list = new_cars_res.fetchall()

        car_scheme_sql = "select id,guide_price from cheyixiao.specs " \
                         "where id not in (select t1.id  FROM " \
                         "cheyixiao.specs as t1 join " \
                         "cheyixiao.car_scheme as t2 on t1.id=t2.car_id " \
                         "where t2.dealer_id=%s);" % dealer_id
        car_scheme_res = session.execute(car_scheme_sql)
        car_scheme_res_list = car_scheme_res.fetchall()

        if not new_cars_res_list and not car_scheme_res_list:
            self.render_json({"code": 200, "msg": "已无最新车型！"})
            return

        for car in new_cars_res_list:
            insert_dealer_spec_sql = "insert ignore into " \
                                     "cheyixiao.dealer_spec " \
                                     "(dealer_id,car_id,status," \
                                     "naked_price,nums) " \
                                     "values(%s,%s,%s,'%s',%s)"
            session.execute(insert_dealer_spec_sql % (dealer_id,
                                                      car[0], 2, car[1], 1))
        for car in car_scheme_res_list:
            insert_car_scheme_sql = "insert ignore into " \
                                    "cheyixiao.car_scheme " \
                                    "(car_id, status, dealer_id) " \
                                    "values(%s,%s,%s)"
            session.execute(insert_car_scheme_sql % (car[0], 2, dealer_id))
        session.commit()

        self.render_json({"code": 200, "msg": "已无最新车型！"})




