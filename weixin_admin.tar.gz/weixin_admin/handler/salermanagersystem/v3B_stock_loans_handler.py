# coding=utf-8

from __future__ import absolute_import, print_function
from .basehandler import BaseHandler
import logging
import datetime
import os
from tornado.httputil import urlencode,urlparse
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest)
from tornado.escape import (json_encode, json_decode)
import tornado.gen
import qrcode
import json
from io import BytesIO
import tornado.web
import datetime
from collections import OrderedDict
import base64, hashlib

try:
    from StringIO import StringIO
except ImportError:
    from io import BytesIO as StringIO


def __handlers(settings):
    return [
        (r"/v3B/sms/finance/stock", V3BStockLoansHandler)
    ]


class V3BStockLoansHandler(BaseHandler):
    """
    1：中规/国产，2：美规， 3：加规， 4：中东， 5：欧规， 6：墨版
    """

    def check_xsrf_cookie(self):
        pass

    def post(self):
        recv_data = self.get_argument("data", None)
        front_data = json_decode(recv_data)

        if not front_data:
            self.render_json({"code": 203, "msg": "上传数据失败！"})
        provider_info = front_data.get("provider_info", None)
        car_info = front_data.get("car_info", None)
        if not car_info or len(car_info) == 0:
            self.render_json({"code": 202, "msg": "缺失必要的车型信息！"})
        total_amount = front_data.get("total_amount", None)
        advanced_amount = front_data.get("advanced_amount", None)
        loans_ratio = front_data.get("loans_ratio", None)
        cash_deposit = front_data.get("cash_deposit", None)
        certification = front_data.get("certification", None)
        invoice = front_data.get("invoice", None)
        param_list = ["provider_info", "car_info", "total_amount",
                      "advanced_amount", "loans_ratio", "cash_deposit",
                      "certification", "invoice"]
        for param in param_list:
            if vars()[param] is None:
                self.render_json({"code": 202, "msg": "缺失必要参数%s" % param})
        insert_data = dict(
            info=provider_info,
            total_fee=total_amount,
            pay_in=advanced_amount,
            ratio=loans_ratio,
            deposit=cash_deposit,
            pic_cert=certification,
            pic_invoice=invoice,
            saler_id=self.saler_id

        )
        try:
            res = self.db.stock_loans.insert_one(insert_data)
        except Exception as e:
            logging.debug("when insert data to stock_loans, Error:%s", e)
            self.render_json({"code": 501, "msg": "录入信息失败"})
            return
        try:
            for car in car_info:
                data = dict(
                    sl_id=res.id,
                    car_id=int(car.get("car_id", None)),
                    car_type=int(car.get("car_type", None)),
                    car_color=car.get("color", None),
                    car_price=int(car.get("price", None)),
                    car_num=int(car.get("num", None))
                )
                self.db.stock_loans_cars.insert_many(data)
            self.DB.commit()
        except Exception as e:
            logging.debug("when insert data to stock_loans_cars, Error:%s", e)
            self.render_json({"code": 501, "msg": "录入信息失败"})
            return
        self.render_json({"code": 200,
                          "msg": "您已成功发起物流发车订单，"
                                 "我们将会为您优选出汽车物流公司，请您保持手机畅通～"})

