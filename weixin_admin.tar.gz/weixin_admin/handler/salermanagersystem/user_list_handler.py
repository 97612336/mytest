# coding=utf-8

from __future__ import absolute_import, print_function

from .basehandler import BaseHandler
import logging
import datetime
import os
import json
from tornado.httputil import urlencode
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest)
from tornado.escape import (json_encode, json_decode)
import tornado.gen
import qrcode
from app import Application
import time
from collections import Counter
try:
    from StringIO import StringIO
except ImportError:
    from io import BytesIO as StringIO


def __handlers(settings):
    return [
        (r"/v2/sms/users", UserListHandler),
        (r"/v2/sms/brands", BrandListHandler),
        (r"/v2/sms/state", StateListHandler),
        (r"/v2/sms/brand/(?P<brand_id>[0-9]+)/series", SeriesListHandler),
        (r"/v2/sms/series/(?P<series_id>[0-9]+)/specs", SpecsListHandler),
    ]


class UserListHandler(BaseHandler):

    def _user_attention_cars(self, user_id, saler_id,
                             isfocus, dict_look, dict_focus):
        attentions = []

        if isfocus:
            focus_car_ids = dict_focus[str(saler_id)][str(user_id)]
        else:
            focus_car_ids = dict_look[str(saler_id)][str(user_id)]
        for car_id in focus_car_ids:
            temp_dict = {}
            car = self.db.specs.find_one({"id": car_id})
            if not car:
                continue
            series_id = car.series_id
            series = self.db.series.find_one({"id": series_id})
            if series:
                temp_dict["name"] = series.name
                temp_dict["img"] = car.logo
            else:
                temp_dict["name"] = ''
                temp_dict["img"] = ''
            attentions.append(temp_dict)
        return attentions

    def _user_info(self, user_id):
        user = self.db.users.find_one({"id": user_id})
        if user:
            user_info = dict(
                id=user.id,
                name=user.name,
                phone=user.phone,
                latime=str(user.created_at)[:-3]
            )
        else:
            user_info = dict(
                id='',
                name='',
                phone='',
                latime=''
            )
        return user_info

    def _results(self, car_ids, dict_look, dict_focus,
                 user_status, dict_bc, location, dealer_name):
        # local dealer's users pool
        res_list = []
        user_id_list = []
        for user_saler in user_status:
            tmp_dict = {}
            user_id = user_saler.user_id
            if user_id in user_id_list:
                pass
            else:
                user_id_list.append(user_id)
                # print(user_id)
                saler_id = user_saler.saler_id
                state = user_saler.status
                bill_cars = []
                if str(saler_id) in dict_bc.keys():
                    if str(user_id) in dict_bc[str(saler_id)].keys():
                        user_bill_cars = dict_bc[str(saler_id)][str(user_id)]
                        # print("exists:", str(user_id), user_bill_cars)
                        for car_id in user_bill_cars:
                            if car_id in car_ids:
                                bill_cars.append(car_id)
                        if not bill_cars:
                            bill_cars = None
                    else:
                        bill_cars = None

                focus_car_list = []
                focus_cars = {}
                if str(saler_id) in dict_focus.keys():
                    if str(user_id) in dict_focus[str(saler_id)].keys():
                        focus_cars = dict_focus[str(saler_id)][str(user_id)]
                for car_id in focus_cars:
                    if car_id in car_ids:
                        focus_car_list.append(car_id)
                tmp_dict["isfocus"] = 1

                if not focus_car_list:
                    tmp_dict["isfocus"] = 0
                    if str(saler_id) in dict_look.keys():
                        if str(user_id) in dict_look[str(saler_id)].keys():
                            look_cars = dict_look[str(saler_id)][str(user_id)]
                        else:
                            continue
                    else:
                        continue
                    carid_list = []
                    for car_id in look_cars:
                        if car_id in car_ids:
                            carid_list.append(car_id)
                    if not carid_list:
                        continue
                user_info = self._user_info(user_id=user_id)
                tmp_dict["user_id"] = user_info["id"]
                tmp_dict["uname"] = user_info["name"]
                tmp_dict["phone"] = user_info["phone"]

                tmp_dict["latime"] = user_info["latime"]
                tmp_dict["saler_id"] = saler_id
                fsaler = self.db.salers.find_one({"id": saler_id})
                if fsaler:
                    tmp_dict["saler"] = fsaler.name
                else:
                    tmp_dict["saler"] = ''
                # dealer_info = self._dealer_info(saler_id=saler_id)
                tmp_dict["loc"] = location
                tmp_dict["dealer"] = dealer_name

                tmp_dict["state"] = state
                maybe_states = [2, 3, 4]
                if state in maybe_states and bill_cars:
                    for bill in bill_cars:
                        new_dict = {}
                        new_dict.update(tmp_dict)
                        car_id = bill
                        car = self.db.specs.find_one({"id": car_id})
                        if car:
                            new_dict["img"] = car.logo
                            new_dict["car"] = car.name
                            res_list.append(new_dict)
                elif state in maybe_states and not bill_cars:
                    continue
                else:
                    tmp_dict["img"] = ''
                    tmp_dict["car"] = ''
                    res_list.append(tmp_dict)
        return res_list

    def _res_by_series(self, series_id, dict_look, dict_focus,
                    user_status, dict_bc, location, dealer_name):
        # print("series_id:", series_id)
        cars = self.db.specs.query().filter_by(series_id=series_id).all()
        car_ids = [i.id for i in cars]
        if not car_ids:
            return []
        return self._results(car_ids=car_ids,
                             dict_look=dict_look,
                             dict_focus=dict_focus,
                             user_status=user_status,
                             dict_bc=dict_bc,
                             dealer_name=dealer_name,
                             location=location,
                             )

    def _res_by_brand(self, brand_id, dict_look, dict_focus,
                      user_status, dict_bc, location, dealer_name):
        series_list = self.db.series.query().filter_by(brand_id=brand_id).all()

        res_list = []
        for ser in series_list:
            item = self._res_by_series(series_id=ser.id,
                                       dict_look=dict_look,
                                       dict_focus=dict_focus,
                                       user_status=user_status,
                                       dict_bc=dict_bc,
                                       dealer_name=dealer_name,
                                       location=location,
                                       )
            if not item:
                continue
            res_list.extend(item)
        return res_list

    def get(self):
        state = self.get_argument_int("state", 0)
        saler_id = self.session_saler_info("id", '')
        saler = self.db.salers.find_one({"id": saler_id})
        dealer_id = saler.dealer_id
        UserStatus = self.model("user_status")
        saler_perm = saler.perm
        Look = self.model("look")
        FocusCar = self.model("focus_car")
        Salers = self.model("salers")
        local_saler_list = self.DB.query(Salers). \
            filter_by(dealer_id=dealer_id).all()
        # local dealer's salers pool
        saler_ids = [s.id for s in local_saler_list]
        look_cars = self.DB.query(Look). \
            filter(Look.saler_id.in_(saler_ids)).all()
        dict_look = {}
        for look in look_cars:
            look_saler_id = str(look.saler_id)
            user_id = str(look.user_id)
            car_id = look.car_id
            if look_saler_id not in dict_look.keys():
                dict_look[look_saler_id] = {}
                dict_look[look_saler_id][user_id] = {car_id}
            if look_saler_id in dict_look.keys():
                if user_id not in dict_look[look_saler_id].keys():
                    dict_look[look_saler_id][user_id] = {car_id}
                if user_id in dict_look[look_saler_id].keys():
                    dict_look[look_saler_id][user_id].add(car_id)
        focus_cars = self.DB.query(FocusCar). \
            filter(FocusCar.saler_id.in_(saler_ids)).all()
        dict_focus = {}
        for focus in focus_cars:
            focus_saler_id = str(focus.saler_id)
            user_id = str(focus.user_id)
            car_id = focus.car_id
            if focus_saler_id not in dict_focus.keys():
                dict_focus[focus_saler_id] = {}
                dict_focus[focus_saler_id][user_id] = {car_id}
            if focus_saler_id in dict_focus.keys():
                if user_id not in dict_focus[focus_saler_id].keys():
                    dict_focus[focus_saler_id][user_id] = {car_id}
                if user_id in dict_focus[focus_saler_id].keys():
                    dict_focus[focus_saler_id][user_id].add(car_id)
        # manger level
        user_status = []
        if saler_perm == 1:
            if not state:
                user_status = self.DB.query(UserStatus).\
                    filter(UserStatus.saler_id.in_(saler_ids)).all()
            else:
                user_status = self.DB.query(UserStatus). \
                    filter(UserStatus.saler_id.in_(saler_ids)).\
                    filter(UserStatus.status == state).all()
        # common level
        if saler_perm == 2:
            if not state:
                user_status = self.DB.query(UserStatus).\
                    filter(UserStatus.saler_id == saler_id).all()
            else:
                user_status = self.DB.query(UserStatus). \
                    filter(UserStatus.saler_id == saler_id).\
                    filter(UserStatus.status == state).all()
        Bills = self.model("bills")
        bills = self.DB.query(Bills).\
            filter(Bills.saler_id.in_(saler_ids)).all()
        dict_bc = {}
        for bill in bills:
            sid = str(bill.saler_id)
            uid = str(bill.user_id)
            car_id = bill.car_id
            if sid not in dict_bc.keys():
                dict_bc[sid] = {}
                dict_bc[sid][uid] = set([car_id])
            if sid in dict_bc.keys():
                if uid not in dict_bc[sid].keys():
                    dict_bc[sid][uid] = set([car_id])
                if uid in dict_bc[sid].keys():
                    dict_bc[sid][uid].add(car_id)

        dealer = self.db.dealers.find_one({"id": dealer_id})
        if dealer:
            location = dealer.address
            dealer_name = dealer.name
        else:
            location = ''
            dealer_name = ''
        page_size = self.get_argument_int("page_size", 10)
        page = self.get_argument_int("page", 1)
        if page < 1:
            page = 1
        brand_id = self.get_argument_int("brand", 0)
        series_id = self.get_argument_int("series", 0)
        results_list = []
        # print("dict_look:",dict_look)
        # print("dict_focus:",dict_focus)
        # print("dict_bcv:",dict_bc)

        # search by series_id and state
        if series_id:
            # print("1begin")
            results_list = self._res_by_series(series_id=series_id,
                                               dict_look=dict_look,
                                               dict_focus=dict_focus,
                                               user_status=user_status,
                                               dict_bc=dict_bc,
                                               dealer_name=dealer_name,
                                               location=location,
                                               )
        # search by brand_id and state
        if brand_id and not series_id:
            # print("2begin")
            results_list = self._res_by_brand(brand_id=brand_id,
                                              dict_look=dict_look,
                                              dict_focus=dict_focus,
                                              user_status=user_status,
                                              dict_bc=dict_bc,
                                              dealer_name=dealer_name,
                                              location=location,
                                              )

        # search all by state
        if not brand_id and not series_id:
            # print("3begin")
            DealerBrand = self.model("dealer_brand")
            dealer_brands = self.DB.query(DealerBrand).\
                filter(DealerBrand.dealer_id == dealer_id).all()
            brand_ids = [ds.brand_id for ds in dealer_brands]
            results_list = []
            for brand_id in brand_ids:
                item = self._res_by_brand(brand_id=brand_id,
                                          dict_look=dict_look,
                                          dict_focus=dict_focus,
                                          user_status=user_status,
                                          dict_bc=dict_bc,
                                          dealer_name=dealer_name,
                                          location=location,
                                          )
                if not item:
                    continue
                results_list.extend(item)
        start = (page - 1) * page_size
        end = page * page_size
        results_list.sort(key=lambda x: x.get("latime"), reverse=True)
        new_list = []
        user_id_list = []
        for i in results_list:
            uid = i.get("user_id")
            if i.get("user_id") not in user_id_list:
                user_id_list.append(uid)
            else:
                continue
            new_list.append(i)
        results = new_list[start: end]
        total = len(new_list)
        for res in results:
            res["attentions"] = self._user_attention_cars(
                                    user_id=res["user_id"],
                                    saler_id=res["saler_id"],
                                    isfocus=res["isfocus"],
                                    dict_look=dict_look,
                                    dict_focus=dict_focus)
        self.render_json({"code": 200, "total": total, "results": results})


class BrandListHandler(BaseHandler):
    def get(self):
        DealerBrand = self.model("dealer_brand")
        saler_id = self.session_saler_info('id', '')
        dealer_id = self.db.salers.find_one({"id": saler_id}).dealer_id
        brand_list = self.DB.query(DealerBrand).\
            filter_by(dealer_id=dealer_id).all()
        brand_ids = [brand.brand_id for brand in brand_list]
        Brands = self.model("brands")
        brands = self.DB.query(Brands).filter(Brands.id.in_(brand_ids)).all()
        res_list = [b.to_dict() for b in brands if b.status == 1]
        res_list2 = [b.to_dict() for b in brands if b.status == 2]
        res_list.extend(res_list2)
        res_list.insert(0, {"id": 0, "name": "全部"})
        self.render_json({"code": 200, "results": res_list})


class SeriesListHandler(BaseHandler):
    def get(self, brand_id):
        saler_id = self.session_saler_info('id', '')
        dealer_id = self.db.salers.find_one({"id": saler_id}).dealer_id
        brand_list = self.db.dealer_brand.query(). \
            filter_by(dealer_id=dealer_id).all()
        brand_ids = [brand.brand_id for brand in brand_list]
        Series = self.model("series")
        if int(brand_id):
            series_list = self.DB.query(Series).\
                filter_by(brand_id=brand_id).all()
        else:
            series_list = self.DB.query(Series).\
                filter(Series.brand_id.in_(brand_ids)).all()
        res_list = [series.to_dict() for series in series_list]
        if len(res_list):
            res_list.insert(0, {"id": 0, "name": "全部"})
        self.render_json({"code": 200, "results": res_list})


class SpecsListHandler(BaseHandler):
    def get(self, series_id):
        Series = self.model("series")
        saler_id = self.session_saler_info('id', '')
        dealer_id = self.db.salers.find_one({"id": saler_id}).dealer_id
        Specs = self.model("specs")
        if int(series_id):
            specs_list = self.DB.query(Specs).\
                filter_by(series_id=series_id).all()
        else:
            brand_list = self.db.dealer_brand.query(). \
                filter_by(dealer_id=dealer_id).all()
            brand_ids = [brand.brand_id for brand in brand_list]
            series_list = self.DB.query(Series). \
                filter(Series.brand_id.in_(brand_ids)).all()
            series_ids = [series.id for series in series_list]
            specs_list = self.DB.query(Specs).\
                filter(Specs.series_id.in_(series_ids)).all()

        res_list = [car.to_dict() for car in specs_list]
        if len(res_list):
            res_list.insert(0, {"id": 0, "name": "全部"})
        self.render_json({"code": 200, "results": res_list})


class StateListHandler(BaseHandler):
    def get(self):
        res = [{"state": 0, "msg": "全部"},
               {"state": 1, "msg": "跟进中"},
               {"state": 2, "msg": "已下单"},
               {"state": 4, "msg": "已交车"},
               {"state": 5, "msg": "订单取消"}]
        self.render_json({"code": 200, "results": res})










