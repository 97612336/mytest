# coding=utf-8

from __future__ import absolute_import, print_function



from .basehandler import BaseHandler
import logging
import datetime
import os
import json
from tornado.httputil import urlencode
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest)
from tornado.escape import (json_encode, json_decode)
import tornado.gen
import qrcode
from app import Application

try:
    from StringIO import StringIO
except ImportError:
    from io import BytesIO as StringIO


def __handlers(settings):
    return [
        (r"/v2/sms/bill/confirmation", DeltaHandler),
        (r"/v2/sms/user/bill", UserBillHandler),
        (r"/v2/sms/user/detail", UserDetailHandler),
    ]


class DeltaHandler(BaseHandler):
    def get(self):
        user_id = self.get_argument_int("user_id")
        if not user_id:
            self.render_json({"code": 402, "msg": "缺失请求参数user_id !"})
            return
        status = self.get_argument_int("status")
        if not status:
            self.render_json({"code": 402, "msg": "缺失请求参数status !"})
            return
        bill = self.db.bills.query().\
            filter_by(user_id=user_id).first()
        if bill:
            car_id = bill.car_id
            saler_id = bill.saler_id
        else:
            self.render_json({"code": 402, "msg": "订单状态异常！"})
            return

        # 弃用，因为目前数据库中有脏数据
        # self.db.user_status. \
        #     find_one_and_update({"user_id": user_id, 'saler_id': saler_id},
        #                        {"$set": {"status": status, "car_id": car_id}}
        #                         , upsert=True)
        # 这里加了saler_id 查询，如果是经销店的话没法操作
        session = self.DB
        sql = "update user_status set status={0},car_id={1} " \
              "where user_id={2} and saler_id={3}"
        session.execute(sql.format(status, car_id, user_id, saler_id))
        session.commit()

        pre_status = status
        UserStatus = self.model("user_status")
        us = self.DB.query(UserStatus). \
            filter_by(status=2, saler_id=saler_id). \
            order_by(UserStatus.updated_at).first()
        if us:
            now = datetime.datetime.now()
            delta = (now - us.updated_at).days
            if delta > 7:
                self.render_json({"code": 410,
                                  "user_id": us.user_id})
                return
            else:
                self.render_json({"code": 200,
                                  "msg": "操作成功！",
                                  "status": pre_status})
                return
        else:
            self.render_json({"code": 200,
                              "msg": "操作成功！",
                              "status": pre_status})


class UserBillHandler(BaseHandler):

    def get(self):
        Bills = self.model('bills')
        Users = self.model('users')
        Specs = self.model('specs')
        Series = self.model('series')
        CarColor = self.model('car_color')
        UserStatus = self.model('user_status')
        CarWheels = self.model('car_wheels')
        session = self.DB()
        user_id = self.get_argument('user_id', '')
        bill = session.query(Bills).join(UserStatus, Bills.user_id == UserStatus.user_id).\
            filter(Bills.user_id == user_id).filter(UserStatus.status > 1). \
            order_by(Bills.id.desc()).first()
        query_user_id = session.query(Users). \
            filter(Users.id == user_id)
        if query_user_id is None:
            self.render_json({'code': 406, 'msg': '用户不存在'})
            return
        results = []
        info = {}
        if bill:
            tmp = {}
            tmp['title'] = '必要花费'
            tmp['total'] = bill.i2
            tmp['items'] = []
            kv = {}
            kv2 = {}
            kv3 = {}
            kv4 = {}
            kv['name'] = '购置税'
            kv['val'] = bill.i3
            kv2['name'] = '上牌费用'
            kv2['val'] = bill.i4
            kv3['name'] = '车船使用费'
            kv3['val'] = bill.i6
            kv4['name'] = '交通强制保险'
            kv4['val'] = bill.i5
            tmp['items'].append(kv)
            tmp['items'].append(kv2)
            tmp['items'].append(kv3)
            tmp['items'].append(kv4)
            results.append(tmp)
            tmp2 = {}
            tmp2['title'] = '商业保险'
            tmp2['total'] = bill.i7
            tmp2['items'] = []
            kv = {}
            kv2 = {}
            kv3 = {}
            kv4 = {}
            kv5 = {}
            kv6 = {}
            kv7 = {}
            kv8 = {}
            kv9 = {}
            kv['name'] = '第三方责任险'
            kv['val'] = bill.i8
            kv2['name'] = '车辆损失险'
            kv2['val'] = bill.i9
            kv3['name'] = '全车盗抢险'
            kv3['val'] = bill.i10
            kv4['name'] = '玻璃单独破碎险'
            kv4['val'] = bill.i11
            kv5['name'] = '自燃损失险'
            kv5['val'] = bill.i12
            kv6['name'] = '不计免赔特约险'
            kv6['val'] = bill.i13
            kv7['name'] = '无过责任险'
            kv7['val'] = bill.i14
            kv8['name'] = '车上人员责任险'
            kv8['val'] = bill.i15
            kv9['name'] = '车身刮痕险'
            kv9['val'] = bill.i16
            tmp2['items'].append(kv)
            tmp2['items'].append(kv2)
            tmp2['items'].append(kv3)
            tmp2['items'].append(kv4)
            tmp2['items'].append(kv5)
            tmp2['items'].append(kv6)
            tmp2['items'].append(kv7)
            tmp2['items'].append(kv8)
            tmp2['items'].append(kv9)
            results.append(tmp2)

            series_id = session.query(Specs.series_id). \
                filter(Specs.id == bill.car_id).first()
            if series_id is None:
                connection = self.get_afsaas_connection()
                with connection.cursor() as cursor:
                    query_sql = 'select series_id from specs where id="%s"' % bill.car_id
                    cursor.execute(query_sql)
                    series_query = cursor.fetchone()
                    series_id_tem = series_query.get('series_id', 0)
                    if series_id_tem:
                        query_series_sql = 'select id from specs where series_id="%s"' % series_id_tem
                        cursor.execute(query_series_sql)
                        series_id_query = cursor.fetchall()
                        car_id_list = []
                        for item in series_id_query:
                            car_id_list.append(item.get('id', 0))
                        series_id = session.query(Specs.series_id). \
                            filter(Specs.id.in_(car_id_list)).first()
                if series_id:
                    pass
                else:
                    results = []
                    info = {}
                    self.render_json({"code": 200, "feelist": results,
                                      "info": info})
                    return
            series_name = session.query(Series.name). \
                filter(Series.id == series_id[0]).first()
            series_imag = session.query(Series.logo). \
                filter(Series.id == series_id[0]).first()
            info['series_name'] = series_name[0]
            info['series_imag'] = series_imag[0]
            info['color'] = bill.color
            color_rgb = session.query(CarColor.color). \
                filter(CarColor.name == bill.color).first()
            if color_rgb:
                info['color_value'] = color_rgb[0]
            else:
                info['color_value'] = ''
            info['total_cost'] = bill.total_cost
            user_status = session.query(UserStatus.status). \
                filter(UserStatus.user_id == user_id).first()
            if user_status:
                info['status'] = user_status[0]
            else:
                info['status'] = 2
            info['car_id'] = bill.car_id
            info['hub'] = bill.hub
            hub_imag = session.query(CarWheels.logo). \
                filter(CarWheels.car_id == bill.car_id).\
                filter(CarWheels.name == bill.hub).first()
            if hub_imag:
                info['hub_imag'] = hub_imag[0]
            else:
                info['hub_imag'] = ''
            info['id'] = bill.id
            if bill.openid is None:
                info['status2'] = 0
            else:
                info['status2'] = 1

        self.render_json({"code": 200,
                          "feelist": results,
                          "info": info})


class UserDetailHandler(BaseHandler):
    def get(self):
        user_id = self.get_argument_int('user_id')
        user = self.db.users.find_one({'id': user_id})
        if user:
            result = {}
            user_name = ''
            nickname = user.nickname
            openid = user.openid
            name = user.name
            if name:
                user_name = name
            elif nickname:
                user_name = nickname
            elif openid:
                user_name = openid
            phone = user.phone
            login_at = user.updated_at
            session = self.DB()
            Salers = self.model('salers')
            UserStatus = self.model('user_status')
            saler_query = session.query(Salers.name).\
                join(UserStatus, Salers.id == UserStatus.saler_id).\
                filter(UserStatus.user_id == user_id).first()
            if saler_query:
                saler_name = saler_query[0]
            else:
                saler_name = ''
            saler_id = self.session_saler_info('id', '')
            perm = self.session_saler_info('perm', 0)
            dealer_id = self.session_saler_info('dealer_id', '')
            role = self.session_saler_info('role', '')
            logging.debug('role:%s', role)
            Salers = self.model('salers')
            saler_id_list = []
            if perm == '1':
                saler_query = session.query(Salers.id). \
                    filter(Salers.dealer_id == dealer_id).all()
                for saler in saler_query:
                    saler_id_list.append(saler[0])
            else:
                saler_id_list.append(saler_id)
            if role in ['3', 3, '4', 4]:
                dealer_name = ''
                dealer_address = ''
            else:
                dealer = self.db.dealers.find_one({'id': dealer_id})
                dealer_name = dealer.name
                dealer_address = dealer.address
            result['name'] = user_name
            result['phone'] = phone
            result['login_at'] = \
                datetime.datetime.strftime(login_at, '%Y-%m-%d %H:%M')
            result['saler_name'] = saler_name
            result['dealer_name'] = dealer_name
            result['dealer_address'] = dealer_address
            Look = self.model('look')
            Hotpoints = self.model('hotpoints')
            Specs = self.model('specs')
            Series = self.model('series')
            FocusCar = self.model('focus_car')
            CarWheels = self.model('car_wheels')
            hotpoints = session.query(Hotpoints).all()
            user_status = session.query(UserStatus). \
                filter(UserStatus.saler_id.in_(saler_id_list),
                       UserStatus.user_id == user_id).first()
            if user_status:
                status_int = user_status.status
            else:
                status_int = 1
            status = ''
            if status_int == 1:
                status = '跟进中'
            elif status_int == 2 or status_int == 3:
                status = '已下单'
            elif status_int == 4:
                status = '已交车'
            elif status_int == 5:
                status = '已取消'
            elif status_int == 6:
                status = '运输中'
            elif status_int == 7:
                status = '已到店'
            elif status_int == 8:
                status = '已取消'
            result['status'] = status
            result['status_int'] = status_int
            hotpoints_map = dict()
            for hotpoint in hotpoints:
                car_id = hotpoint.car_id
                ename = hotpoint.ename
                name = hotpoint.name
                if hotpoints_map.get(car_id, None):
                    hotpoints_map[car_id][ename] = name
                else:
                    hotpoints_map[car_id] = {}
                    hotpoints_map[car_id][ename] = name
            car_color_map = dict()
            CarColor = self.model('car_color')
            car_colors = session.query(CarColor).all()
            for car_color in car_colors:
                car_id = car_color.car_id
                ename = car_color.ename
                name = car_color.name
                color = car_color.color
                if car_color_map.get(car_id, None):
                    car_color_map[car_id][ename] = \
                        {'name': name, 'color': color}
                else:
                    car_color_map[car_id] = {}
                    car_color_map[car_id][ename] = \
                        {'name': name, 'color': color}
            looks = session.query(Look).filter(
                Look.user_id == user_id,
                Look.saler_id.in_(saler_id_list)).all()
            car_id_list = []
            car_map = dict()
            if looks:
                for look in looks:
                    car_id = look.car_id
                    if not car_map.get(car_id, None):
                        car_map[car_id] = {}
                    action = look.action
                    avalue = look.avalue
                    if action == 'outer_color':
                        if not car_map[car_id].get('outer_color', None):
                            car_map[car_id]['outer_color'] = {}
                        if car_map[car_id]['outer_color'].get(avalue, None):
                            car_map[car_id]['outer_color'][avalue] += 1
                        else:
                            car_map[car_id]['outer_color'][avalue] = 1
                    elif action == "inner_color":
                        if not car_map[car_id].get('inner_color', None):
                            car_map[car_id]['inner_color'] = {}
                        if car_map[car_id]['inner_color'].get(avalue, None):
                            car_map[car_id]['inner_color'][avalue] += 1
                        else:
                            car_map[car_id]['inner_color'][avalue] = 1
                    elif action == 'lungu':
                        if not car_map[car_id].get('car_part', None):
                            car_map[car_id]['car_part'] = {}
                        value = avalue
                        if car_map[car_id]['car_part'].get(value, None):
                            car_map[car_id]['car_part'][value] += 1
                        else:
                            car_map[car_id]['car_part'][value] = 1
                    else:
                        if action != 'switch' and avalue == 'open':
                            if not car_map[car_id].get('hotpoint', None):
                                car_map[car_id]['hotpoint'] = {}
                            value = hotpoints_map.get(car_id, {}). \
                                get(action, '')
                            if car_map[car_id]['hotpoint'].get(value, None):
                                car_map[car_id]['hotpoint'][value] += 1
                            else:
                                car_map[car_id]['hotpoint'][value] = 1
                    car_id_list.append(look.car_id)
            car_id_list = list(set(car_id_list))
            focus_car_query = session.query(FocusCar).filter(
                FocusCar.user_id == user_id,
                FocusCar.saler_id.in_(saler_id_list)).all()
            if focus_car_query:
                car_id_list = []
                for item in focus_car_query:
                    car_id_list.append(item.car_id)
            car_name_list = []
            focus_car = []
            car_id_name_map = dict()
            if car_id_list:
                for car_id in car_id_list:
                    car = session.query(Specs.logo, Series.name). \
                        join(Series, Specs.series_id == Series.id). \
                        filter(Specs.id == car_id).first()
                    if car:
                        car_name = car[1]
                        logo = car[0]
                        temp_map = dict()
                        temp_map['car_name'] = car_name
                        temp_map['car_id'] = car_id
                        temp_map['logo'] = logo
                        car_id_name_map[car_id] = car_name
                        car_name_list.append(temp_map)
            result['car_name_list'] = car_name_list
            for car_id in car_id_list:
                temp_dict = dict()
                temp_dict['car_id'] = car_id
                temp_dict['name'] = car_id_name_map.get(car_id, '')
                car_info = car_map.get(car_id, None)
                if car_info:
                    inner_color_map = car_info.get('inner_color', None)
                else:
                    inner_color_map = None
                if inner_color_map:
                    inner_color_sta = []
                    total_times = 0
                    for item in sorted(
                            list(inner_color_map.items()),
                            key=lambda x: x[0]):
                        temp_map1 = dict()
                        name = car_color_map.get(car_id, {}). \
                            get(item[0], {}).get('name', None)
                        color = car_color_map.get(car_id, {}). \
                            get(item[0], {}).get('color', '')
                        if name:
                            color_name = name
                        else:
                            color_name = item[0]
                        temp_map1['name'] = color_name
                        temp_map1['times'] = item[1]
                        temp_map1['color'] = color
                        total_times += item[1]
                        inner_color_sta.append(temp_map1)
                    inner_color_sta.sort(key=lambda x: x['times'],
                                         reverse=True)
                    for item in inner_color_sta:
                        item['total_times'] = total_times

                    temp_dict['inner_color_sta'] = inner_color_sta[:3]
                    temp_dict['inner_color'] = inner_color_sta[:2]
                else:
                    temp_dict['inner_color'] = []
                    temp_dict['inner_color_sta'] = []
                if car_info:
                    outer_color_map = car_info.get('outer_color', None)
                else:
                    outer_color_map = None
                if outer_color_map:
                    outer_color_sta = []
                    total_times = 0
                    for item in sorted(
                            list(outer_color_map.items()),
                            key=lambda x: x[0]):
                        temp_map2 = dict()
                        name = car_color_map.get(car_id, {}). \
                            get(item[0], {}).get('name', None)
                        color = car_color_map.get(car_id, {}). \
                            get(item[0], {}).get('color', '')
                        if name:
                            color_name = name
                        else:
                            color_name = item[0]
                        temp_map2['name'] = color_name
                        temp_map2['times'] = item[1]
                        temp_map2['color'] = color
                        total_times += item[1]
                        outer_color_sta.append(temp_map2)
                    outer_color_sta.sort(key=lambda x: x['times'],
                                         reverse=True)
                    for item in outer_color_sta:
                        item['total_times'] = total_times
                    temp_dict['outer_color_sta'] = outer_color_sta[:3]
                    temp_dict['outer_color'] = outer_color_sta[:2]
                else:
                    temp_dict['outer_color_sta'] = []
                    temp_dict['outer_color'] = []
                if car_info:
                    car_part_map = car_info.get('car_part', None)
                else:
                    car_part_map = None
                if car_part_map:
                    car_part_sta = []
                    total_times = 0
                    for item in sorted(
                            list(car_part_map.items()),
                            key=lambda x: x[0]):
                        query = session.query(CarWheels.logo, CarWheels.name).\
                            filter(CarWheels.car_id == car_id,
                                   CarWheels.ename == item[0]).first()
                        if query:
                            temp_map3 = dict()
                            temp_map3['times'] = item[1]
                            temp_map3['img'] = query[0]
                            temp_map3['name'] = query[1]
                            total_times += item[1]
                            car_part_sta.append(temp_map3)
                    car_part_sta.sort(key=lambda x: x['times'],
                                      reverse=True)
                    for item in car_part_sta:
                        item['total_times'] = total_times
                    temp_dict['car_part_sta'] = car_part_sta[:3]
                    temp_dict['car_part'] = car_part_sta[:2]
                else:
                    temp_dict['car_part_sta'] = []
                    temp_dict['car_part'] = []
                if car_info:
                    hotpoint_map = car_info.get('hotpoint', None)
                else:
                    hotpoint_map = None
                if hotpoint_map:
                    hotpoint_sta = []
                    total_times = 0
                    for item in sorted(
                            list(hotpoint_map.items()),
                            key=lambda x: x[0]):
                        temp_map4 = dict()
                        temp_map4['name'] = item[0]
                        temp_map4['times'] = item[1]
                        total_times += item[1]
                        hotpoint_sta.append(temp_map4)
                    hotpoint_sta.sort(key=lambda x: x['times'],
                                      reverse=True)
                    for item in hotpoint_sta:
                        item['total_times'] = total_times
                    temp_dict['hotpoint_sta'] = hotpoint_sta[:3]
                else:
                    temp_dict['hotpoint_sta'] = []
                focus_car.append(temp_dict)
            result['focus_car'] = focus_car
            self.render_json({'code': 200, 'results': result})
        else:
            self.render_json({'code': 406, 'msg': '参数错误'})
