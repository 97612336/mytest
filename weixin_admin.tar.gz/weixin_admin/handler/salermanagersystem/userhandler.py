# coding=utf-8

from __future__ import absolute_import, print_function
from .basehandler import BaseHandler
import logging
import datetime
import os
from tornado.httputil import urlencode
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest)
from tornado.escape import (json_encode, json_decode)
import tornado.gen
import qrcode
import json
from io import BytesIO
import tornado.web
import datetime
from collections import defaultdict


try:
	from StringIO import StringIO
except ImportError:
	from io import BytesIO as StringIO


def __handlers(settings):
	return [
		(r"/v2/sms/data/overview", DataOverviewHandler),
		(r"/v2/sms/car/config/detail", CarConfigDetailHandler),
		(r"/v2/sms/(?P<brand_id>[1-9]\d*)/series/preference",
		 SeriesPreferenceHandler),
		(r"/v2/sms/data/preference", DataPreferenceHandler),
		(r"/v2/sms/data/trend", DataTrendHandler),
		(r"/v2/sms/user/inform", UserInformHandler),
	]


class DataOverviewHandler(BaseHandler):
	def get(self):
		saler_id = self.session_saler_info('id', 0)
		session = self.DB()
		UserStatus = self.model('user_status')
		DealerSpec = self.model('dealer_spec')
		Brands = self.model('brands')
		Series = self.model('series')
		Specs = self.model('specs')
		Look = self.model('look')
		Salers = self.model('salers')
		CarColor = self.model('car_color')
		DealerBrand = self.model('dealer_brand')
		CarWheels = self.model('car_wheels')
		key_overview = dict()
		results = dict()
		dealer_id = self.session_saler_info('dealer_id', 0)
		perm = self.session_saler_info('perm', 0)
		saler_id_list = []
		if perm == 1 or perm == '1':
			saler_query = session.query(Salers.id). \
				filter(Salers.dealer_id == dealer_id).all()
			for saler in saler_query:
				saler_id_list.append(saler[0])
		else:
			saler_id_list.append(saler_id)
		look_users_id = session.query(Look.user_id).\
			filter(Look.saler_id.in_(saler_id_list))
		user_status = session.query(UserStatus).filter(
			UserStatus.saler_id.in_(saler_id_list),
			UserStatus.user_id.in_(look_users_id)
		).all()

		infos = session.query(Brands.id, Brands.name, Series.id, Series.name).\
			join(Series, Brands.id == Series.brand_id). \
			join(DealerBrand, DealerBrand.brand_id == Brands.id). \
			filter(DealerBrand.dealer_id == dealer_id,
				   Brands.status == 1, DealerBrand.onsell == 1).all()
		brand_dealer_info_map = dict()
		for info in infos:
			brand_id = info[0]
			brand_name = info[1]
			series_id = info[2]
			series_name = info[3]
			if brand_dealer_info_map.get(brand_id, None):
				tem_map = {'id': series_id, 'name': series_name}
				brand_dealer_info_map[brand_id]['series'].append(tem_map)
			else:
				brand_dealer_info_map[brand_id] = dict()
				brand_dealer_info_map[brand_id]['name'] = brand_name
				brand_dealer_info_map[brand_id]['series'] = \
					[{'id': series_id, 'name': series_name}]
		brand_dealer_info_list = []
		for brand_id in brand_dealer_info_map:
			tem_map = dict()
			tem_map['id'] = brand_id
			tem_map['name'] = brand_dealer_info_map[brand_id]['name']
			tem_map['series'] = brand_dealer_info_map[brand_id]['series']
			brand_dealer_info_list.append(tem_map)
		key_overview['brand_dealer_info_list'] = brand_dealer_info_list
		user_id_list = []
		for item in user_status:
			uid = item.user_id
			if uid not in user_id_list:
				user_id_list.append(uid)
		total_users = len(user_id_list)
		key_overview['total_users'] = total_users
		car_order_num = 0
		car_bill_date_num_map = defaultdict(defaultdict)
		car_deal_date_num_map = defaultdict(defaultdict)
		# intention_user_num = 0
		for item in user_status:
			car_id = item.car_id
			created_at = item.created_at
			date = created_at.date()
			# if item.status in [2, 3, 4]:
			# 	intention_user_num += 1
			if item.status in [2, 3, 4, 6, 7]:
				car_order_num += 1
				if car_bill_date_num_map.get(car_id, {}).get(date, 0):
					car_bill_date_num_map[car_id][date] += 1
				else:
					car_bill_date_num_map[car_id][date] = 1
			elif item.status == 4:
				if car_deal_date_num_map.get(car_id, {}).get(date, 0):
					car_deal_date_num_map[car_id][date] += 1
				else:
					car_deal_date_num_map[car_id][date] = 1

		key_overview['car_order_num'] = car_order_num
		car_id_query = session.query(Specs.id).join(
			DealerSpec, DealerSpec.car_id == Specs.id).\
			filter(DealerSpec.dealer_id == dealer_id).all()
		car_colors = session.query(CarColor).all()
		color_ename_name_map = defaultdict(defaultdict)
		color_ename_color_map = defaultdict(defaultdict)
		for item in car_colors:
			car_id = item.car_id
			name = item.name
			ename = item.ename
			color = item.color
			color_ename_name_map[car_id][ename] = name
			color_ename_color_map[car_id][ename] = color

		brand_id_name_map = dict()
		car_brand_map = dict()
		brand_series_map = dict()
		car_series_map = dict()
		series_id_name_map = dict()
		series_car_map = dict()
		for query in car_id_query:
			car_id = query[0]
			brand = \
				session.query(Brands.id, Brands.name, Series.id, Series.name).\
				join(Series, Brands.id == Series.brand_id).\
				join(Specs, Specs.series_id == Series.id).\
				filter(Specs.id == car_id).first()
			if brand:
				brand_id = brand[0]
				brand_name = brand[1]
				series_id = brand[2]
				car_brand_map[car_id] = brand_id
				brand_id_name_map[brand_id] = brand_name
				if brand_series_map.get(brand_id, None):
					brand_series_map[brand_id].append(series_id)
				else:
					brand_series_map[brand_id] = [series_id]
				car_series_map[car_id] = series_id
				series_car_map[series_id] = car_id
				series_id_name_map[series_id] = brand[3]
		looks = session.query(Look).filter(
			Look.saler_id.in_(saler_id_list)).all()
		brand_num_map = dict()
		series_num_map = dict()
		user_look_time = dict()
		outer_color_map = dict()
		inner_color_map = dict()
		car_part_map = dict()
		look_car_date_user_map = dict()
		look_series_date_user_map = dict()

		for look in looks:
			car_id = look.car_id
			user_id = look.user_id
			if car_id and user_id:
				brand_id = car_brand_map.get(car_id, 0)
				series_id = car_series_map.get(car_id, 0)
				if brand_num_map.get(brand_id, None):
					if user_id not in brand_num_map[brand_id]['user_id']:
						brand_num_map[brand_id]['nums'] += 1
						brand_num_map[brand_id]['user_id'].append(user_id)
				else:
					brand_num_map[brand_id] = {}
					brand_num_map[brand_id]['nums'] = 1
					brand_num_map[brand_id]['user_id'] = [user_id]

				if series_num_map.get(series_id, None):
					if user_id not in series_num_map[series_id]['user_id']:
						series_num_map[series_id]['nums'] += 1
						series_num_map[series_id]['user_id'].append(user_id)
				else:
					series_num_map[series_id] = {}
					series_num_map[series_id]['nums'] = 1
					series_num_map[series_id]['user_id'] = [user_id]
				action = look.action
				avalue = look.avalue
				created_at = look.created_at
				date = created_at.date()
				series_id = car_series_map.get(car_id, 0)
				if look_series_date_user_map.get(series_id, None):
					if look_series_date_user_map[series_id].get(date, {}).\
							get('uid', None):
						if user_id not in look_series_date_user_map[series_id][date]['uid']:
							look_series_date_user_map[series_id][date]['uid'].\
								append(user_id)
					else:
						look_series_date_user_map[series_id][date]['uid'] = \
							[user_id]
				else:
					look_series_date_user_map[series_id] =\
						defaultdict(defaultdict)
					look_series_date_user_map[series_id][date]['uid'] = [user_id]
				if look_car_date_user_map.get(car_id, None):
					if look_car_date_user_map[car_id].get(date, {}).\
							get('uid', None):
						look_car_date_user_map[car_id][date]['uid'].append(user_id)
					else:
						look_car_date_user_map[car_id][date]['uid'] = [user_id]
				else:
					look_car_date_user_map[car_id] = defaultdict(defaultdict)
					look_car_date_user_map[car_id][date]['uid'] = [user_id]

				if action == 'look':
					if user_look_time.get(car_id, None):
						user_look_time[car_id][user_id][avalue] = created_at
					else:
						user_look_time[car_id] = defaultdict(defaultdict)
						user_look_time[car_id][user_id][avalue] = created_at
				elif action == 'lungu':
					if car_part_map.get(car_id, None):
						car_part_map[car_id][avalue] += 1
					else:
						car_part_map[car_id] = defaultdict(int)
						car_part_map[car_id][avalue] = 1
				elif action == 'outer_color':
					if outer_color_map.get(car_id, None):
						outer_color_map[car_id][avalue] += 1
					else:
						outer_color_map[car_id] = defaultdict(int)
						outer_color_map[car_id][avalue] = 1
				elif action == 'inner_color':
					if inner_color_map.get(car_id, None):
						inner_color_map[car_id][avalue] += 1
					else:
						inner_color_map[car_id] = defaultdict(int)
						inner_color_map[car_id][avalue] = 1
		total_look_brand_nums = 0
		for key in brand_num_map:
			total_look_brand_nums += brand_num_map[key]['nums']
		brand_list = []
		for key in brand_num_map:
			tem_map = dict()
			if brand_id_name_map.get(key, 0):
				tem_map['name'] = brand_id_name_map[key]
				tem_map['id'] = key
				nums = brand_num_map[key]['nums']
				if total_look_brand_nums:
					tem_map['percent'] = \
						round(nums / total_look_brand_nums * 100)
				else:
					tem_map['percent'] = 0
				brand_list.append(tem_map)
		brand_list.sort(key=lambda x: x['percent'], reverse=True)
		key_overview['brands'] = brand_list

		series_list = []
		preference = dict()
		trend = dict()
		if brand_list:
			brand_show = brand_list[0]
			brand_id = brand_show.get('id', 0)
			series_id_list = brand_series_map.get(brand_id, 0)
			now = datetime.datetime.now()
			for series_id in series_id_list:
				tem_dict = dict()
				tem_list1 = []
				tem_list2 = []
				for day in range(8):
					tem_dict = dict()
					date = (now - datetime.timedelta(days=day)).date()
					uid_list = look_series_date_user_map.get(series_id, {}).\
						get(date, {}).get('uid', [])
					month = date.month
					day = date.day
					key = str(month) + '-' + str(day)
					tem_list1.append(key)
					tem_list2.append(len(uid_list))
				tem_dict['date'] = tem_list1
				tem_dict['nums'] = tem_list2
				tem_map = dict()
				tem_map['name'] = series_id_name_map.get(series_id, '')
				tem_map['id'] = series_id
				nums = series_num_map.get(series_id, {}).get('nums', 0)
				brand_look_num1 = brand_num_map.get(brand_id, {}).\
					get('nums', 0)
				if brand_look_num1:
					tem_map['percent'] = round(nums / brand_look_num1 * 100)
				else:
					tem_map['percent'] = 0
				tem_map['data'] = tem_dict
				series_list.append(tem_map)
			key_overview['series'] = series_list
			series_list.sort(key=lambda x: x['percent'], reverse=True)
			series_show = series_list[0]
			series_id = series_show.get('id', 0)
			car_id = series_car_map.get(series_id, 0)
			car_part_list = list(car_part_map.get(car_id, {}).items())
			car_part_list.sort(key=lambda x: x[1], reverse=True)
			car_part = []
			for item in car_part_list:
				tem_map = dict()
				ename = item[0]
				wheel = session.query(CarWheels).filter(
					CarWheels.car_id == car_id, CarWheels.ename == ename).\
					first()

				if wheel:
					tem_map['name'] = wheel.name
					tem_map['logo'] = wheel.logo
					car_part.append(tem_map)
			preference['car_part'] = car_part

			user_look_map = user_look_time.get(car_id, None)
			if user_look_map:
				user_num = len(user_look_map)
				seconds = 0
				for item in user_look_map:
					if user_look_map[item].get('begin', None):
						if user_look_map[item].get('end', None):
							begin = user_look_map[item].get('begin')
							end = user_look_map[item].get('end')
							seconds += (end - begin).total_seconds()
						else:
							seconds += 300
				avg_look_time = round(seconds / (user_num * 60))
			else:
				avg_look_time = 0
			preference['avg_look_time'] = avg_look_time
			if total_users:
				preference['buy_intention_rate'] = \
					round(car_order_num / total_users * 100)
			else:
				preference['buy_intention_rate'] = 0
			total_inner_color_num = 0
			inner_list = []
			if inner_color_map.get(car_id, None):
				for color in inner_color_map[car_id]:
					total_inner_color_num += inner_color_map[car_id][color]

				for color in inner_color_map[car_id]:
					tem_map = dict()
					if color_ename_name_map.get(car_id, {}).get(color, None):
						name = color_ename_name_map[car_id][color]
					else:
						name = color
					if color_ename_color_map.get(car_id, {}).get(color, None):
						color_value = color_ename_color_map[car_id][color]
					else:
						color_value = ''
					num = inner_color_map[car_id][color]
					if total_inner_color_num:
						rate = round(num / total_inner_color_num * 100)
					else:
						rate = 0
					tem_map['name'] = name
					tem_map['rate'] = rate
					tem_map['color_value'] = color_value
					inner_list.append(tem_map)

			total_outer_color_num = 0
			if outer_color_map.get(car_id, None):
				for color in outer_color_map[car_id]:
					total_outer_color_num += outer_color_map[car_id][color]
			outer_list = []
			if outer_color_map.get(car_id, None):
				for color in outer_color_map[car_id]:
					tem_map = dict()
					if color_ename_name_map.get(car_id, {}).get(color, None):
						name = color_ename_name_map[car_id][color]
					else:
						name = color
					num = outer_color_map[car_id][color]
					if total_outer_color_num:
						rate = round(num / total_outer_color_num * 100)
					else:
						rate = 0
					if color_ename_color_map.get(car_id, {}).get(color, None):
						color_value = color_ename_color_map[car_id][color]
					else:
						color_value = ''
					tem_map['name'] = name
					tem_map['rate'] = rate
					tem_map['color_value'] = color_value
					outer_list.append(tem_map)
			color_prefer_rate = dict()
			color_prefer_rate['outer'] = outer_list
			color_prefer_rate['inner'] = inner_list
			preference['color_prefer_rate'] = color_prefer_rate
			now = datetime.datetime.now()
			date_look_num_list = []
			date_bill_num_list = []
			date_deal_num_list = []

			for day in range(30):
				tem_map = dict()
				date = (now - datetime.timedelta(days=day)).date()
				month = date.month
				day = date.day
				look_num = look_car_date_user_map.get(car_id, {}).\
					get(date, {}).get('uid', [])
				tem_map['nums'] = len(set(look_num))
				tem_map['date'] = str(month) + '-' + str(day)
				date_look_num_list.append(tem_map)
				tem_map1 = dict()
				bill_num = car_bill_date_num_map.get(car_id, {}).get(date, 0)
				tem_map1['nums'] = bill_num
				tem_map1['date'] = str(month) + '-' + str(day)
				date_bill_num_list.append(tem_map1)
				tem_map2 = dict()
				deal_num = car_deal_date_num_map.get(car_id, {}).get(date, 0)
				tem_map2['nums'] = deal_num
				tem_map2['date'] = str(month) + '-' + str(day)
				date_deal_num_list.append(tem_map2)
			trend['look_num'] = date_look_num_list
			trend['bill_num'] = date_bill_num_list
			trend['deal_num'] = date_deal_num_list
		else:
			preference['car_part'] = []
			preference['avg_look_time'] = 0
			preference['buy_intention_rate'] = 0
			preference['color_prefer_rate'] = {'outer': [], 'inner': []}
			date_list = []
			now = datetime.datetime.now()
			for day in range(30):
				tem_map = dict()
				tem_map['nums'] = 0
				tem_map['date'] = (now - datetime.timedelta(days=day)).date()
				date_list.append(tem_map)
			trend['look_num'] = date_list
			trend['bill_num'] = date_list
			trend['deal_num'] = date_list
		results['key_overview'] = key_overview
		results['preference'] = preference
		results['trend'] = trend
		self.render_json({'code': 200, 'results': results})


class CarConfigDetailHandler(BaseHandler):

	def get(self):
		car_id = self.get_argument_int('car_id')
		connection = self.get_afsaas_connection()
		head = dict()
		session = self.DB()
		Series = self.model('series')
		Specs = self.model('specs')
		series_info = session.query(Series.name, Series.logo).\
			join(Specs, Series.id == Specs.series_id).\
			filter(Specs.id == car_id).first()
		if series_info:
			head['series_name'] = series_info[0]
			head['series_logo'] = series_info[1]
		else:
			head['series_name'] = ''
			head['series_logp'] = ''
		with connection.cursor() as cursor:
			query_sql = 'select * from specs where id="%s"' % car_id
			cursor.execute(query_sql)
			spec = cursor.fetchone()
			if spec:
				config = spec.get('config', None)
				if config:
					config = json_decode(config)
					i1 = spec.get('i1', '')
					head['name'] = i1
					i2 = spec.get('i2', 0)
					if i2:
						i2 = int(float(i2.strip('万')) * 10000)
					head['price'] = i2
					i3 = spec.get('i3', '')
					i4 = spec.get('i4', '')
					i5 = spec.get('i5', '')
					i6 = spec.get('i6', '')
					i7 = spec.get('i7', '')
					i8 = spec.get('i8', '')
					i9 = spec.get('i9', '')
					i10 = spec.get('i10', '')
					i11 = spec.get('i11', '')
					i12 = spec.get('i12', '')
					i13 = spec.get('i13', '')
					i14 = spec.get('i14', '')
					i15 = spec.get('i15', '')
					basic_para_map = dict(
						i1='车型名称',
						i2='厂商指导价(元)',
						i3='厂商',
						i4='级别',
						i5='发动机',
						i6='变速箱',
						i7='长*宽*高(mm)',
						i8='车身结构',
						i9='最高车速(km/h)',
						i10='官方0-100km/h加速(s)',
						i11='实测0-100km/h加速(s)',
						i12='实测100-0km/h制动(m)',
						i13='实测油耗(L/100km)',
						i14='工信部综合油耗(L/100km)',
						i15='实测离地间隙(mm)',
					)
					car_body_map = dict(
						i16='整车质保',
						i17='长度(mm)',
						i18='宽度(mm)',
						i19='高度(mm)',
						i20='轴距(mm)',
						i21='前轮距(mm)',
						i22='后轮距(mm)',
						i23='最小离地间隙(mm)',
						i24='整备质量(kg)',
						i25='车身结构',
						i26='车门数(个)',
						i27='座位数(个)',
						i28='油箱容积(L)',
						i29='行李厢容积(L)',
					)
					engine_map = dict(
						i30='发动机型号',
						i31='排量(mL)',
						i32='排量(L)',
						i33='进气形式',
						i34='气缸排列形式',
						i35='气缸数(个)',
						i36='每缸气门数(个)',
						i37='压缩比',
						i38='配气机构',
						i39='缸径(mm)',
						i40='行程(mm)',
						i41='最大马力(Ps)',
						i42='最大功率(kW)',
						i43='最大功率转速(rpm)',
						i44='最大扭矩(N·m)',
						i45='最大扭矩转速(rpm)',
						i46='发动机特有技术',
						i47='燃料形式',
						i48='燃油标号',
						i49='供油方式',
						i50='缸盖材料',
						i51='缸体材料',
						i52='环保标准',
					)
					electric_map = dict(
						i53='电动机总功率(kW)',
						i54='电动机总扭矩(N·m)',
						i55='前电动机最大功率(kW)',
						i56='前电动机最大扭矩(N·m)',
						i57='后电动机最大功率(kW)',
						i58='后电动机最大扭矩(N·m)',
						i59='工信部续航里程(km)',
						i60='电池容量(kWh)',
						i61='电池充电时间',
						i62='充电桩价格',
					)
					gear_map = dict(
						i63='简称',
						i64='挡位个数',
						i65='变速箱类型',
					)

					bottom_map = dict(
						i66='驱动方式',
						i67='四驱形式',
						i68='中央差速器结构',
						i69='前悬架类型',
						i70='后悬架类型',
						i71='助力类型',
						i72='车体结构',
					)
					brake_map = dict(
						i73='前制动器类型',
						i74='后制动器类型',
						i75='驻车制动类型',
						i76='前轮胎规格',
						i77='后轮胎规格',
						i78='备胎规格',
					)
					safe_map = dict(
						i79='主/副驾驶座安全气囊',
						i80='前/后排侧气囊',
						i81='前/后排头部气囊(气帘)',
						i82='膝部气囊',
						i83='胎压监测装置',
						i84='零胎压继续行驶',
						i85='安全带未系提示',
						i86='ISOFIX儿童座椅接口',
						i87='发动机电子防盗',
						i88='车内中控锁',
						i89='遥控钥匙',
						i90='无钥匙启动系统',
						i91='无钥匙进入系统',
					)
					handle_map = dict(
						i92='ABS防抱死',
						i93='制动力分配(EBD/CBC等)',
						i94='刹车辅助(EBA/BAS/BA等)',
						i95='牵引力控制(ASR/TCS/TRC等)',
						i96='车身稳定控制(ESC/ESP/DSC等)',
						i97='上坡辅助',
						i98='自动驻车',
						i99='陡坡缓降',
						i100='可变悬架',
						i101='空气悬架',
						i102='可变转向比',
						i103='前桥限滑差速器/差速锁',
						i104='中央差速器锁止功能',
						i105='后桥限滑差速器/差速锁',
					)
					outer_map = dict(
						i106='电动天窗',
						i107='全景天窗',
						i108='运动外观套件',
						i109='铝合金轮圈',
						i110='电动吸合门',
						i111='侧滑门',
						i112='电动后备厢',
						i113='感应后备厢',
						i114='车顶行李架',
					)
					inner_map = dict(
						i115='真皮方向盘',
						i116='方向盘调节',
						i117='方向盘电动调节',
						i118='多功能方向盘',
						i119='方向盘换挡',
						i120='方向盘加热',
						i121='方向盘记忆',
						i122='定速巡航',
						i123='前/后驻车雷达',
						i124='倒车视频影像',
						i125='行车电脑显示屏',
						i126='全液晶仪表盘',
						i127='HUD抬头数字显示',
					)
					chair_map = dict(
						i128='座椅材质',
						i129='运动风格座椅',
						i130='座椅高低调节',
						i131='腰部支撑调节',
						i132='肩部支撑调节',
						i133='主/副驾驶座电动调节',
						i134='第二排靠背角度调节',
						i135='第二排座椅移动',
						i136='后排座椅电动调节',
						i137='电动座椅记忆',
						i138='前/后排座椅加热',
						i139='前/后排座椅通风',
						i140='前/后排座椅按摩',
						i141='第三排座椅',
						i142='后排座椅放倒方式',
						i143='前/后中央扶手',
						i144='后排杯架',
					)
					video_map = dict(
						i145='GPS导航系统',
						i146='定位互动服务',
						i147='中控台彩色大屏',
						i148='蓝牙/车载电话',
						i149='车载电视',
						i150='后排液晶屏',
						i151='220V/230V电源',
						i152='外接音源接口',
						i153='CD支持MP3/WMA',
						i154='多媒体系统',
						i155='扬声器品牌',
						i156='扬声器数量',
					)
					light_map = dict(
						i157='近光灯',
						i158='远光灯',
						i159='日间行车灯',
						i160='自适应远近光',
						i161='自动头灯',
						i162='转向辅助灯',
						i163='转向头灯',
						i164='前雾灯',
						i165='大灯高度可调',
						i166='大灯清洗装置',
						i167='车内氛围灯',
					)
					glass_map = dict(
						i168='前/后电动车窗',
						i169='车窗防夹手功能',
						i170='防紫外线/隔热玻璃',
						i171='后视镜电动调节',
						i172='后视镜加热',
						i173='内/外后视镜自动防眩目',
						i174='后视镜电动折叠',
						i175='后视镜记忆',
						i176='后风挡遮阳帘',
						i177='后排侧遮阳帘',
						i178='后排侧隐私玻璃',
						i179='遮阳板化妆镜',
						i180='后雨刷',
						i181='感应雨刷',
					)
					air_condition_map = dict(
						i182='空调控制方式',
						i183='后排独立空调',
						i184='后座出风口',
						i185='温度分区控制',
						i186='车内空气调节/花粉过滤',
						i187='车载冰箱',
					)
					tech_maps = dict(
						i188='自动泊车入位',
						i189='发动机启停技术',
						i190='并线辅助',
						i191='车道偏离预警系统',
						i192='主动刹车/主动安全系统',
						i193='整体主动转向系统',
						i194='夜视系统',
						i195='中控液晶屏分屏显示',
						i196='自适应巡航',
						i197='全景摄像头',
					)
					results = []
					param_return = dict()
					basic_para = []
					for part in ['i3', 'i4', 'i5', 'i6', 'i7', 'i8', 'i9',
								 'i10', 'i11', 'i12', 'i13', 'i14', 'i15']:
						if eval(part):
							tem_dict = dict()
							tem_dict[basic_para_map[part]] = eval(part)
							basic_para.append(tem_dict)
					param_return['基本信息'] = basic_para
					results.append(param_return)
					car_body = []
					engine = []
					electric = []
					gear = []
					bottom = []
					brake = []
					safe = []
					handle = []
					outer = []
					inner = []
					chair = []
					video = []
					light = []
					glass = []
					air_condition = []
					tech = []
					for part in config:
						tem_dict = dict()
						if part in car_body_map:
							tem_dict[car_body_map[part]] = \
								self.strip_nbsp(config[part])
							car_body.append(tem_dict)
						elif part in engine_map:
							tem_dict[engine_map[part]] = \
								self.strip_nbsp(config[part])
							engine.append(tem_dict)
						elif part in gear_map:
							tem_dict[gear_map[part]] = \
								self.strip_nbsp(config[part])
							gear.append(tem_dict)
						elif part in electric_map:
							tem_dict[electric_map[part]] = \
								self.strip_nbsp(config[part])
							electric.append(tem_dict)
						elif part in bottom_map:
							tem_dict[bottom_map[part]] = \
								self.strip_nbsp(config[part])
							bottom.append(tem_dict)
						elif part in brake_map:
							tem_dict[brake_map[part]] = \
								self.strip_nbsp(config[part])
							brake.append(tem_dict)
						elif part in safe_map:
							tem_dict[safe_map[part]] = \
								self.strip_nbsp(config[part])
							safe.append(tem_dict)
						elif part in handle_map:
							tem_dict[handle_map[part]] = \
								self.strip_nbsp(config[part])
							handle.append(tem_dict)
						elif part in outer_map:
							tem_dict[outer_map[part]] = \
								self.strip_nbsp(config[part])
							outer.append(tem_dict)
						elif part in inner_map:
							tem_dict[inner_map[part]] = \
								self.strip_nbsp(config[part])
							inner.append(tem_dict)
						elif part in chair_map:
							tem_dict[chair_map[part]] = \
								self.strip_nbsp(config[part])
							chair.append(tem_dict)
						elif part in video_map:
							tem_dict[video_map[part]] = \
								self.strip_nbsp(config[part])
							video.append(tem_dict)
						elif part in light_map:
							tem_dict[light_map[part]] = \
								self.strip_nbsp(config[part])
							light.append(tem_dict)
						elif part in glass_map:
							tem_dict[glass_map[part]] = \
								self.strip_nbsp(config[part])
							glass.append(tem_dict)
						elif part in air_condition_map:
							tem_dict[air_condition_map[part]] = \
								self.strip_nbsp(config[part])
							air_condition.append(tem_dict)
						elif part in tech_maps:
							tem_dict[tech_maps[part]] = \
								self.strip_nbsp(config[part])
							tech.append(tem_dict)
					if car_body:
						param_return = dict()
						param_return['车身'] = car_body
						results.append(param_return)
					if engine:
						param_return = dict()
						param_return['发动机'] = engine
						results.append(param_return)
					if electric:
						param_return = dict()
						param_return['电动机'] = electric
						results.append(param_return)
					if gear:
						param_return = dict()
						param_return['变速箱'] = gear
						results.append(param_return)
					if bottom:
						param_return = dict()
						param_return['底盘转向'] = bottom
						results.append(param_return)
					if brake:
						param_return = dict()
						param_return['车轮制动'] = brake
						results.append(param_return)
					if safe:
						param_return = dict()
						param_return['安全装备'] = safe
						results.append(param_return)
					if handle:
						param_return = dict()
						param_return['操控配置'] = handle
						results.append(param_return)
					if outer:
						param_return = dict()
						param_return['外部配置'] = outer
						results.append(param_return)
					if inner:
						param_return = dict()
						param_return['内部配置'] = inner
						results.append(param_return)
					if chair:
						param_return = dict()
						param_return['座椅配置'] = chair
						results.append(param_return)
					if video:
						param_return = dict()
						param_return['多媒体配置'] = video
						results.append(param_return)
					if light:
						param_return = dict()
						param_return['灯光配置'] = light
						results.append(param_return)
					if glass:
						param_return = dict()
						param_return['玻璃/后视镜'] = glass
						results.append(param_return)
					if air_condition:
						param_return = dict()
						param_return['空调/冰箱'] = air_condition
						results.append(param_return)
					if tech:
						param_return = dict()
						param_return['高科技配置'] = tech
						results.append(param_return)
					return self.render_json({'code': 200, 'results': results,
											 'head': head})
				return
			results = []
			for key in ['车身', '发动机', '电动机', '变速箱', '底盘转向',
						'车轮制动', '安全装备', '操控配置', '外部配置',
						'内部配置', '座椅配置', '多媒体配置', '灯光配置',
						'玻璃/后视镜', '空调/冰箱', '高科技配置']:
				param_return = dict()
				param_return[key] = {}
				results.append(param_return)
			return self.render_json({'code': 200, 'results': results,
									 'head': {'name': '', 'price': 0}})


class SeriesPreferenceHandler(BaseHandler):
	def get(self, brand_id):
		self.brand_id = int(brand_id)
		saler_id = self.session_saler_info('id', 0)
		dealer_id = self.session_saler_info('dealer_id', 0)
		session = self.DB()
		Series = self.model('series')
		Specs = self.model('specs')
		DealerSpec = self.model('dealer_spec')
		Brands = self.model('brands')
		Look = self.model('look')
		Salers = self.model('salers')
		brand_series_map = dict()
		car_id_query = session.query(Specs.id).join(
			DealerSpec, DealerSpec.car_id == Specs.id). \
			filter(DealerSpec.dealer_id == dealer_id).all()
		now = datetime.datetime.now()
		saler_id_list = []
		dealer_id = self.session_saler_info('dealer_id', 0)
		perm = self.session_saler_info('perm', 0)
		if perm == 1 or perm == '1':
			saler_query = session.query(Salers.id). \
				filter(Salers.dealer_id == dealer_id).all()
			for saler in saler_query:
				saler_id_list.append(saler[0])
		else:
			saler_id_list.append(saler_id)
		series_list = []
		looks = session.query(Look).filter(
			Look.saler_id.in_(saler_id_list)).all()
		car_brand_map = dict()
		car_series_map = dict()
		series_car_map = dict()
		series_id_name_map = dict()
		brand_num_map = dict()
		series_num_map = dict()
		look_series_date_user_map = dict()
		for query in car_id_query:
			car_id = query[0]
			brand = \
				session.query(Brands.id, Brands.name, Series.id, Series.name).\
				join(Series, Brands.id == Series.brand_id).\
				join(Specs, Specs.series_id == Series.id).\
				filter(Specs.id == car_id).first()
			brand_id = brand[0]
			series_id = brand[2]
			car_brand_map[car_id] = brand_id
			if brand_series_map.get(brand_id, None):
				brand_series_map[brand_id].append(series_id)
			else:
				brand_series_map[brand_id] = [series_id]
			car_series_map[car_id] = series_id
			series_car_map[series_id] = car_id
			series_id_name_map[series_id] = brand[3]
		for look in looks:
			car_id = look.car_id
			user_id = look.user_id
			brand_id = car_brand_map.get(car_id, 0)
			series_id = car_series_map.get(car_id, 0)
			if brand_id and series_id:
				if brand_num_map.get(brand_id, None):
					if user_id not in brand_num_map[brand_id]['user_id']:
						brand_num_map[brand_id]['nums'] += 1
						brand_num_map[brand_id]['user_id'].append(user_id)
				else:
					brand_num_map[brand_id] = {}
					brand_num_map[brand_id]['nums'] = 1
					brand_num_map[brand_id]['user_id'] = [user_id]

				if series_num_map.get(series_id, None):
					if user_id not in series_num_map[series_id]['user_id']:
						series_num_map[series_id]['nums'] += 1
						series_num_map[series_id]['user_id'].append(user_id)
				else:
					series_num_map[series_id] = {}
					series_num_map[series_id]['nums'] = 1
					series_num_map[series_id]['user_id'] = [user_id]
				created_at = look.created_at
				date = created_at.date()
				series_id = car_series_map.get(car_id, 0)
				if look_series_date_user_map.get(series_id, None):
					if look_series_date_user_map[series_id].get(date, {}).\
							get('uid', None):
						if user_id not in look_series_date_user_map[series_id][date]['uid']:
							look_series_date_user_map[series_id][date]['uid'].\
								append(user_id)
					else:
						look_series_date_user_map[series_id][date]['uid'] = \
							[user_id]
				else:
					look_series_date_user_map[series_id] = \
						defaultdict(defaultdict)
					look_series_date_user_map[series_id][date]['uid'] = \
						[user_id]
		series_id_list = brand_series_map.get(self.brand_id, [])
		for series_id in series_id_list:
			tem_dict = dict()
			tem_list1 = []
			tem_list2 = []
			for day in range(8):
				tem_dict = dict()
				date = (now - datetime.timedelta(days=day)).date()
				uid_list = look_series_date_user_map.get(series_id, {}). \
					get(date, {}).get('uid', [])
				month = date.month
				day = date.day
				key = str(month) + '-' + str(day)
				tem_list1.append(key)
				tem_list2.append(len(uid_list))
			tem_dict['date'] = tem_list1
			tem_dict['nums'] = tem_list2
			tem_map = dict()
			tem_map['name'] = series_id_name_map[series_id]
			tem_map['id'] = series_id
			nums = series_num_map.get(series_id, {}).get('nums', 0)
			brand_look_num1 = brand_num_map.get(self.brand_id, {}).get('nums', 0)
			if brand_look_num1:
				tem_map['percent'] = round(nums / brand_look_num1 * 100)
			else:
				tem_map['percent'] = 0
			tem_map['data'] = tem_dict
			series_list.append(tem_map)
		series_list.sort(key=lambda x: x['percent'], reverse=True)
		self.render_json({'code': 200, 'results': series_list})


class DataPreferenceHandler(BaseHandler):
	def get(self):
		series_id = self.get_argument_int('series_id')
		saler_id = self.session_saler_info('id', 0)
		session = self.DB()
		UserStatus = self.model('user_status')
		DealerSpec = self.model('dealer_spec')
		Brands = self.model('brands')
		Series = self.model('series')
		Specs = self.model('specs')
		Look = self.model('look')
		CarColor = self.model('car_color')
		CarWheels = self.model('car_wheels')
		Salers = self.model('salers')
		key_overview = dict()
		car_id_para = 0
		car_id_query = session.query(Specs.id).\
			join(Series, Specs.series_id == Series.id).\
			filter(Series.id == series_id).first()
		logging.debug('car_id_query:%s', car_id_query)
		if car_id_query:
			car_id_para = car_id_query[0]
		else:
			self.render_json({'code': 406, 'msg': '参数有误'})
			return

		saler_id_list = []
		dealer_id = self.session_saler_info('dealer_id', 0)
		perm = self.session_saler_info('perm', 0)
		if perm == 1 or perm == '1':
			saler_query = session.query(Salers.id). \
				filter(Salers.dealer_id == dealer_id).all()
			for saler in saler_query:
				saler_id_list.append(saler[0])
		else:
			saler_id_list.append(saler_id)

		user_status = session.query(UserStatus).filter(
			UserStatus.saler_id.in_(saler_id_list)).all()
		user_id_list = []
		for item in user_status:
			uid = item.user_id
			if uid not in user_id_list:
				user_id_list.append(uid)
		total_users = len(user_id_list)
		car_order_num = 0
		car_bill_date_num_map = defaultdict(defaultdict)
		car_deal_date_num_map = defaultdict(defaultdict)
		# intention_user_num = 0
		for item in user_status:
			car_id = item.car_id
			created_at = item.created_at
			date = created_at.date()
			# if item.status in [2, 3, 4]:
			# 	intention_user_num += 1
			if item.status in [2, 3, 4, 6, 7]:
				car_order_num += 1
				if car_bill_date_num_map.get(car_id, {}).get(date, 0):
					car_bill_date_num_map[car_id][date] += 1
				else:
					car_bill_date_num_map[car_id][date] = 1
			elif item.status == 4:
				if car_deal_date_num_map.get(car_id, {}).get(date, 0):
					car_deal_date_num_map[car_id][date] += 1
				else:
					car_deal_date_num_map[car_id][date] = 1

		key_overview['car_order_num'] = car_order_num
		dealer_id = self.session_saler_info('dealer_id', 0)
		car_id_query = session.query(Specs.id).join(
			DealerSpec, DealerSpec.car_id == Specs.id). \
			filter(DealerSpec.dealer_id == dealer_id).all()
		car_colors = session.query(CarColor).all()
		color_ename_name_map = defaultdict(defaultdict)
		color_ename_color_map = defaultdict(defaultdict)
		for item in car_colors:
			car_id = item.car_id
			name = item.name
			ename = item.ename
			color = item.color
			color_ename_name_map[car_id][ename] = name
			color_ename_color_map[car_id][ename] = color

		brand_id_name_map = dict()
		car_brand_map = dict()
		brand_series_map = dict()
		car_series_map = dict()
		series_id_name_map = dict()
		series_car_map = dict()

		for query in car_id_query:
			car_id = query[0]
			brand = \
				session.query(Brands.id, Brands.name, Series.id, Series.name).\
					join(Series, Brands.id == Series.brand_id). \
					join(Specs, Specs.series_id == Series.id). \
					filter(Specs.id == car_id).first()
			brand_id = brand[0]
			brand_name = brand[1]
			series_id = brand[2]
			car_brand_map[car_id] = brand_id
			brand_id_name_map[brand_id] = brand_name
			if brand_series_map.get(brand_id, None):
				brand_series_map[brand_id].append(series_id)
			else:
				brand_series_map[brand_id] = [series_id]
			car_series_map[car_id] = series_id
			series_car_map[series_id] = car_id
			series_id_name_map[series_id] = brand[3]
		looks = session.query(Look).filter(
			Look.saler_id.in_(saler_id_list)).all()
		brand_num_map = dict()
		series_num_map = dict()
		user_look_time = dict()
		outer_color_map = dict()
		inner_color_map = dict()
		car_part_map = dict()
		look_car_date_user_map = dict()
		look_series_date_user_map = dict()
		for look in looks:
			car_id = look.car_id
			user_id = look.user_id
			brand_id = car_brand_map.get(car_id, 0)
			series_id = car_series_map.get(car_id, 0)
			if brand_id and series_id:
				if brand_num_map.get(brand_id, None):
					if user_id not in brand_num_map[brand_id]['user_id']:
						brand_num_map[brand_id]['nums'] += 1
						brand_num_map[brand_id]['user_id'].append(user_id)
				else:
					brand_num_map[brand_id] = {}
					brand_num_map[brand_id]['nums'] = 1
					brand_num_map[brand_id]['user_id'] = [user_id]

				if series_num_map.get(series_id, None):
					if user_id not in series_num_map[series_id]['user_id']:
						series_num_map[series_id]['nums'] += 1
						series_num_map[series_id]['user_id'].append(user_id)
				else:
					series_num_map[series_id] = {}
					series_num_map[series_id]['nums'] = 1
					series_num_map[series_id]['user_id'] = [user_id]
				action = look.action
				avalue = look.avalue
				created_at = look.created_at
				date = created_at.date()
				series_id = car_series_map.get(car_id, 0)
				if look_series_date_user_map.get(series_id, None):
					if look_series_date_user_map[series_id].get(date, {}). \
							get('uid', None):
						if user_id not in look_series_date_user_map[series_id].get(date, {}):
							look_series_date_user_map[series_id][date]['uid']. \
								append(user_id)
					else:
						look_series_date_user_map[series_id][date]['uid'] = \
							[user_id]
				else:
					look_series_date_user_map[series_id] = \
						defaultdict(defaultdict)
					look_series_date_user_map[series_id][date]['uid'] = [user_id]

				if look_car_date_user_map.get(car_id, None):
					if look_car_date_user_map[car_id].get(date, {}). \
							get('uid', None):
						look_car_date_user_map[car_id][date]['uid'].append(
							user_id)
					else:
						look_car_date_user_map[car_id][date]['uid'] = [user_id]
				else:
					look_car_date_user_map[car_id] = defaultdict(defaultdict)
					look_car_date_user_map[car_id][date]['uid'] = [user_id]

				if action == 'look':
					if user_look_time.get(car_id, None):
						user_look_time[car_id][user_id][avalue] = created_at
					else:
						user_look_time[car_id] = defaultdict(defaultdict)
						user_look_time[car_id][user_id][avalue] = created_at
				elif action == 'lungu':
					if car_part_map.get(car_id, None):
						car_part_map[car_id][avalue] += 1
					else:
						car_part_map[car_id] = defaultdict(int)
						car_part_map[car_id][avalue] = 1
				elif action == 'outer_color':
					if outer_color_map.get(car_id, None):
						outer_color_map[car_id][avalue] += 1
					else:
						outer_color_map[car_id] = defaultdict(int)
						outer_color_map[car_id][avalue] = 1
				elif action == 'inner_color':
					if inner_color_map.get(car_id, None):
						inner_color_map[car_id][avalue] += 1
					else:
						inner_color_map[car_id] = defaultdict(int)
						inner_color_map[car_id][avalue] = 1
		total_look_brand_nums = 0
		for key in brand_num_map:
			total_look_brand_nums += brand_num_map[key]['nums']
		brand_list = []
		for key in brand_num_map:
			tem_map = dict()
			tem_map['name'] = brand_id_name_map[key]
			tem_map['id'] = key
			nums = brand_num_map[key]['nums']
			if total_look_brand_nums:
				tem_map['percent'] = round(nums / total_look_brand_nums * 100)
			else:
				tem_map['percent'] = 0
			brand_list.append(tem_map)
		brand_list.sort(key=lambda x: x['percent'], reverse=True)
		key_overview['brands'] = brand_list

		preference = dict()
		if brand_list:
			car_id = car_id_para
			car_part_list = list(car_part_map.get(car_id, {}).items())
			car_part_list.sort(key=lambda x: x[1], reverse=True)
			car_part = []
			for item in car_part_list:
				tem_map = dict()
				ename = item[0]
				wheel = session.query(CarWheels).filter(CarWheels.car_id == car_id, CarWheels.ename == ename).first()
				if wheel:
					tem_map['name'] = wheel.name
					tem_map['logo'] = wheel.logo
					car_part.append(tem_map)
			preference['car_part'] = car_part
			user_look_map = user_look_time.get(car_id)
			if user_look_map:
				user_num = len(user_look_map)
				seconds = 0
				for _, item in user_look_map.items():
					if item.get('begin', None):
						if item.get('end', None):
							begin = item.get('begin')
							end = item.get('end')
							seconds += (end - begin).total_seconds()
						else:
							seconds += 300
				avg_look_time = round(seconds / (user_num * 60))
			else:
				avg_look_time = 0
			preference['avg_look_time'] = avg_look_time
			if total_users:
				preference['buy_intention_rate'] = \
					round(car_order_num / total_users * 100)
			else:
				preference['buy_intention_rate'] = 0

			total_inner_color_num = 0
			inner_list = []
			if inner_color_map.get(car_id, None):
				for color in inner_color_map[car_id]:
					total_inner_color_num += inner_color_map[car_id][color]

				for color in inner_color_map[car_id]:
					tem_map = dict()
					if color_ename_name_map.get(car_id, {}).get(color, None):
						name = color_ename_name_map[car_id][color]
					else:
						name = color
					if color_ename_color_map.get(car_id, {}).get(color, None):
						color_value = color_ename_color_map[car_id][color]
					else:
						color_value = ''
					num = inner_color_map[car_id][color]
					if total_inner_color_num:
						rate = round(num / total_inner_color_num * 100)
					else:
						rate = 0
					tem_map['name'] = name
					tem_map['rate'] = rate
					tem_map['color_value'] = color_value
					inner_list.append(tem_map)

			total_outer_color_num = 0
			if outer_color_map.get(car_id, None):
				for color in outer_color_map[car_id]:
					total_outer_color_num += outer_color_map[car_id][color]
			outer_list = []
			if outer_color_map.get(car_id, None):
				for color in outer_color_map[car_id]:
					tem_map = dict()
					if color_ename_name_map.get(car_id, {}).get(color, None):
						name = color_ename_name_map[car_id][color]
					else:
						name = color
					num = outer_color_map[car_id][color]
					if total_outer_color_num:
						rate = round(num / total_outer_color_num * 100)
					else:
						rate = 0
					if color_ename_color_map.get(car_id, {}).get(color, None):
						color_value = color_ename_color_map[car_id][color]
					else:
						color_value = ''
					tem_map['name'] = name
					tem_map['rate'] = rate
					tem_map['color_value'] = color_value
					outer_list.append(tem_map)
			color_prefer_rate = dict()
			color_prefer_rate['outer'] = outer_list
			color_prefer_rate['inner'] = inner_list
			preference['color_prefer_rate'] = color_prefer_rate
		else:
			preference['car_part'] = []
			preference['avg_look_time'] = 0
			preference['buy_intention_rate'] = 0
			preference['color_prefer_rate'] = {'outer': [], 'inner': []}
		self.render_json({'code': 200, 'results': preference})


class DataTrendHandler(BaseHandler):
	def get(self):
		series_id = self.get_argument_int('series_id')
		date_begin = self.get_argument('date_begin', '')
		date_end = self.get_argument('date_end', '')
		saler_id = self.session_saler_info('id', 0)
		session = self.DB()
		UserStatus = self.model('user_status')
		DealerSpec = self.model('dealer_spec')
		Brands = self.model('brands')
		Series = self.model('series')
		Specs = self.model('specs')
		Look = self.model('look')
		Salers = self.model('salers')
		CarColor = self.model('car_color')
		perm = self.session_saler_info('perm', 0)
		saler_id_list = []
		dealer_id = self.session_saler_info('dealer_id', 0)
		if perm == 1 or perm == '1':
			saler_query = session.query(Salers.id). \
				filter(Salers.dealer_id == dealer_id).all()
			for saler in saler_query:
				saler_id_list.append(saler[0])
		else:
			saler_id_list.append(saler_id)
		car_id_para = 0
		car_id_query = session.query(Specs.id). \
			join(Series, Specs.series_id == Series.id). \
			filter(Series.id == series_id).first()
		if car_id_query:
			car_id_para = car_id_query[0]
		else:
			self.render_json({'code': 406, 'msg': '参数有误'})
			return
		user_status = session.query(UserStatus).filter(
			UserStatus.saler_id.in_(saler_id_list)).all()
		car_order_num = 0
		car_bill_date_num_map = defaultdict(defaultdict)
		car_deal_date_num_map = defaultdict(defaultdict)
		# intention_user_num = 0
		for item in user_status:
			car_id = item.car_id
			created_at = item.created_at
			date = created_at.date()
			# if item.status in [2, 3, 4]:
			# 	intention_user_num += 1
			if item.status in [2, 3, 4, 6, 7]:
				car_order_num += 1
				if car_bill_date_num_map.get(car_id, {}).get(date, 0):
					car_bill_date_num_map[car_id][date] += 1
				else:
					car_bill_date_num_map[car_id][date] = 1
			elif item.status == 4:
				if car_deal_date_num_map.get(car_id, {}).get(date, 0):
					car_deal_date_num_map[car_id][date] += 1
				else:
					car_deal_date_num_map[car_id][date] = 1

		dealer_id = self.session_saler_info('dealer_id', 0)
		car_id_query = session.query(Specs.id).join(
			DealerSpec, DealerSpec.car_id == Specs.id). \
			filter(DealerSpec.dealer_id == dealer_id).all()
		car_colors = session.query(CarColor).all()
		color_ename_name_map = defaultdict(defaultdict)
		color_ename_color_map = defaultdict(defaultdict)
		for item in car_colors:
			car_id = item.car_id
			name = item.name
			ename = item.ename
			color = item.color
			color_ename_name_map[car_id][ename] = name
			color_ename_color_map[car_id][ename] = color

		brand_id_name_map = dict()
		car_brand_map = dict()
		brand_series_map = dict()
		car_series_map = dict()
		series_id_name_map = dict()
		series_car_map = dict()
		for query in car_id_query:
			car_id = query[0]
			brand = \
				session.query(Brands.id, Brands.name, Series.id, Series.name).\
					join(Series, Brands.id == Series.brand_id). \
					join(Specs, Specs.series_id == Series.id). \
					filter(Specs.id == car_id).first()
			brand_id = brand[0]
			brand_name = brand[1]
			series_id = brand[2]
			car_brand_map[car_id] = brand_id
			brand_id_name_map[brand_id] = brand_name
			if brand_series_map.get(brand_id, None):
				brand_series_map[brand_id].append(series_id)
			else:
				brand_series_map[brand_id] = [series_id]
			car_series_map[car_id] = series_id
			series_car_map[series_id] = car_id
			series_id_name_map[series_id] = brand[3]
		looks = session.query(Look).filter(
			Look.saler_id.in_(saler_id_list)).all()
		brand_num_map = dict()
		look_car_date_user_map = dict()
		look_series_date_user_map = dict()
		for look in looks:
			car_id = look.car_id
			user_id = look.user_id
			brand_id = car_brand_map.get(car_id, 0)
			if brand_num_map.get(brand_id, None):
				if user_id not in brand_num_map[brand_id]['user_id']:
					brand_num_map[brand_id]['nums'] += 1
					brand_num_map[brand_id]['user_id'].append(user_id)
			else:
				brand_num_map[brand_id] = {}
				brand_num_map[brand_id]['nums'] = 1
				brand_num_map[brand_id]['user_id'] = [user_id]
			created_at = look.created_at
			date = created_at.date()
			series_id = car_series_map.get(car_id, 0)
			if look_series_date_user_map.get(series_id, None):
				if look_series_date_user_map[series_id].get(date, {}). \
						get('uid', None):
					if user_id not in look_series_date_user_map[series_id][date]['uid']:
						look_series_date_user_map[series_id][date]['uid']. \
							append(user_id)
				else:
					look_series_date_user_map[series_id][date]['uid'] = \
						[user_id]
			else:
				look_series_date_user_map[series_id] = defaultdict(defaultdict)
				look_series_date_user_map[series_id][date]['uid'] = [user_id]

			if look_car_date_user_map.get(car_id, None):
				if look_car_date_user_map[car_id].get(date, {}). \
						get('uid', None):
					look_car_date_user_map[car_id][date]['uid'].append(user_id)
				else:
					look_car_date_user_map[car_id][date]['uid'] = [user_id]
			else:
				look_car_date_user_map[car_id] = defaultdict(defaultdict)
				look_car_date_user_map[car_id][date]['uid'] = [user_id]

		trend = dict()
		if date_begin and date_end:
			begin = datetime.datetime.strptime(date_begin, '%Y-%m-%d').date()
			end = datetime.datetime.strptime(date_end, "%Y-%m-%d").date()
		else:
			end = datetime.datetime.now().date()
			begin = end - datetime.timedelta(days=30)
		date_look_num_list = []
		date_bill_num_list = []
		date_deal_num_list = []
		days = (end - begin).days
		for day in range(days + 1):
			tem_map = dict()
			date = end - datetime.timedelta(days=day)
			month = date.month
			day = date.day
			look_num = look_car_date_user_map.get(car_id_para, {}). \
				get(date, {}).get('uid', [])
			tem_map['nums'] = len(set(look_num))
			tem_map['date'] = str(month) + '-' + str(day)
			date_look_num_list.append(tem_map)
			tem_map1 = dict()
			bill_num = car_bill_date_num_map.get(car_id_para, {}).get(date, 0)
			tem_map1['nums'] = bill_num
			tem_map1['date'] = str(month) + '-' + str(day)
			date_bill_num_list.append(tem_map1)
			tem_map2 = dict()
			deal_num = car_deal_date_num_map.get(car_id_para, {}).get(date, 0)
			tem_map2['nums'] = deal_num
			tem_map2['date'] = str(month) + '-' + str(day)
			date_deal_num_list.append(tem_map2)
		trend['look_num'] = date_look_num_list
		trend['bill_num'] = date_bill_num_list
		trend['deal_num'] = date_deal_num_list
		self.render_json({'code': 200, 'results': trend})


class UserInformHandler(BaseHandler):
	@tornado.gen.coroutine
	def get(self):
		msg = self.get_argument('msg', '')
		if msg:
			msg = '店家留言: ' + msg
		bill_id = self.get_argument_int('bill_id')
		if bill_id:
			result = yield self.wechat_info_push(bill_id, msg)
			if result == 1:
				self.render_json({'code': 200, 'msg': '信息推送成功'})
				return
			elif result == 0:
				self.render_json({'code': 500, 'msg': '服务器异常，请稍后重试！'})
				return
			elif result == 2:
				self.render_json({'code': 407, 'msg': '用户未扫码，信息推送失败'})
				return
		else:
			self.render_json({'code': 500, 'msg': '参数有误！'})
			return
