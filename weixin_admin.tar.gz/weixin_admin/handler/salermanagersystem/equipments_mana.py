# coding=utf-8

from __future__ import absolute_import, print_function

import hashlib
import time

from .basehandler import BaseHandler
import logging
import datetime
import os
import json
from tornado.httputil import urlencode
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest)
from tornado.escape import (json_encode, json_decode)
import tornado.gen
import qrcode
from app import Application

try:
	from StringIO import StringIO
except ImportError:
	from io import BytesIO as StringIO



def __handlers(settings):
	return [
		(r"/v2/sms/devices", DevicesHandler),
		(r"/v2/sms/saler", SalerHandler),
		(r"/v2/sms/saler/edit", SalerEditHandler),
		(r"/v2/sms/saler/del", SalerDelHandler),
		(r"/v2/sms/saler/reset", ResetPasswordHandler),
	]


class DevicesHandler(BaseHandler):

	def get(self):
		Devices = self.model('devices')
		Salers = self.model('salers')
		Dealers = self.model('dealers')
		session = self.DB()
		saler = self.session.get('Saler', False)
		dealer_id = saler.get('dealer_id', '')
		saler_id = saler.get('id', '')
		device_query = session.query(Devices).\
			filter(Devices.dealer_id == dealer_id)

		results = []
		dealer_query = session.query(Dealers.d_type).filter(
			Dealers.id == dealer_id).first()
		d_type = 0
		max_num_salers = 3
		if dealer_query:
			d_type = dealer_query[0]
		if d_type == 2:
			max_num_salers = 0

		for device in device_query:
			tmp = {}

			tmp['id'] = str(device.id)
			tmp['device_name'] = device.name
			tmp_t = str(device.created_at)
			tmp_t = tmp_t.split('T')[0]
			tmp_t = tmp_t.split(' ')[0]
			#tmp['created_at'] = device.created_at
			tmp['created_at'] = tmp_t
			tmp_t = str(device.expire_at)
			tmp_t = tmp_t.split('T')[0]
			tmp_t = tmp_t.split(' ')[0]
			tmp['expire_at'] = tmp_t
			tmp['salers'] = []

			salers_query = session.query(Salers, Devices).\
				join(Devices, Devices.id == Salers.device_id).\
				filter(Devices.name == device.name).all()
			for saler in salers_query:
				res = {}
				if saler[0].id != saler_id:
					res['id'] = str(saler[0].id)
					res['name'] = saler[0].name
					res['username'] = saler[0].username
					if saler[0].phone == 0:
						res['phone'] = ''
					else:
						res['phone'] = saler[0].phone
					if saler[0].created_at > saler[1].created_at:
						if saler[0].created_at < saler[1].expire_at:
							res['status'] = '使用中'
							res['status_int'] = 1
						elif saler[0].created_at > saler[1].expire_at:
							res['status'] = '已到期'
							res['status_int'] = 3
					elif saler[0].created_at > saler[1].expire_at:
						res['status'] = '已到期'
						res['status_int'] = 3
					else:
						pass
					tmp['salers'].append(res)
			results.append(tmp)

		self.render_json(dict(code=200, results=results,
							  max_num_salers=max_num_salers))


class SalerHandler(BaseHandler):
	def check_xsrf_cookie(self):
		pass

	def post(self):
		Devices = self.model('devices')
		Salers = self.model('salers')
		session = self.DB()

		device_id = self.get_argument('device_id', '')
		name = self.get_argument('name', '')
		phone = self.get_argument('phone', '')
		username = self.get_argument('username', '')
		password = self.get_argument('passwd', '')
		passwd_md5 = self.db.salers.to_password(username, password)
		saler = self.session.get('Saler', False)
		dealer_id = saler.get('dealer_id', '')
		saler_id = saler.get('id', '')
		saler_info = {}

		saler_info['device_id'] = device_id
		saler_info['name'] = name
		if phone:
			saler_info['phone'] = phone
		else:
			saler_info['phone'] = 0
		saler_info['username'] = username
		saler_info['password'] = passwd_md5
		saler_info['dealer_id'] = dealer_id
		saler_info['perm'] = 2
		saler_info['role'] = 2
		saler_info['cert_code'] = 2

		saler = self.db.salers.find_one({'username': username})
		if saler is not None and saler.id != saler_id:
			self.render_json({'code': 409, 'msg': '用户名重复'})
			return
		elif saler is None:
			res = self.db.salers.insert_one(saler_info)

			saler_info['id'] = res.id
			salers_query = session.query(Salers, Devices). \
				join(Devices, Devices.id == Salers.device_id). \
				filter(Salers.username == res.username).first()
			if salers_query is not None:
				if salers_query[0].created_at > salers_query[1].created_at:
					if salers_query[0].created_at < salers_query[1].expire_at:
						saler_info['status'] = '使用中'
						saler_info['status_int'] = 1
					elif salers_query[0].created_at > salers_query[1].expire_at:
						saler_info['status'] = '已到期'
						saler_info['status_int'] = 3
				elif salers_query[0].created_at > salers_query[1].expire_at:
					saler_info['status'] = '已到期'
					saler_info['status_int'] = 3
		if saler_info['phone'] == 0:
			saler_info['phone'] = ''

		self.render_json({'code': 200, 'results': saler_info})


class SalerEditHandler(BaseHandler):

	def check_xsrf_cookie(self):
		pass

	def post(self):
		Devices = self.model('devices')
		Salers = self.model('salers')
		session = self.DB()

		id = self.get_argument_int('id')
		if not id:
			self.render_json({'code': 403, 'msg': 'id need'})
			return

		name = self.get_argument('name', '')
		phone = self.get_argument('phone', '')
		username = self.get_argument('username', '')
		password = self.get_argument('passwd', '')
		device_id = self.get_argument('device_id', '')
		passwd_md5 = self.db.salers.to_password(username, password)
		saler_info = {}

		saler_info['name'] = name
		if phone:
			saler_info['phone'] = phone
		else:
			saler_info['phone'] = 0
		saler_info['username'] = username
		if password:
			saler_info['password'] = passwd_md5
		saler_info['device_id'] = device_id

		query_saler = {
			'id': id
		}
		saler = self.db.salers.find_one({'username': username})
		if saler and saler.id != id:
			self.render_json({'code': 409, 'msg': '用户名重复'})
			return
		elif saler is None or saler.id == id:
			self.db.salers.update_one(query_saler, {'$set': saler_info})

		saler = self.db.salers.find_one({"id": id})
		if saler:
			self.session_update_saler(saler.to_dict())

		saler_info['id'] = id
		salers_query = session.query(Salers, Devices). \
			join(Devices, Devices.id == Salers.device_id). \
			filter(Salers.id == id).first()
		if salers_query:
			if salers_query[0].created_at > salers_query[1].created_at:
				if salers_query[0].created_at < salers_query[1].expire_at:
					saler_info['status'] = '使用中'
					saler_info['status_int'] = 1
				elif salers_query[0].created_at > salers_query[1].expire_at:
					saler_info['status'] = '已到期'
					saler_info['status_int'] = 3
			elif salers_query[0].created_at > salers_query[1].expire_at:
				saler_info['status'] = '已到期'
				saler_info['status_int'] = 3

		if saler_info['phone'] == 0:
			saler_info['phone'] = ''

		self.render_json({'code': 200, 'results': saler_info})


class SalerDelHandler(BaseHandler):
	def check_xsrf_cookie(self):
		pass

	def post(self):
		id = self.get_argument_int('id')
		if not id:
			self.render_json({'code': 403, 'msg': 'id need'})
			return
		Salers = self.model('salers')
		session = self.DB()
		try:
			session.query(Salers).filter(Salers.id == id).delete()
			session.commit()
			self.render_json({'code': 200, 'msg': '删除成功'})
		except Exception as e:
			logging.debug('delete %s dealers fail %s', id, e)
			self.render_json({'code': 203, 'msg': '删除失败'})
			return

class ResetPasswordHandler(BaseHandler):
	def check_xsrf_cookie(self):
		pass

	def post(self):
		id = self.get_argument_int('id')
		passwd = self.get_argument('password', '')
		username = self.get_argument('username', '')
		password = self.db.salers.to_password(username, passwd)
		if not id:
			self.render_json({'code': 403, 'msg': 'id need'})
			return
		info = {}
		info['password'] = password
		info['username'] = username
		try:
			self.db.salers.update_one({'id': id}, {'$set': info})
			self.render_json({'code': 200, 'msg': '更新成功'})
		except Exception as e:
			self.render_json({'code': 203, 'msg': '更新失败'})
			return
