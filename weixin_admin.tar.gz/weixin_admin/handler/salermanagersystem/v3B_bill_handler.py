# coding=utf-8

from __future__ import absolute_import, print_function

from operator import itemgetter

from .basehandler import BaseHandler
import logging
import datetime
import os
from tornado.httputil import urlencode
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest)
from tornado.escape import (json_encode, json_decode)
import tornado.gen
import qrcode
import json
from io import BytesIO
import tornado.web
import datetime
from collections import defaultdict
import pypinyin

try:
    from StringIO import StringIO
except ImportError:
    from io import BytesIO as StringIO


def __handlers(settings):
    return [
        (r"/v3B/sms/user/bill", V3UserBillHandler),
        (r"/v3B/sms/user/logistics", LogisticsHandler),
        (r"/v3B/sms/user/brands", BrandsHandler),
        (r"/v3B/sms/user/series", SeriesHandler),
        (r"/v3B/sms/user/specs", SpecHandler),
        (r"/v3B/sms/finance/bill", BillLoansHandler),
        # (r"/v3B/sms/saler/info",V3BSalerInfoHandler)
    ]

class V3UserBillHandler(BaseHandler):
    def get(self):
        Bills = self.model('bills')
        Users = self.model('users')
        Specs = self.model('specs')
        Series = self.model('series')
        CarColor = self.model('car_color')
        CarWheels = self.model('car_wheels')
        UserStatus = self.model('user_status')
        session = self.DB()
        user_id = self.get_argument('user_id', '')

        bill = session.query(Bills).join(UserStatus, Bills.user_id == UserStatus.user_id). \
            filter(Bills.user_id == user_id).filter(UserStatus.status > 1). \
            order_by(Bills.id.desc()).first()
        query_user_id = session.query(Users). \
            filter(Users.id == user_id)
        if query_user_id is None:
            self.render_json({'code': 406, 'msg': '用户不存在'})
            return
        results = []
        info = {}
        if bill:
            tmp = {}
            tmp['title'] = '必要花费'
            tmp['total'] = bill.i2
            tmp['items'] = []
            kv = {}
            kv2 = {}
            kv3 = {}
            kv4 = {}
            kv['name'] = '购置税'
            kv['val'] = bill.i3
            kv2['name'] = '上牌费用'
            kv2['val'] = bill.i4
            kv3['name'] = '车船使用费'
            kv3['val'] = bill.i6
            kv4['name'] = '交通强制保险'
            kv4['val'] = bill.i5
            tmp['items'].append(kv)
            tmp['items'].append(kv2)
            tmp['items'].append(kv3)
            tmp['items'].append(kv4)
            results.append(tmp)
            tmp2 = {}
            tmp2['title'] = '商业保险'
            tmp2['total'] = bill.i7
            tmp2['items'] = []
            kv = {}
            kv2 = {}
            kv3 = {}
            kv4 = {}
            kv5 = {}
            kv6 = {}
            kv7 = {}
            kv8 = {}
            kv9 = {}
            kv['name'] = '第三方责任险'
            kv['val'] = bill.i8
            kv2['name'] = '车辆损失险'
            kv2['val'] = bill.i9
            kv3['name'] = '全车盗抢险'
            kv3['val'] = bill.i10
            kv4['name'] = '玻璃单独破碎险'
            kv4['val'] = bill.i11
            kv5['name'] = '自燃损失险'
            kv5['val'] = bill.i12
            kv6['name'] = '不计免赔特约险'
            kv6['val'] = bill.i13
            kv7['name'] = '无过责任险'
            kv7['val'] = bill.i14
            kv8['name'] = '车上人员责任险'
            kv8['val'] = bill.i15
            kv9['name'] = '车身刮痕险'
            kv9['val'] = bill.i16
            tmp2['items'].append(kv)
            tmp2['items'].append(kv2)
            tmp2['items'].append(kv3)
            tmp2['items'].append(kv4)
            tmp2['items'].append(kv5)
            tmp2['items'].append(kv6)
            tmp2['items'].append(kv7)
            tmp2['items'].append(kv8)
            tmp2['items'].append(kv9)
            results.append(tmp2)
            series_id = session.query(Specs.series_id). \
                filter(Specs.id == bill.car_id).first()
            if series_id is None:
                connection = self.get_afsaas_connection()
                with connection.cursor() as cursor:
                    query_sql = 'select series_id from specs where id="%s"' \
                                % bill.car_id
                    cursor.execute(query_sql)
                    series_query = cursor.fetchone()
                    series_id_tem = series_query.get('series_id', 0)
                    if series_id_tem:
                        query_series_sql = 'select id from specs where ' \
                                           'series_id="%s"' % series_id_tem
                        cursor.execute(query_series_sql)
                        series_id_query = cursor.fetchall()
                        car_id_list = []
                        for item in series_id_query:
                            car_id_list.append(item.get('id', 0))
                        series_id = session.query(Specs.series_id). \
                            filter(Specs.id.in_(car_id_list)).first()
                if series_id:
                    pass
                else:
                    results = []
                    info = {}
                    self.render_json({"code": 200, "feelist": results,
                                      "info": info})
                    return
            series_name = session.query(Series.name). \
                filter(Series.id == series_id[0]).first()
            series_imag = session.query(Series.logo). \
                filter(Series.id == series_id[0]).first()
            info['series_name'] = series_name[0]
            info['series_imag'] = series_imag[0]
            info['color'] = bill.color
            info["prepay"] = 0
            if bill.order_fee:
                info["prepay"] = bill.order_fee / 100
            color_rgb = session.query(CarColor.color). \
                filter(CarColor.name == bill.color).first()
            if color_rgb:
                info['color_value'] = color_rgb[0]
            else:
                info['color_value'] = ''
            info['total_cost'] = bill.total_cost

            info['car_id'] = bill.car_id
            info['hub'] = bill.hub
            hub_imag = session.query(CarWheels.logo). \
                filter(CarWheels.car_id == bill.car_id). \
                filter(CarWheels.name == bill.hub).first()
            if hub_imag:
                info['hub_imag'] = hub_imag[0]
            else:
                info['hub_imag'] = ''
            info['id'] = bill.id
            if bill.openid is None:
                info['status2'] = 0
            else:
                info['status2'] = 1
            # ===========================================================
            # v4新增选装花费栏
            schemes_dict = {}
            bill_id = bill.id
            # parts_bill 就是 bill_schemes
            bill_schemes = self.db.bill_schemes.query(). \
                filter_by(bill_id=bill_id).all()
            # category_id 字段就是 scheme_id字段
            scheme_ids = [bs.scheme_id for bs in bill_schemes]
            res_list = []
            schemes_cost = 0
            for sc_id in scheme_ids:
                tmp_dict = {}
                scheme = self.db.schemes.find_one({"id": sc_id})
                if scheme:
                    # tmp_dict["scheme_id"] = scheme.id
                    tmp_dict["name"] = scheme.name
                    # tmp_dict["price"] = scheme.price
                    tmp_dict["val"] = scheme.price
                else:
                    continue
                schemes_cost += scheme.price
                options = self.db.scheme_options.query(). \
                    filter_by(scheme_id=sc_id).all()
                op_list = []
                for op in options:
                    tmp_op_dict = dict(
                        # op_id=op.id,
                        name=op.name,
                        val=op.price
                    )
                    op_list.append(tmp_op_dict)
                tmp_dict["subItems"] = op_list
                res_list.append(tmp_dict)
            schemes_dict["items"] = res_list
            schemes_dict["title"] = "选装花费"
            schemes_dict["total"] = schemes_cost
            results.append(schemes_dict)
            # ============================================================
            # judge and change bill's status when user visit this api
            us = self.db.user_status.find_one({"user_id": user_id})
            if us:
                status = us.status
                info["status"] = status
                info["last_time"] = str(us.updated_at)
            else:
                self.render_json({"code": 504,
                                  "msg": "用户{0}状态异常！".format(user_id)})
                return
            info["end_status"] = ""
            if us.end_status is not None:
                info["end_status"] = us.end_status
        # consider v2 bills status change history
            if (us.status == 5 or us.status == 8) and us.end_status is None:
                info["end_status"] = 2
        self.render_json({"code": 200,
                          "feelist": results,
                          "info": info})


class LogisticsHandler(BaseHandler):
    def check_xsrf_cookie(self):
        pass

    def post(self):
        origin = self.get_argument('origin', '')
        destination = self.get_argument('destination', '')
        send_time = self.get_argument('send_time', '')
        car_type = self.get_argument('car_type', '')
        car_price = self.get_argument('car_price', '')
        car_num = self.get_argument('car_num', '')

        if not all((origin, destination, send_time, car_type, car_price,
                    car_num)):
            self.render_json({'code': 500, 'msg': '发车消息不可为空！'})
            return

        receiver_name = self.get_argument('receiver_name', '')
        receiver_phone = self.get_argument('receiver_phone', '')
        receiver_address = self.get_argument('receiver_address', '')
        is_invoice = self.get_argument('if_invoice', '')
        receiver_company = self.get_argument('receiver_company', '')
        tax_number = self.get_argument('tax_number', '')

        if not all((
                receiver_name, receiver_phone, receiver_address, is_invoice)):
            self.render_json({'code': 500, 'msg': '收车消息不可为空！'})
            return

        sender_name = self.get_argument('sender_name', '')
        sender_phone = self.get_argument('sender_phone', '')
        sender_address = self.get_argument('sender_address', '')

        if not all((sender_name, sender_phone, sender_address)):
            self.render_json({'code': 500, 'msg': '寄车消息不可为空！'})
            return
        try:
            origin = int(origin)
            destination = int(destination)
            car_type = int(car_type)
            car_price = int(car_price)
            car_num = int(car_num)
            receiver_phone = int(receiver_phone)
            sender_phone = int(sender_phone)
        except Exception as e:
            self.render_json({'code': 500, 'msg': '城市，车型，车价，车量，收发电话应均为数字！'})
            return

        logistics_info = dict(
            city_id_begin=origin,
            city_id_end=destination,
            send_time=send_time,
            car_type=car_type,
            car_price=car_price,
            car_num=car_num,
            receiver_name=receiver_name,
            receiver_phone=receiver_phone,
            receiver_address=receiver_address,
            is_invoice=is_invoice,
            sender_name=sender_name,
            sender_phone=sender_phone,
            sender_address=sender_address
        )

        if is_invoice == 2 or is_invoice == '2':
            if not all((receiver_company, tax_number)):
                self.render_json({'code': 500, 'msg': '发票信息不可为空！'})
                return
            logistics_info['receiver_company'] = receiver_company
            logistics_info['tax_number'] = tax_number
        saler_id = self.session_saler_info("id",0)
        if saler_id:
            logistics_info['saler_id'] = saler_id
        try:
            self.db.logistics_bill.insert_one(logistics_info)
            self.render_json(
                {'code': 200, 'msg': '您已成功发起物流发车订单，我们将会为您优选出汽车物流公司，请您保持手机畅通～'})
        except Exception as e:
            self.render_json({'code': 500, 'msg': '插入数据出错！'})


class BrandsHandler(BaseHandler):
    def check_xsrf_cookie(self):
        pass

    def get(self):
        connection = self.get_afsaas_connection()
        with connection.cursor() as cursor:
            sql = "select distinct(bid), bs.bname from (select distinct" \
                  "(brands.id) as bid,brands.name as bname, series.id as " \
                  "s_id from brands right join series on brands.id=" \
                  "series.brand_id) as bs right join specs on specs.series_id=bs.s_id"
            cursor.execute(sql)
            brands = cursor.fetchall()
        if brands:
            stand_dict = {}
            for num in range(26):
                stand = chr(num + ord('a'))
                stand_list = []
                for brand_info in brands:
                    info = {}
                    name = brand_info['bname']
                    if name:
                        p_name = ''.join(pypinyin.lazy_pinyin(name))
                        if stand == p_name[0]:
                            info['pinyin'] = p_name
                            info['id'] = brand_info['bid']
                            info['name'] = name
                            stand_list.append(info)
                if stand_list:
                    stand_dict[stand] = sorted(stand_list,
                                               key=lambda k: k['pinyin'])
            result = sorted(stand_dict.items(), key=itemgetter(0))
            results = []
            for res in result:
                dic = {}
                dic[res[0]] = res[1]
                results.append(dic)
            self.render_json({'code': 200, 'result': results})


class SeriesHandler(BaseHandler):
    def check_xsrf_cookie(self):
        pass

    def get(self):
        brand_id = self.get_argument("brand_id", "")
        connection = self.get_afsaas_connection()
        with connection.cursor() as cursor:
            sql = "select distinct(series.id),series.name from series  right join specs" \
                  " on specs.series_id=series.id where series.brand_id=%s" % brand_id
            cursor.execute(sql)
            series = cursor.fetchall()
        if series:
            self.render_json({'code': 200, 'result': series})
        else:
            self.render_json({'code': 406, 'msg': '查询不到该车系！'})


class SpecHandler(BaseHandler):
    def check_xsrf_cookie(self):
        pass

    def get(self):
        series_id = self.get_argument('series_id', '')
        connection = self.get_afsaas_connection()
        with connection.cursor() as cursor:
            sql = "select id,i1,i2 from specs where series_id=%s" % series_id
            cursor.execute(sql)
            specs = cursor.fetchall()
        for spec in specs:
            spec['name'] = spec['i1']
        if specs:
            self.render_json({'code': 200, 'results': specs})
        else:
            self.render_json({'code': 406, 'msg': '查询不到该车信息！'})


class BillLoansHandler(BaseHandler):
    def check_xsrf_cookie(self):
        pass

    def post(self):
        recv_data = self.get_argument("data", None)
        front_data = json_decode(recv_data)
        provider_info = front_data.get('provider_info')
        short_name = front_data.get('short_name')
        try:
            contract_amount = int(front_data.get('contract_amount'))
            payed_amount = int(front_data.get('payed_amount'))
            advanced_amount = int(front_data.get('advanced_amount'))
            loans_ratio = int(front_data.get('loans_ratio'))
            cash_deposit = int(front_data.get('cash_deposit'))
        except Exception as e:
            self.render_json({'code': 500, 'msg': '金额必须为整数！'})
            return
        purchase_contract = front_data.get('purchase_contract')
        payed_proof = front_data.get('payed_proof')
        procedure_letter = front_data.get('procedure_letter')

        if not all((provider_info, contract_amount, payed_amount,
                    advanced_amount, loans_ratio, cash_deposit,
                    purchase_contract,
                    payed_proof, procedure_letter)):
            self.render_json({'code': 500, 'msg': '除选填信息外，其他信息不可为空！'})
            return

        car_info = front_data.get('car_info')
        if car_info:
            car_info = car_info[0]
        try:
            car_type = int(car_info['car_type'])
            car_id = int(car_info['car_id'])
            num = int(car_info['num'])
            price = int(car_info['price'])
        except Exception as e:
            self.render_json(
                {'code': 500, 'msg': 'car_type,car_id,num,price必须为数字！'})
            return

        color = car_info['color']
        if not all((car_type, car_id, color, num, price)):
            self.render_json({'code': 500, 'msg': '车辆信息不可为空！'})
            return
        loans_info = dict(
            info=provider_info,
            car_type=car_type,
            car_id=car_id,
            car_color=color,
            car_num=num,
            car_price=price,
            short_name=short_name,
            contract_fee=contract_amount,
            payed=payed_amount,
            pay_in=advanced_amount,
            ratio=loans_ratio,
            deposit=cash_deposit,
            pic_purchase=purchase_contract,
            pic_payed=payed_proof,
            pic_procedure=procedure_letter,
            saler_id=self.saler_id
        )

        try:
            self.db.bill_loans.insert_one(loans_info)
            self.render_json(
                {'code': 200, 'msg': '您已成功发起物流发车订单，我们将会为您优选出汽车物流公司，请您保持手机畅通～'})
        except Exception as e:

            self.render_json({'code': 500, 'msg': '数据插入失败！'})


class V3BSalerInfoHandler(BaseHandler):

    def get(self):
        saler_id = self.session_saler_info('id', 0)
        session = self.DB()
        Salers = self.model('salers')
        saler_Info = session.query(Salers.name,
                                   Salers.phone,
                                   Salers.address,
                                   Salers.city,
                                   Salers.role,
                                   Salers.cert_code,
                                   Salers.avatar,
                                   Salers.username). \
            filter(Salers.id == saler_id).first()

        name = saler_Info[0]
        phone = saler_Info[1]
        address = saler_Info[2]
        city = saler_Info[3]
        role = saler_Info[4]
        cert_code = saler_Info[5]
        avatar = saler_Info[6]

        if not avatar:
            avatar = ''
        if avatar == 'None':
            avatar = ''

        username = saler_Info[7]
        pro_dict = {}
        if city:
            Area = self.model('areas')
            city_info = tuple(self.DB.query(Area.id, Area.name, Area.pid). \
                              filter(Area.id == int(city)).first())
            pro_info = self.DB.query(Area.id, Area.name, Area.pid). \
                filter(Area.id == city_info[2]).first()
            city_dict = {}
            city_dict['id'] = city_info[0]
            city_dict['name'] = city_info[1]
            pro_dict['id'] = pro_info[0]
            pro_dict['name'] = pro_info[1]
            pro_dict['city'] = city_dict

        weixin_name = ''
        status = 0
        qrcode = ''
        res = self.db.wechat_bind.find_one({"saler_id": saler_id})
        if res and res.openid is not None:
            status = 1
            res_saler_id = res.saler_id
            weixin_name = session.query(Salers.name). \
                filter(Salers.id == res_saler_id).first()[0]
        else:
            qrcode = "https://cheyixiao.autoforce.net/static" \
                     "/qrcode/chexiaoyi.jpg"

        results = dict(salers_name=name,
                       salers_phone=phone,
                       salers_address=address,
                       salers_city=pro_dict,
                       salers_role=role,
                       salers_certcode=cert_code,
                       salers_avatar=avatar,
                       status=status,
                       weixin_name=weixin_name,
                       qrcode=qrcode,
                       saler_username=username
                       )
        if role == 1 or role == 2:
            dealer_id = session.query(Salers.dealer_id). \
                filter(Salers.id == saler_id).first()[0]
            Dealers = self.model('dealers')
            dealers_info = session.query(Dealers.name, Dealers.company,
                                         Dealers.address,
                                         Dealers.call, Dealers.ch_name,
                                         Dealers.phone,
                                         Dealers.bus_licence,
                                         Dealers.pic_door, Dealers.pic_show,
                                         Dealers.pic_rest, Dealers.pic_other). \
                filter(Dealers.id == dealer_id).first()
            if dealers_info:
                dealers_name = dealers_info[0]
                dealers_company = dealers_info[1]
                dealers_address = dealers_info[2]
                dealers_call = dealers_info[3]
                dealers_chname = dealers_info[4]
                dealers_phone = dealers_info[5]
                dealers_buslicense = dealers_info[6]
                pic_door = dealers_info[7]
                pic_show = dealers_info[8]
                pic_rest = dealers_info[9]
                pic_other = dealers_info[10]
            else:
                dealers_name = ''
                dealers_company = ''
                dealers_address = ''
                dealers_call = ''
                dealers_chname = ''
                dealers_phone = ''
                dealers_buslicense = ''
                pic_door = ''
                pic_show = ''
                pic_rest = ''
                pic_other = ''
            results['dealers_name'] = dealers_name
            results['dealers_company'] = dealers_company
            results['dealers_address'] = dealers_address
            results['dealers_call'] = dealers_call
            results['dealers_chname'] = dealers_chname
            results['dealers_phone'] = dealers_phone
            results['dealers_buslicense'] = dealers_buslicense
            results['pic_door'] = pic_door
            results['pic_show'] = pic_show
            results['pic_rest'] = pic_rest
            results['pic_other'] = pic_other

        elif role == 3:
            ID_info = self.DB.query(Salers.ID_face, Salers.ID_con). \
                filter(Salers.id == saler_id).first()
            ID_face = ID_info[0]
            ID_con = ID_info[1]
            results['ID_face'] = ID_face
            results['ID_con'] = ID_con
        else:
            self.render_json({'code': 203, 'msg': '该用户信息不存在'})
        if cert_code == 3:
            results['msg'] = '审核失败，请重新提交！'
        self.render_json({'results': results, 'code': 200})
