# coding=utf-8

from __future__ import absolute_import, print_function

from operator import itemgetter

from .basehandler import BaseHandler
import logging
import datetime
import os
from tornado.httputil import urlencode
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest)
from tornado.escape import (json_encode, json_decode)
import tornado.gen
import qrcode
import json
from io import BytesIO
import tornado.web
import datetime
from collections import defaultdict
import pypinyin

try:
    from StringIO import StringIO
except ImportError:
    from io import BytesIO as StringIO


def __handlers(settings):
    return [
        (r"/v4/sms/car/price/query", V4CarPriceQueryHandler),
        (r"/v4/sms/car/price/brands", V4BrandsHandler),
        (r"/v4/sms/car/price/series", V4SeriesHandler),
        (r"/v4/sms/car/price/specs", V4SpecsHandler),
        (r"/v4/sms/sell/rank", V4SellRankHandler)
    ]


class V4BrandsHandler(BaseHandler):
    # tokenpass = True

    def get(self):
        connection = self.get_afsaas_connection()
        with connection.cursor() as cursor:
            sql = "select distinct(bid), bs.bname from (select distinct" \
                  "(cheyixiao.brands.id) as bid,cheyixiao.brands.name as bname, cheyixiao.series.id as " \
                  "s_id from cheyixiao.brands right join cheyixiao.series on cheyixiao.brands.id=" \
                  "cheyixiao.series.brand_id) as bs right join cheyixiao.specs on cheyixiao.specs.series_id=bs.s_id"
            cursor.execute(sql)
            brands = cursor.fetchall()
        result = [i for i in brands if i['bname'] is not None]
        result.append({'bname': '全部', 'bid': 0})
        self.render_json({'code': 200, 'result':  sorted(result, key=lambda k: k['bid'])})


class V4SeriesHandler(BaseHandler):
    # tokenpass = True

    def get(self):
        brand_id = self.get_argument("brand_id", "")
        connection = self.get_afsaas_connection()
        with connection.cursor() as cursor:
            sql = "select distinct(se.id),se.name from cheyixiao.series as se right join cheyixiao.specs as sp" \
                  " on sp.series_id=se.id where se.brand_id=%s" % brand_id
            cursor.execute(sql)
            series = cursor.fetchall()
        if series:
            self.render_json({'code': 200, 'result': series})
        else:
            self.render_json({'code': 406, 'msg': '查询不到该车系！'})


class V4SpecsHandler(BaseHandler):
    # tokenpass = True

    def get(self):
        series_id = self.get_argument('series_id', '')
        connection = self.get_afsaas_connection()
        with connection.cursor() as cursor:
            sql = "select id,name from cheyixiao.specs as sp where sp.series_id=%s" % series_id
            cursor.execute(sql)
            specs = cursor.fetchall()

        if specs:
            self.render_json({'code': 200, 'results': specs})
        else:
            self.render_json({'code': 406, 'msg': '查询不到该车信息！'})


class V4CarPriceQueryHandler(BaseHandler):
    def _get_price(self, specs):
        if specs:
            results = []
            for spec_info in specs:
                real_price = spec_info['real_price']
                guide_price = spec_info['guide_price']
                if guide_price:
                    guide_price = float(guide_price[:guide_price.index('万')])
                else:
                    guide_price = ''
                if real_price:
                    real_price = float(real_price[:real_price.index('万')])
                    change_price = guide_price - real_price
                else:
                    real_price = ''
                    change_price = ''
                if spec_info['name'] and spec_info['se.name'] and ['sp.name']:
                    data = dict(
                        real_price=real_price,
                        guide_price=guide_price,
                        change_price=change_price,
                        brand=spec_info['name'],
                        series=spec_info['se.name'],
                        spec=spec_info['sp.name']
                    )

                    results.append(data)
            return results

    def get(self):
        brand_id = self.get_argument_int('brand_id', 0)
        series_id = self.get_argument_int('series_id', 0)
        spec_id = self.get_argument('spec_id', 0)
        page = self.get_argument_int('page', 1)
        page_size = self.get_argument_int('page_size', 10)

        results = ''
        if spec_id:
            connection = self.get_afsaas_connection()
            with connection.cursor() as cursor:
                cursor.execute("select br.name,se.name,sp.name,sp.guide_price,sp.real_price from " \
                               "cheyixiao.specs as sp left join cheyixiao.series as se on se.id=sp.series_id" \
                               " right join cheyixiao.brands as br on br.id=se.brand_id where sp.id=%s",
                               (spec_id))
                specs = cursor.fetchall()
                if specs:
                    results = self._get_price(specs)
        elif series_id:
            connection = self.get_afsaas_connection()
            with connection.cursor() as cursor:
                cursor.execute("select br.name,se.name,sp.name,sp.guide_price,sp.real_price from " \
                               "cheyixiao.specs as sp left join cheyixiao.series as se on se.id=sp.series_id" \
                               " right join cheyixiao.brands as br on br.id=se.brand_id where sp.series_id=%s",
                               (series_id))
                specs = cursor.fetchall()
                if specs:
                    results = self._get_price(specs)
        elif brand_id:
            connection = self.get_afsaas_connection()
            with connection.cursor() as cursor:
                cursor.execute("select br.name,se.name,sp.name,sp.guide_price,sp.real_price from " \
                               "cheyixiao.specs as sp left join cheyixiao.series as se on se.id=sp.series_id" \
                               " right join cheyixiao.brands as br on br.id=se.brand_id where br.id=%s",
                               (brand_id))
                specs = cursor.fetchall()
                if specs:
                    results = self._get_price(specs)
        else:
            connection = self.get_afsaas_connection()
            with connection.cursor() as cursor:
                cursor.execute("select br.name,se.name,sp.name,sp.guide_price,sp.real_price from " \
                               "cheyixiao.specs as sp left join cheyixiao.series as se on se.id=sp.series_id" \
                               " right join cheyixiao.brands as br on br.id=se.brand_id")
                specs = cursor.fetchall()

                if specs:
                    results = self._get_price(specs)
        start = (page - 1) * page_size
        end = page * page_size
        self.render_json({'code': 200, 'result': results[start:end],'count':len(results)})


class V4SellRankHandler(BaseHandler):
    def _black(self, saler_id):

        black_list = [59, 60, 61, 1, 64]
        if saler_id in black_list:
            return False
        else:
            return True

    def get(self):
        date = self.get_argument('date', '')
        if not date:
            today = datetime.datetime.today()
            date = datetime.datetime(today.year, today.month, today.day).strftime('%Y-%m')
        page_size = self.get_argument_int('page_size', 10)
        page = self.get_argument_int('page', 1)
        region = dict(
            region_north=[150000, 230000, 220000, 210000,
                          110000, 120000, 130000, 140000],
            region_east=[370000, 320000, 340000, 330000, 310000, 410000, 420000],
            region_south=[360000, 350000, 430000, 450000, 440000, 530000],
            region_west=[650000, 540000, 630000, 620000, 510000,
                         640000, 610000, 500000, 520000],
        )
        region_citys = {}
        for key, value in region.items():
            Areas = self.model('areas')
            citys = []
            for pid in value:
                city = self.DB.query(Areas.id, Areas.name).filter(Areas.pid == pid).all()
                for c in city:
                    citys.append(c[0])
            region_citys[key] = citys

        saler_id = self.session_saler_info('id', 0)
        saler = self.db.salers.find_one({'id': saler_id})
        city_id = ''
        if saler:
            city_id = saler.city
        rank_citys = {}
        for key, value in region_citys.items():
            if city_id in value:
                if key == "region_north":
                    key = "华北区"
                if key == "region_east":
                    key = "华东区"
                if key == "region_south":
                    key = "华南区"
                if key == "region_west":
                    key = "华西区"
                rank_citys['region'] = key
                rank_citys['citys'] = value
                break
        if rank_citys:
            connection = self.get_afsaas_connection()
            with connection.cursor() as cursor:
                sql = "select bs.saler_id from cheyixiao.bills " \
                      "as bs where date_format(bs.updated_at,'%Y-%m')='{}';"

                cursor.execute(sql.format(date))
                salers = cursor.fetchall()

            salers_dict = {}
            for saler_info in salers:
                salers_dict[saler_info['saler_id']] = salers.count(saler_info)

            results = []
            Salers = self.model('salers')
            for sale_id, num in salers_dict.items():
                res = {}
                saler = self.DB.query(Salers.name, Salers.city, Salers.id, Salers.dealer_id).filter(
                    Salers.id == sale_id).all()
                if saler:
                    city = saler[0][1]
                    if city in rank_citys['citys'] and self._black(saler[0][2]):
                        if int(saler[0][2]) == int(saler_id):
                            res['msg'] = 'here'
                        res['name'] = saler[0][0]
                        dealer_id = saler[0][-1]
                        dealer = self.db.dealers.find_one({'id': dealer_id})
                        dealer_name = ''
                        if dealer:
                            dealer_name = dealer.name
                        res['dealer'] = dealer_name
                        res['deal_amount'] = num
                        if res['name'] != "":
                            results.append(res)

            start = (page - 1) * page_size
            end = page * page_size
            sort_results = sorted(results, key=lambda k: -k['deal_amount'])
            my_position = ''
            for info in sort_results:
                if len(info) == 4:
                    my_position = {}
                    my_position['position'] = sort_results.index(info) + 1
                    my_position['name'] = info['name']
                    my_position['num'] = info['deal_amount']
                    my_position['dealer'] = info['dealer']
            self.render_json(
                {'code': 200, 'all_count': len(results), 'region': rank_citys['region'],
                 'results': sort_results[start:end], 'my_position': my_position})
        else:
            self.render_json({'code': 200, 'msg': '查询不到您所在区域信息！', 'all_count': 0, 'region': '',
                              'results': [], 'my_position': ''})
