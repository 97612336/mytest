# coding=utf-8

from __future__ import absolute_import, print_function

from operator import itemgetter

from .basehandler import BaseHandler
import logging
import datetime
import os
from tornado.httputil import urlencode
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest)
from tornado.escape import (json_encode, json_decode)
import tornado.gen
import qrcode
import json
from io import BytesIO
import tornado.web
import datetime
from collections import defaultdict
import pypinyin

try:
    from StringIO import StringIO
except ImportError:
    from io import BytesIO as StringIO


def __handlers(settings):
    return [
        (r"/v4/sms/car/search/all", V4CarSearchAllHandler),
        (r"/v4/sms/car/search/mine", V4CarSearchMineHandler),
        (r"/v4/sms/car/quote/receive", V4CarQuoteReceiveHandler),
        (r"/v4/sms/car/quote/release", V4CarQuoteReleaseHandler),
        (r"/v4/sms/car/status", V4CarStatusHandler),
        (r"/v4/sms/car/brands", V4CarBrands)

    ]


class V4CarBrands(BaseHandler):

    def get(self):
        connection = self.get_afsaas_connection()
        with connection.cursor() as cursor:
            sql = "select distinct(bid), bs.bname from (select distinct" \
                  "(afsaas.brands.id) as bid,afsaas.brands.name as bname, afsaas.series.id as " \
                  "s_id from afsaas.brands right join afsaas.series on afsaas.brands.id=" \
                  "afsaas.series.brand_id) as bs right join afsaas.specs on afsaas.specs.series_id=bs.s_id"
            cursor.execute(sql)
            brands = cursor.fetchall()
        result = [i for i in brands if i['bname'] is not None]
        result.append({'bname': '全部', 'bid': 0})
        self.render_json({'code': 200, 'results': sorted(result, key=lambda k: k['bid'])})


class V4CarSearchAllHandler(BaseHandler):

    def _get_results(self, series_id):
        connection = self.get_afsaas_connection()
        with connection.cursor() as cursor:
            cursor.execute("select id,i1 from specs where series_id=%s", (series_id))
            specs = cursor.fetchall()
        results = []
        if specs:
            for spec_info in specs:
                spec_id = spec_info['id']
                spec_name = spec_info['i1']
                FindCar = self.model('find_car')
                all_find = self.DB.query(FindCar.id, FindCar.color, FindCar.plate_city,
                                         FindCar.order_fee, FindCar.expect_price, FindCar.status,
                                         FindCar.created_at, FindCar.car_format, FindCar.end_time).filter(
                    FindCar.spec_id == spec_id).all()
                if all_find:
                    for find_info in all_find:
                        result = {}
                        result['spec'] = spec_name
                        result['find_id'] = find_info[0]
                        result['color'] = find_info[1]
                        city = self.db.areas.find_one({'id': find_info[2]})
                        if city:
                            city = city.name
                        result['plate_city'] = city
                        result['order_fee'] = find_info[3]
                        result['expected_price'] = find_info[4]
                        result['created_at'] = str(find_info[6])
                        result['car_format'] = find_info[7]
                        Quote = self.model('quote')
                        now = datetime.datetime.now()
                        quotes = self.DB.query(Quote.id, Quote.end_time).filter(Quote.find_id == find_info[0]).all()
                        res_quote = []
                        if quotes:
                            for info in quotes:
                                if (now - info[1]).days < 0:
                                    res_quote.append(info)

                        result['quote_num'] = len(res_quote)
                        end_time = find_info[-1]
                        now = datetime.datetime.now()
                        detal = (now - end_time).days
                        if detal > 0:
                            status = self.db.find_car.find_one_and_update(
                                {"id": find_info[0]}, {"$set": {"status": 4}}).status
                            result['status'] = status
                        else:
                            result['status'] = find_info[5]
                        if result['status'] == 1:
                            results.append(result)
        return results
    tokenpass = True
    def get(self):
        brand_id = self.get_argument_int('brand_id', 0)
        series_id = self.get_argument_int('series_id', 0)
        page = self.get_argument_int('page', 1)
        page_size = self.get_argument_int('page_size', 10)
        connection = self.get_afsaas_connection()
        results = []
        if series_id:
            results = self._get_results(series_id)
        elif brand_id:
            with connection.cursor() as cursor:
                cursor.execute("select id from series where brand_id=%s", (brand_id))
                series = cursor.fetchall()
            for series_info in series:
                series_id = series_info['id']
                result = self._get_results(series_id)
                if result:
                    results.extend(result)
        else:
            FindCar = self.model('find_car')
            all_find = self.DB.query(FindCar.id, FindCar.color, FindCar.plate_city,
                                     FindCar.order_fee, FindCar.expect_price, FindCar.status,
                                     FindCar.created_at, FindCar.car_format, FindCar.end_time, FindCar.spec_id).all()
            for find_info in all_find:
                result = {}
                with connection.cursor() as cursor:
                    cursor.execute("select i1 from specs where id=%s", (find_info[-1]))
                    spec_name = cursor.fetchall()[0]['i1']
                result['spec'] = spec_name
                result['find_id'] = find_info[0]
                result['color'] = find_info[1]
                city = self.db.areas.find_one({'id': find_info[2]})
                if city:
                    city = city.name
                result['plate_city'] = city
                result['order_fee'] = find_info[3]
                result['expected_price'] = find_info[4]
                result['created_at'] = str(find_info[6])
                result['car_format'] = find_info[7]
                Quote = self.model('quote')
                quotes = self.DB.query(Quote.id, Quote.end_time).filter(Quote.find_id == find_info[0]).all()
                now = datetime.datetime.now()
                res_quote = []
                if quotes:
                    for info in quotes:
                        if (now - info[1]).days < 0:
                            res_quote.append(info)
                result['quote_num'] = len(res_quote)
                end_time = find_info[-2]
                detal = (now - end_time).days
                if detal > 0:
                    status = self.db.find_car.find_one_and_update(
                        {"id": find_info[0]}, {"$set": {"status": 4}}).status
                    result['status'] = status
                else:
                    result['status'] = find_info[5]
                if result['status'] == 1:
                    results.append(result)
        if results:
            start = (page - 1) * page_size
            end = page * page_size
            res = sorted(results, key=lambda k: k["created_at"], reverse=True)
            self.render_json(
                {'code': 200, 'results': res[start:end],
                 'count': len(results)})
        else:
            self.render_json({'code': 200, 'results': []})


class V4CarSearchMineHandler(BaseHandler):

    def get(self):
        saler_id = self.session_saler_info('id', 0)
        page = self.get_argument_int('page', 1)
        page_size = self.get_argument_int('page_size', 10)
        FindCar = self.model('find_car')
        mine_find = self.DB.query(FindCar.id, FindCar.spec_id, FindCar.color,
                                  FindCar.created_at, FindCar.plate_city, FindCar.order_fee,
                                  FindCar.expect_price, FindCar.status, FindCar.car_format,
                                  FindCar.end_time).filter(FindCar.saler_id == saler_id).all()
        results = []
        if mine_find:
            for find_info in mine_find:
                result = {}
                result['find_id'] = find_info[0]

                with self.get_afsaas_connection().cursor() as cursor:
                    cursor.execute("select i1 from specs where id=%s", (find_info[1]))
                    spec_name = cursor.fetchall()
                result['spec'] = spec_name[0]['i1']
                result['color'] = find_info[2]
                result['created_at'] = str(find_info[3])
                city = self.db.areas.find_one({'id': find_info[4]})
                if city:
                    city = city.name
                result['plate_city'] = city
                result['order_fee'] = find_info[5]
                result['expected_price'] = find_info[6]
                result['car_format'] = find_info[8]
                end_time = find_info[-1]
                now = datetime.datetime.now()
                detal = (now - end_time).days
                if detal > 0:
                    status = self.db.find_car.find_one_and_update(
                        {"id": find_info[0]}, {"$set": {"status": 4}}).status
                    result['status'] = status
                else:
                    result['status'] = find_info[7]
                results.append(result)
        if results:
            start = (page - 1) * page_size
            end = page * page_size
            res = sorted(results, key=lambda k: (-k["status"], k["created_at"]),reverse=True)
            self.render_json(
                {'code': 200, 'results': res[start:end],
                 'count': len(results)})
        else:
            self.render_json({'code': 200, 'results': []})


class V4CarQuoteReceiveHandler(BaseHandler):

    def get(self, *args, **kwargs):
        saler_id = self.session_saler_info('id', 0)
        page = self.get_argument_int('page', 1)
        page_size = self.get_argument_int('page_size', 10)
        FindCar = self.model('find_car')
        mine_find = self.DB.query(FindCar.id, FindCar.spec_id, FindCar.color,
                                  FindCar.created_at, FindCar.plate_city, FindCar.order_fee,
                                  FindCar.expect_price, FindCar.status, FindCar.car_format,
                                  FindCar.end_time).filter(FindCar.saler_id == saler_id).all()
        results = []
        if mine_find:
            for find_info in mine_find:
                Quote = self.model('quote')
                quote = self.DB.query(Quote.id, Quote.end_time).filter(Quote.find_id == find_info[0]).all()
                now = datetime.datetime.now()
                res_quote = []
                if quote:
                    result = {}
                    for info in quote:
                        if (now - info[1]).days < 0:
                            res_quote.append(info)
                    result['quote_num'] = len(res_quote)

                    result['find_id'] = find_info[0]
                    with self.get_afsaas_connection().cursor() as cursor:
                        cursor.execute("select i1 from specs where id=%s", (find_info[1]))
                        spec_name = cursor.fetchall()
                    result['spec'] = spec_name[0]['i1']
                    result['color'] = find_info[2]
                    result['created_at'] = str(find_info[3])
                    city = self.db.areas.find_one({'id': find_info[4]})
                    if city:
                        city = city.name
                    result['plate_city'] = city
                    result['order_fee'] = find_info[5]
                    result['expected_price'] = find_info[6]
                    result['car_format'] = find_info[8]

                    end_time = find_info[-1]
                    now = datetime.datetime.now()
                    detal = (now - end_time).days
                    if detal > 0:
                        status = self.db.find_car.find_one_and_update(
                            {"id": find_info[0]}, {"$set": {"status": 4}}).status
                        result['status'] = status
                    else:
                        result['status'] = find_info[7]
                    if result['status'] == 1:
                        results.append(result)
        if results:
            start = (page - 1) * page_size
            end = page * page_size
            res = sorted(results, key=lambda k: k["created_at"], reverse=True)
            self.render_json(
                {'code': 200, 'results': res[start:end],
                 'count': len(results)})
        else:
            self.render_json({'code': 200, 'results': []})


class V4CarQuoteReleaseHandler(BaseHandler):
    def get(self):
        saler_id = self.session_saler_info('id', 0)
        page = self.get_argument_int('page', 1)
        page_size = self.get_argument_int('page_size', 10)
        Quote = self.model('quote')
        quote_info = self.DB.query(Quote.find_id, Quote.quote, Quote.created_at).filter(Quote.saler_id == saler_id).all()
        results = []
        if quote_info:
            new_quote_info = sorted(quote_info, key=lambda k: str(k[2]), reverse=True)
            for info in new_quote_info:
                find_id = info[0]
                quote = info[1]
                FindCar = self.model('find_car')
                mine_find = self.DB.query(FindCar.spec_id, FindCar.color,
                                          FindCar.created_at, FindCar.plate_city, FindCar.order_fee,
                                          FindCar.expect_price, FindCar.status, FindCar.car_format,
                                          FindCar.end_time).filter(FindCar.id == find_id).all()
                if mine_find:
                    find_info = mine_find[0]
                    result = {}
                    with self.get_afsaas_connection().cursor() as cursor:
                        cursor.execute("select i1 from specs where id=%s", (find_info[0]))
                        spec_name = cursor.fetchall()
                    result['spec'] = spec_name[0]['i1']
                    result['color'] = find_info[1]
                    result['created_at'] = str(find_info[2])
                    city = self.db.areas.find_one({'id': find_info[3]})
                    if city:
                        city = city.name
                    result['plate_city'] = city
                    result['order_fee'] = find_info[4]
                    result['expected_price'] = find_info[5]
                    result['car_format'] = find_info[7]
                    result['quote'] = quote
                    result['find_id'] = find_id
                    end_time = find_info[-1]
                    now = datetime.datetime.now()
                    detal = (now - end_time).days
                    if detal > 0:
                        status = self.db.find_car.find_one_and_update(
                            {"id": find_id}, {"$set": {"status": 4}}).status
                        result['status'] = status
                    else:
                        result['status'] = find_info[6]

                    results.append(result)
        sort_results = []
        if len(results) > 0:
            for item in results:
                if item["status"] == 1:
                    sort_results.append(item)
                    results.remove(item)
        if len(results) > 0:
            for item in results:
                if item["status"] == 2:
                    sort_results.append(item)
                    results.remove(item)
        if len(results) > 0:
            for item in results:
                if item["status"] == 4:
                    sort_results.append(item)
                    results.remove(item)
        if len(results) > 0:
            for item in results:
                if item["status"] == 3:
                    sort_results.append(item)
                    results.remove(item)
        if sort_results:
            start = (page - 1) * page_size
            end = page * page_size
            # res = sorted(results, key=lambda k: k["created_at"], reverse=True)
            self.render_json(
                {'code': 200, 'results': sort_results[start:end],
                 'count': len(sort_results)})
        else:
            self.render_json({'code': 200, 'results': []})


class V4CarStatusHandler(BaseHandler):
    def get(self, *args, **kwargs):
        find_id = self.get_argument_int('find_id', 0)
        status = self.get_argument_int('status', 0)
        if status == 2 or status == 3:
            find = self.db.find_car.find_one_and_update(
                {"id": find_id}, {"$set": {"status": status}})
            if find:
                if find.status == 2:
                    self.render_json({'code': 200, 'msg': '寻车完成！'})
                elif find.status == 3:
                    self.render_json({'code': 200, 'msg': '寻车取消！'})
        else:
            self.render_json({'code': 500, 'msg': '参数错误！'})
