# coding=utf-8

from __future__ import absolute_import, print_function

import time
from operator import itemgetter

from .basehandler import BaseHandler
import logging
import datetime
import os
from tornado.httputil import urlencode
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest)
from tornado.escape import (json_encode, json_decode)
import tornado.gen
import qrcode
import json
from io import BytesIO
import tornado.web
import datetime
from collections import defaultdict
import pypinyin

try:
    from StringIO import StringIO
except ImportError:
    from io import BytesIO as StringIO


def __handlers(settings):
    return [
        (r"/v3B/sms/data/rank", RankHandler),
        (r"/v3B/sms/data/percent", PercentHandler),
        (r"/v3B/sms/data/salers", TodaySalersHandler),
        (r"/v3B/sms/data/bills", TodayBillsHandler),
        (r"/v3B/sms/data/map", MapHandler),
        (r"/v3B/sms/data/key", KeyIndicatorsHandler),
        (r"/v3B/sms/user/area", AreaHandler),
    ]


class AreaHandler(BaseHandler):
    tokenpass = True

    def get(self):
        Areas = self.model('areas')
        areas = tuple(self.DB.query(Areas.id, Areas.name, Areas.pid).all())

        pro_dict = {}
        for info in areas:
            if info[2] == 0:
                pro_dict[info[0]] = info[1]

        area_list = []
        for pid in pro_dict:
            area_dic = {}
            citys = []
            province = {}
            for info in areas:
                if info[2] == pid:
                    city = {}
                    city['id'] = info[0]
                    city['name'] = info[1]
                    citys.append(city)

                province['citys'] = sorted(citys, key=itemgetter('id'))
                province['name'] = pro_dict[pid]
                province['id'] = pid
                area_dic['province'] = province
            area_list.append(area_dic)

        result = {}
        result['areas'] = sorted(area_list, key=lambda k: k['province']['id'])

        self.render_json({'code': 200, 'result': result})


class RankHandler(BaseHandler):
    tokenpass = True

    def get(self):
        Salers = self.model('salers')
        UserStatus = self.model('user_status')
        salers = self.DB.query(UserStatus.saler_id).filter(UserStatus.status == 4).all()
        salers_dict = {}
        for saler_id in salers:
            salers_dict[saler_id[0]] = salers.count(saler_id)
        results = []
        black_list = [3, 31, 32, 33, 34, 35, 37, 38, 39, 40, 41, 42, 43, 44, 45, 60, 63,
                      76, 4542, 4544, 4573, 4582]
        for sale_id, num in salers_dict.items():
            res = {}
            if sale_id not in black_list:
                saler = self.DB.query(Salers.name, Salers.phone).filter(Salers.id == sale_id).filter(
                    Salers.name != '').all()
                if saler:
                    res['name'] = saler[0][0]
                    res['phone'] = saler[0][1]
                    res['salernum'] = num
                    results.append(res)

        self.render_json({'code': 200, 'result': sorted(results, key=lambda k: -k['salernum'])})


class PercentHandler(BaseHandler):
    tokenpass = True

    def get(self):
        connection = self.get_afsaas_connection()
        with connection.cursor() as cursor:
            sql_look = "select count(*) as count from cheyixiao.look "
            cursor.execute(sql_look)
            look_num = cursor.fetchall()[0]["count"]

        Bills = self.model('bills')
        orders = self.DB.query(Bills.saler_id).all()
        order_num = len(orders)
        order_pencent = order_num / look_num
        look_pencent = 1 - order_pencent
        result = dict(
            look_num=look_num,
            order_num=order_num,
            look_pencent=look_pencent,
            order_pencent=order_pencent
        )
        self.render_json({'code': 200, 'result': result})


class TodaySalersHandler(BaseHandler):
    tokenpass = True

    def get(self):
        now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        today = datetime.datetime.today()
        start = datetime.datetime(today.year, today.month, today.day, 6, 0, 0).strftime('%Y-%m-%d %H:%M:%S')
        connection = self.get_afsaas_connection()
        with connection.cursor() as cursor:
            sql = "SELECT DATE_FORMAT(created_at, '%H') as date , count(*) as count FROM cheyixiao.look " \
                  "WHERE  created_at > '{start}' and created_at < '{now}'" \
                  "group by date"
            cursor.execute(sql.format(start=start, now=now))
            looks = cursor.fetchall()
        result = []
        for look in looks:
            res = {}
            res['time'] = look["date"]
            res['num'] = look["count"]
            result.append(res)
        if result:
            self.render_json({'code': 200, 'result': result})
        else:
            self.render_json({'code': 207, 'msg': '查询不到数据！'})


class TodayBillsHandler(BaseHandler):
    tokenpass = True

    def get(self):
        now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        today = datetime.datetime.today()
        start = datetime.datetime(today.year, today.month, today.day, 6, 0, 0).strftime('%Y-%m-%d %H:%M:%S')
        connection = self.get_afsaas_connection()
        with connection.cursor() as cursor:
            sql = "SELECT DATE_FORMAT(created_at, '%H'), COUNT(*) FROM cheyixiao.bills " \
                  "WHERE  created_at > '{start}' and created_at < '{now}' " \
                  "group by date_format(created_at,'%H')"
            cursor.execute(sql.format(start=start, now=now))
            bills = cursor.fetchall()
        result = []
        for look in bills:
            res = {}
            res['time'] = look["DATE_FORMAT(created_at, '%H')"]
            res['num'] = look["COUNT(*)"]
            result.append(res)
        if result:
            self.render_json({'code': 200, 'result': result})
        else:
            self.render_json({'code': 207, 'msg': '今日订单数据暂无！'})


class MapHandler(BaseHandler):
    tokenpass = True

    def get(self):
        connection = self.get_afsaas_connection()
        with connection.cursor() as cursor:
            sql = 'SELECT sl.name,sl.phone,sl.city,sl.role,' \
                  'ar.id,ar.name,ar.pid,ar.lng,ar.lat,dl.name ' \
                  'as address FROM cheyixiao.salers as sl' \
                  ' left join cheyixiao.areas as ar on sl.city=ar.id' \
                  ' right join cheyixiao.dealers as dl on sl.dealer_id=dl.id where sl.city' \
                  ' is not null and sl.role=1 and sl.id > 79 and sl.id != 4573;'
            cursor.execute(sql)
            result = cursor.fetchall()
        Areas = self.model('areas')
        provinces = self.DB.query(Areas.id, Areas.name).filter(Areas.pid == 0).all()
        citys = self.DB.query(Areas.id, Areas.name, Areas.lng, Areas.lat, Areas.pid).filter(Areas.pid != 0).all()
        Salers = self.model('salers')
        all_count = len(self.DB.query(Salers.id).all())
        c_list = []
        for city in citys:
            c_dict = {}
            saler = []
            num = 0
            for res in result:
                # name = self.db.dealers.find_one({'id':res['dealer_id']}).name
                # res['address'] = name
                c_dict['id'] = city[0]
                c_dict['name'] = city[1]
                c_dict['lng'] = city[2]
                c_dict['lat'] = city[3]
                c_dict['pid'] = city[-1]
                if city[0] == res['city']:
                    saler.append(res)
                    num += 1
            c_dict['city_saler_num'] = num
            c_dict['saler'] = saler
            c_list.append(c_dict)

        pro_list = []
        for pro in provinces:
            pro_dict = {}
            a = 0
            citys = []
            for c_info in c_list:
                pro_dict['id'] = pro[0]
                pro_dict['name'] = pro[1]
                if c_info['pid'] == pro[0]:
                    citys.append(c_info)
                    a += c_info['city_saler_num']
            pro_dict['num'] = a
            pro_dict['percent'] = a / all_count
            pro_dict['citys'] = citys
            pro_list.append(pro_dict)

        self.render_json({'code': 200, 'result': sorted(pro_list, key=lambda k: k['id'])})


class KeyIndicatorsHandler(BaseHandler):
    tokenpass = True

    def get(self):
        start = self.get_argument('start', '')
        end = self.get_argument('end', '')
        city = self.get_argument('city', '')
        typeq = self.get_argument('type', '')

        connection = self.get_afsaas_connection()

        date_list = []
        begin_date = datetime.datetime.strptime(start, "%Y-%m-%d")
        end_date = datetime.datetime.strptime(end, "%Y-%m-%d")
        while begin_date <= end_date:
            date_str = begin_date.strftime("%Y-%m-%d")
            date_list.append(date_str)
            begin_date += datetime.timedelta(days=1)

        if typeq == 'salers':
            with connection.cursor() as cursor:
                sql = " select count(*),date_format(created_at,'%Y-%m-%d') as date " \
                      "from cheyixiao.salers as sl where sl.created_at >'{}' and " \
                      "sl.created_at < '{}' and sl.city = {} group by date"
                cursor.execute(sql.format(start + ' 00:00:00', end + ' 23:59:59', city))
                count = cursor.fetchall()
                results = []
                for date in date_list:
                    result = {}
                    result['date'] = date
                    for info in count:
                        if date == info['date']:
                            result['num'] = info['count(*)']
                            break
                        else:
                            result['num'] = 0
                    results.append(result)
                self.render_json({'code': 200, 'result': results})

        elif typeq == 'bills':
            with connection.cursor() as cursor:
                sql = " select count(*),date_format(cheyixiao.bills.updated_at,'%Y-%m-%d') as date" \
                      " from cheyixiao.bills left join cheyixiao.salers on  cheyixiao.bills." \
                      "saler_id = cheyixiao.salers.id where cheyixiao.bills.updated_at >'{}'" \
                      "and cheyixiao.bills.updated_at < '{}' and cheyixiao.salers.city={} group by date"
                cursor.execute(sql.format(start + ' 00:00:00', end + ' 23:59:59', city))
                count = cursor.fetchall()
                results = []
                for date in date_list:
                    result = {}
                    result['date'] = date
                    for info in count:
                        if date == info['date']:
                            result['num'] = info['count(*)']
                            break
                        else:
                            result['num'] = 0
                    results.append(result)
                self.render_json({'code': 200, 'result': results})

        elif typeq == 'success':
            with connection.cursor() as cursor:
                sql = "select count(*),date_format(user_status.created_at,'%Y-%m-%d') as date " \
                      "from cheyixiao.user_status left join cheyixiao.salers on cheyixiao." \
                      "salers.id = cheyixiao.user_status.saler_id where cheyixiao.user_status." \
                      "created_at >'{}'and cheyixiao.user_status.created_at < '{}' and" \
                      " cheyixiao.user_status.status=4 and cheyixiao.salers.city={} group by date"
                cursor.execute(sql.format(start + ' 00:00:00', end + ' 23:59:59', city))
                count = cursor.fetchall()

                results = []
                for date in date_list:
                    result = {}
                    result['date'] = date
                    for info in count:
                        if date == info['date']:
                            result['num'] = info['count(*)']
                            break
                        else:
                            result['num'] = 0
                    results.append(result)
                self.render_json({'code': 200, 'result': results})
