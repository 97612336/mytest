# coding=utf-8

from __future__ import absolute_import, print_function

from operator import itemgetter

from .basehandler import BaseHandler
import logging
import datetime
import os
from tornado.httputil import urlencode
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest)
from tornado.escape import (json_encode, json_decode)
import tornado.gen
import qrcode
import json
from io import BytesIO
import tornado.web
import datetime
from collections import defaultdict
import pypinyin

try:
    from StringIO import StringIO
except ImportError:
    from io import BytesIO as StringIO


def __handlers(settings):
    return [
        (r"/v5/sms/car/specs", V5SpecsHandler),
        (r"/v5/sms/sell/rank", V5SellRankHandler),
        (r"/v5/sms/user/record", V5UserRecordHandler),
        (r"/v5/sms/users", V5UserListHandler),
        (r"/v5/sms/user/detail", V5UserDetailHandler),

        (r"/v5/sms/user/brands", V5BrandsHandler),
    ]


class V5SpecsHandler(BaseHandler):

    def get(self):
        series_id = self.get_argument('series_id', '')
        connection = self.get_afsaas_connection()
        with connection.cursor() as cursor:
            sql = "select id,name,guide_price from cheyixiao.specs as sp where sp.series_id=%s" % series_id
            cursor.execute(sql)
            specs = cursor.fetchall()

        if specs:
            self.render_json({'code': 200, 'results': specs})
        else:
            self.render_json({'code': 406, 'msg': '查询不到该车信息！'})


class V5SellRankHandler(BaseHandler):
    def _black(self, saler_id):

        black_list = [59, 60, 61, 1, 64]
        if saler_id in black_list:
            return False
        else:
            return True

    def get(self):
        date = self.get_argument('date', '')
        if not date:
            today = datetime.datetime.today()
            date = datetime.datetime(today.year, today.month, today.day).strftime('%Y-%m')
        page_size = self.get_argument_int('page_size', 10)
        page = self.get_argument_int('page', 1)
        region = dict(
            region_north=[150000, 230000, 220000, 210000,
                          110000, 120000, 130000, 140000],
            region_east=[370000, 320000, 340000, 330000, 310000, 410000, 420000],
            region_south=[360000, 350000, 430000, 450000, 440000, 530000],
            region_west=[650000, 540000, 630000, 620000, 510000,
                         640000, 610000, 500000, 520000],
        )
        region_citys = {}
        for key, value in region.items():
            Areas = self.model('areas')
            citys = []
            for pid in value:
                city = self.DB.query(Areas.id, Areas.name).filter(Areas.pid == pid).all()
                for c in city:
                    citys.append(c[0])
            region_citys[key] = citys

        saler_id = self.session_saler_info('id', 0)
        saler = self.db.salers.find_one({'id': saler_id})
        city_id = ''
        if saler:
            city_id = saler.city
        rank_citys = {}
        for key, value in region_citys.items():
            if city_id in value:
                if key == "region_north":
                    key = "华北区"
                if key == "region_east":
                    key = "华东区"
                if key == "region_south":
                    key = "华南区"
                if key == "region_west":
                    key = "华西区"
                rank_citys['region'] = key
                rank_citys['citys'] = value
                break
        if rank_citys:
            connection = self.get_afsaas_connection()
            with connection.cursor() as cursor:
                sql = "select bs.saler_id from cheyixiao.bills " \
                      "as bs where date_format(bs.updated_at,'%Y-%m')='{}';"

                cursor.execute(sql.format(date))
                salers = cursor.fetchall()

            salers_dict = {}
            for saler_info in salers:
                salers_dict[saler_info['saler_id']] = salers.count(saler_info)

            results = []
            Salers = self.model('salers')
            for sale_id, num in salers_dict.items():
                res = {}
                saler = self.DB.query(Salers.name, Salers.city, Salers.id, Salers.dealer_id, Salers.avatar).filter(
                    Salers.id == sale_id).all()
                if saler:
                    city = saler[0][1]
                    if city in rank_citys['citys'] and self._black(saler[0][2]):
                        if int(saler[0][2]) == int(saler_id):
                            res['msg'] = 'here'
                        res['name'] = saler[0][0]
                        avatar = saler[0][-1]
                        if avatar:
                            res['avatar'] = avatar
                        else:
                            res['avatar'] = ''
                        dealer_id = saler[0][-2]
                        dealer = self.db.dealers.find_one({'id': dealer_id})
                        dealer_name = ''
                        if dealer:
                            dealer_name = dealer.name
                        res['dealer'] = dealer_name
                        res['deal_amount'] = num
                        if res['name'] != "":
                            results.append(res)

            start = (page - 1) * page_size
            end = page * page_size
            sort_results = sorted(results, key=lambda k: -k['deal_amount'])
            my_position = ''
            for info in sort_results:
                if len(info) == 5:
                    my_position = {}
                    my_position['position'] = sort_results.index(info) + 1
                    my_position['name'] = info['name']
                    my_position['num'] = info['deal_amount']
                    my_position['dealer'] = info['dealer']
            self.render_json(
                {'code': 200, 'all_count': len(results), 'region': rank_citys['region'],
                 'results': sort_results[start:end], 'my_position': my_position})
        else:
            self.render_json({'code': 200, 'msg': '查询不到您所在区域信息！', 'all_count': 0, 'region': '',
                              'results': [], 'my_position': ''})


class V5UserRecordHandler(BaseHandler):
    def check_xsrf_cookie(self):
        pass

    def post(self):
        name = self.get_argument('name', '')
        phone = self.get_argument_int('phone', '')
        remark = self.get_argument('remark','')
        user_id = self.get_argument_int('user_id', '')
        customer_type = self.get_argument('customer_type', '')
        note = self.get_argument('note', '')
        info = {}
        info['name'] = name
        info['phone'] = phone
        info['remark'] = remark
        if customer_type:
            info['utype'] = customer_type
        if note:
            info['note'] = note
        try:
            self.db.users.update_one({'id': user_id}, {'$set': info})
            self.render_json({'code': 200, 'msg': '更新成功'})
        except Exception as e:
            logging.debug('error:%s', e)
            self.render_json({'code': 203, 'msg': '更新失败'})
            return


class V5UserDetailHandler(BaseHandler):
    def get(self):
        user_id = self.get_argument_int('user_id')
        user = self.db.users.find_one({'id': user_id})
        if user:
            result = {}
            user_name = ''
            nickname = user.nickname
            openid = user.openid
            name = user.name
            remark = user.remark
            if not remark:
                remark = ''
            if name:
                user_name = name
            elif nickname:
                user_name = nickname
            elif openid:
                user_name = openid
            phone = user.phone
            login_at = user.updated_at
            session = self.DB()
            Salers = self.model('salers')
            UserStatus = self.model('user_status')
            saler_query = session.query(Salers.name). \
                join(UserStatus, Salers.id == UserStatus.saler_id). \
                filter(UserStatus.user_id == user_id).first()
            if saler_query:
                saler_name = saler_query[0]
            else:
                saler_name = ''
            saler_id = self.session_saler_info('id', '')
            perm = self.session_saler_info('perm', 0)
            dealer_id = self.session_saler_info('dealer_id', '')
            role = self.session_saler_info('role', '')
            logging.debug('role:%s', role)
            Salers = self.model('salers')
            saler_id_list = []
            if perm == '1':
                saler_query = session.query(Salers.id). \
                    filter(Salers.dealer_id == dealer_id).all()
                for saler in saler_query:
                    saler_id_list.append(saler[0])
            else:
                saler_id_list.append(saler_id)
            if role in ['3', 3, '4', 4]:
                dealer_name = ''
                dealer_address = ''
            else:
                dealer = self.db.dealers.find_one({'id': dealer_id})
                dealer_name = dealer.name
                dealer_address = dealer.address
            result['name'] = user_name
            result['remark'] = remark
            result['phone'] = phone
            result['login_at'] = \
                datetime.datetime.strftime(login_at, '%Y-%m-%d %H:%M')
            result['saler_name'] = saler_name
            result['dealer_name'] = dealer_name
            result['dealer_address'] = dealer_address
            Look = self.model('look')
            Hotpoints = self.model('hotpoints')
            Specs = self.model('specs')
            Series = self.model('series')
            FocusCar = self.model('focus_car')
            CarWheels = self.model('car_wheels')
            hotpoints = session.query(Hotpoints).all()
            user_status = session.query(UserStatus). \
                filter(UserStatus.saler_id.in_(saler_id_list),
                       UserStatus.user_id == user_id).first()
            if user_status:
                status_int = user_status.status
            else:
                status_int = 1
            status = ''
            if status_int == 1:
                status = '跟进中'
            elif status_int == 2 or status_int == 3:
                status = '已下单'
            elif status_int == 4:
                status = '已交车'
            elif status_int == 5:
                status = '已取消'
            elif status_int == 6:
                status = '运输中'
            elif status_int == 7:
                status = '已到店'
            elif status_int == 8:
                status = '已取消'
            result['status'] = status
            result['status_int'] = status_int
            hotpoints_map = dict()
            for hotpoint in hotpoints:
                car_id = hotpoint.car_id
                ename = hotpoint.ename
                name = hotpoint.name
                if hotpoints_map.get(car_id, None):
                    hotpoints_map[car_id][ename] = name
                else:
                    hotpoints_map[car_id] = {}
                    hotpoints_map[car_id][ename] = name
            car_color_map = dict()
            CarColor = self.model('car_color')
            car_colors = session.query(CarColor).all()
            for car_color in car_colors:
                car_id = car_color.car_id
                ename = car_color.ename
                name = car_color.name
                color = car_color.color
                if car_color_map.get(car_id, None):
                    car_color_map[car_id][ename] = \
                        {'name': name, 'color': color}
                else:
                    car_color_map[car_id] = {}
                    car_color_map[car_id][ename] = \
                        {'name': name, 'color': color}
            looks = session.query(Look).filter(
                Look.user_id == user_id,
                Look.saler_id.in_(saler_id_list)).all()
            car_id_list = []
            car_map = dict()
            if looks:
                for look in looks:
                    car_id = look.car_id
                    if not car_map.get(car_id, None):
                        car_map[car_id] = {}
                    action = look.action
                    avalue = look.avalue
                    if action == 'outer_color':
                        if not car_map[car_id].get('outer_color', None):
                            car_map[car_id]['outer_color'] = {}
                        if car_map[car_id]['outer_color'].get(avalue, None):
                            car_map[car_id]['outer_color'][avalue] += 1
                        else:
                            car_map[car_id]['outer_color'][avalue] = 1
                    elif action == "inner_color":
                        if not car_map[car_id].get('inner_color', None):
                            car_map[car_id]['inner_color'] = {}
                        if car_map[car_id]['inner_color'].get(avalue, None):
                            car_map[car_id]['inner_color'][avalue] += 1
                        else:
                            car_map[car_id]['inner_color'][avalue] = 1
                    elif action == 'lungu':
                        if not car_map[car_id].get('car_part', None):
                            car_map[car_id]['car_part'] = {}
                        value = avalue
                        if car_map[car_id]['car_part'].get(value, None):
                            car_map[car_id]['car_part'][value] += 1
                        else:
                            car_map[car_id]['car_part'][value] = 1
                    else:
                        if action != 'switch' and avalue == 'open':
                            if not car_map[car_id].get('hotpoint', None):
                                car_map[car_id]['hotpoint'] = {}
                            value = hotpoints_map.get(car_id, {}). \
                                get(action, '')
                            if car_map[car_id]['hotpoint'].get(value, None):
                                car_map[car_id]['hotpoint'][value] += 1
                            else:
                                car_map[car_id]['hotpoint'][value] = 1
                    car_id_list.append(look.car_id)
            car_id_list = list(set(car_id_list))
            focus_car_query = session.query(FocusCar).filter(
                FocusCar.user_id == user_id,
                FocusCar.saler_id.in_(saler_id_list)).all()
            if focus_car_query:
                car_id_list = []
                for item in focus_car_query:
                    car_id_list.append(item.car_id)
            car_name_list = []
            focus_car = []
            car_id_name_map = dict()
            if car_id_list:
                for car_id in car_id_list:
                    car = session.query(Specs.logo, Series.name). \
                        join(Series, Specs.series_id == Series.id). \
                        filter(Specs.id == car_id).first()
                    if car:
                        car_name = car[1]
                        logo = car[0]
                        temp_map = dict()
                        temp_map['car_name'] = car_name
                        temp_map['car_id'] = car_id
                        temp_map['logo'] = logo
                        car_id_name_map[car_id] = car_name
                        car_name_list.append(temp_map)
            result['car_name_list'] = car_name_list
            for car_id in car_id_list:
                temp_dict = dict()
                temp_dict['car_id'] = car_id
                temp_dict['name'] = car_id_name_map.get(car_id, '')
                car_info = car_map.get(car_id, None)
                if car_info:
                    inner_color_map = car_info.get('inner_color', None)
                else:
                    inner_color_map = None
                if inner_color_map:
                    inner_color_sta = []
                    total_times = 0
                    for item in sorted(
                            list(inner_color_map.items()),
                            key=lambda x: x[0]):
                        temp_map1 = dict()
                        name = car_color_map.get(car_id, {}). \
                            get(item[0], {}).get('name', None)
                        color = car_color_map.get(car_id, {}). \
                            get(item[0], {}).get('color', '')
                        if name:
                            color_name = name
                        else:
                            color_name = item[0]
                        temp_map1['name'] = color_name
                        temp_map1['times'] = item[1]
                        temp_map1['color'] = color
                        total_times += item[1]
                        inner_color_sta.append(temp_map1)
                    inner_color_sta.sort(key=lambda x: x['times'],
                                         reverse=True)
                    for item in inner_color_sta:
                        item['total_times'] = total_times

                    temp_dict['inner_color_sta'] = inner_color_sta[:3]
                    temp_dict['inner_color'] = inner_color_sta[:2]
                else:
                    temp_dict['inner_color'] = []
                    temp_dict['inner_color_sta'] = []
                if car_info:
                    outer_color_map = car_info.get('outer_color', None)
                else:
                    outer_color_map = None
                if outer_color_map:
                    outer_color_sta = []
                    total_times = 0
                    for item in sorted(
                            list(outer_color_map.items()),
                            key=lambda x: x[0]):
                        temp_map2 = dict()
                        name = car_color_map.get(car_id, {}). \
                            get(item[0], {}).get('name', None)
                        color = car_color_map.get(car_id, {}). \
                            get(item[0], {}).get('color', '')
                        if name:
                            color_name = name
                        else:
                            color_name = item[0]
                        temp_map2['name'] = color_name
                        temp_map2['times'] = item[1]
                        temp_map2['color'] = color
                        total_times += item[1]
                        outer_color_sta.append(temp_map2)
                    outer_color_sta.sort(key=lambda x: x['times'],
                                         reverse=True)
                    for item in outer_color_sta:
                        item['total_times'] = total_times
                    temp_dict['outer_color_sta'] = outer_color_sta[:3]
                    temp_dict['outer_color'] = outer_color_sta[:2]
                else:
                    temp_dict['outer_color_sta'] = []
                    temp_dict['outer_color'] = []
                if car_info:
                    car_part_map = car_info.get('car_part', None)
                else:
                    car_part_map = None
                if car_part_map:
                    car_part_sta = []
                    total_times = 0
                    for item in sorted(
                            list(car_part_map.items()),
                            key=lambda x: x[0]):
                        query = session.query(CarWheels.logo, CarWheels.name). \
                            filter(CarWheels.car_id == car_id,
                                   CarWheels.ename == item[0]).first()
                        if query:
                            temp_map3 = dict()
                            temp_map3['times'] = item[1]
                            temp_map3['img'] = query[0]
                            temp_map3['name'] = query[1]
                            total_times += item[1]
                            car_part_sta.append(temp_map3)
                    car_part_sta.sort(key=lambda x: x['times'],
                                      reverse=True)
                    for item in car_part_sta:
                        item['total_times'] = total_times
                    temp_dict['car_part_sta'] = car_part_sta[:3]
                    temp_dict['car_part'] = car_part_sta[:2]
                else:
                    temp_dict['car_part_sta'] = []
                    temp_dict['car_part'] = []
                if car_info:
                    hotpoint_map = car_info.get('hotpoint', None)
                else:
                    hotpoint_map = None
                if hotpoint_map:
                    hotpoint_sta = []
                    total_times = 0
                    for item in sorted(
                            list(hotpoint_map.items()),
                            key=lambda x: x[0]):
                        temp_map4 = dict()
                        temp_map4['name'] = item[0]
                        temp_map4['times'] = item[1]
                        total_times += item[1]
                        hotpoint_sta.append(temp_map4)
                    hotpoint_sta.sort(key=lambda x: x['times'],
                                      reverse=True)
                    for item in hotpoint_sta:
                        item['total_times'] = total_times
                    temp_dict['hotpoint_sta'] = hotpoint_sta[:3]
                else:
                    temp_dict['hotpoint_sta'] = []
                focus_car.append(temp_dict)
            result['focus_car'] = focus_car
            self.render_json({'code': 200, 'results': result})
        else:
            self.render_json({'code': 406, 'msg': '参数错误'})


class V5UserListHandler(BaseHandler):
    def _user_attention_cars(self, user_id, saler_id,
                             isfocus, dict_look, dict_focus):
        attentions = []

        if isfocus:
            focus_car_ids = dict_focus[str(saler_id)][str(user_id)]
        else:
            focus_car_ids = dict_look[str(saler_id)][str(user_id)]
        for car_id in focus_car_ids:
            temp_dict = {}
            car = self.db.specs.find_one({"id": car_id})
            if not car:
                continue
            series_id = car.series_id
            series = self.db.series.find_one({"id": series_id})
            if series:
                temp_dict["name"] = series.name
                temp_dict["img"] = car.logo
            else:
                temp_dict["name"] = ''
                temp_dict["img"] = ''
            attentions.append(temp_dict)
        return attentions

    def _user_info(self, user_id):
        user = self.db.users.find_one({"id": user_id})
        if user:
            user_info = dict(
                id=user.id,
                name=user.name,
                phone=user.phone,
                latime=str(user.created_at)[:-3],
                remark=user.remark
            )
        else:
            user_info = dict(
                id='',
                name='',
                phone='',
                latime='',
                remark=''
            )
        return user_info

    def _results(self, car_ids, dict_look, dict_focus,
                 user_status, dict_bc, location, dealer_name):
        # local dealer's users pool
        res_list = []
        user_id_list = []
        for user_saler in user_status:
            tmp_dict = {}
            user_id = user_saler.user_id
            if user_id in user_id_list:
                pass
            else:
                user_id_list.append(user_id)
                # print(user_id)
                saler_id = user_saler.saler_id
                state = user_saler.status
                bill_cars = []
                if str(saler_id) in dict_bc.keys():
                    if str(user_id) in dict_bc[str(saler_id)].keys():
                        user_bill_cars = dict_bc[str(saler_id)][str(user_id)]
                        # print("exists:", str(user_id), user_bill_cars)
                        for car_id in user_bill_cars:
                            if car_id in car_ids:
                                bill_cars.append(car_id)
                        if not bill_cars:
                            bill_cars = None
                    else:
                        bill_cars = None

                focus_car_list = []
                focus_cars = {}
                if str(saler_id) in dict_focus.keys():
                    if str(user_id) in dict_focus[str(saler_id)].keys():
                        focus_cars = dict_focus[str(saler_id)][str(user_id)]
                for car_id in focus_cars:
                    if car_id in car_ids:
                        focus_car_list.append(car_id)
                tmp_dict["isfocus"] = 1

                if not focus_car_list:
                    tmp_dict["isfocus"] = 0
                    if str(saler_id) in dict_look.keys():
                        if str(user_id) in dict_look[str(saler_id)].keys():
                            look_cars = dict_look[str(saler_id)][str(user_id)]
                        else:
                            continue
                    else:
                        continue
                    carid_list = []
                    for car_id in look_cars:
                        if car_id in car_ids:
                            carid_list.append(car_id)
                    if not carid_list:
                        continue
                user_info = self._user_info(user_id=user_id)
                tmp_dict["user_id"] = user_info["id"]
                tmp_dict["uname"] = user_info["name"]
                tmp_dict["phone"] = user_info["phone"]
                remark = user_info["remark"]
                if not remark:
                    remark = ''
                tmp_dict["remark"] = remark

                tmp_dict["latime"] = user_info["latime"]
                tmp_dict["saler_id"] = saler_id
                fsaler = self.db.salers.find_one({"id": saler_id})
                if fsaler:
                    tmp_dict["saler"] = fsaler.name
                else:
                    tmp_dict["saler"] = ''
                # dealer_info = self._dealer_info(saler_id=saler_id)
                tmp_dict["loc"] = location
                tmp_dict["dealer"] = dealer_name

                tmp_dict["state"] = state
                maybe_states = [2, 3, 4]
                if state in maybe_states and bill_cars:
                    for bill in bill_cars:
                        new_dict = {}
                        new_dict.update(tmp_dict)
                        car_id = bill
                        car = self.db.specs.find_one({"id": car_id})
                        if car:
                            new_dict["img"] = car.logo
                            new_dict["car"] = car.name
                            res_list.append(new_dict)
                elif state in maybe_states and not bill_cars:
                    continue
                else:
                    tmp_dict["img"] = ''
                    tmp_dict["car"] = ''
                    res_list.append(tmp_dict)
        return res_list

    def _res_by_series(self, series_id, dict_look, dict_focus,
                       user_status, dict_bc, location, dealer_name):
        # print("series_id:", series_id)
        cars = self.db.specs.query().filter_by(series_id=series_id).all()
        car_ids = [i.id for i in cars]
        if not car_ids:
            return []
        return self._results(car_ids=car_ids,
                             dict_look=dict_look,
                             dict_focus=dict_focus,
                             user_status=user_status,
                             dict_bc=dict_bc,
                             dealer_name=dealer_name,
                             location=location,
                             )

    def _res_by_brand(self, brand_id, dict_look, dict_focus,
                      user_status, dict_bc, location, dealer_name):
        series_list = self.db.series.query().filter_by(brand_id=brand_id).all()

        res_list = []
        for ser in series_list:
            item = self._res_by_series(series_id=ser.id,
                                       dict_look=dict_look,
                                       dict_focus=dict_focus,
                                       user_status=user_status,
                                       dict_bc=dict_bc,
                                       dealer_name=dealer_name,
                                       location=location,
                                       )
            if not item:
                continue
            res_list.extend(item)
        return res_list

    def get(self):
        state = self.get_argument_int("state", 0)
        saler_id = self.session_saler_info("id", '')
        saler = self.db.salers.find_one({"id": saler_id})
        dealer_id = saler.dealer_id
        UserStatus = self.model("user_status")
        saler_perm = saler.perm
        Look = self.model("look")
        FocusCar = self.model("focus_car")
        Salers = self.model("salers")
        local_saler_list = self.DB.query(Salers). \
            filter_by(dealer_id=dealer_id).all()
        # local dealer's salers pool
        saler_ids = [s.id for s in local_saler_list]
        look_cars = self.DB.query(Look). \
            filter(Look.saler_id.in_(saler_ids)).all()
        dict_look = {}
        for look in look_cars:
            look_saler_id = str(look.saler_id)
            user_id = str(look.user_id)
            car_id = look.car_id
            if look_saler_id not in dict_look.keys():
                dict_look[look_saler_id] = {}
                dict_look[look_saler_id][user_id] = {car_id}
            if look_saler_id in dict_look.keys():
                if user_id not in dict_look[look_saler_id].keys():
                    dict_look[look_saler_id][user_id] = {car_id}
                if user_id in dict_look[look_saler_id].keys():
                    dict_look[look_saler_id][user_id].add(car_id)
        focus_cars = self.DB.query(FocusCar). \
            filter(FocusCar.saler_id.in_(saler_ids)).all()
        dict_focus = {}
        for focus in focus_cars:
            focus_saler_id = str(focus.saler_id)
            user_id = str(focus.user_id)
            car_id = focus.car_id
            if focus_saler_id not in dict_focus.keys():
                dict_focus[focus_saler_id] = {}
                dict_focus[focus_saler_id][user_id] = {car_id}
            if focus_saler_id in dict_focus.keys():
                if user_id not in dict_focus[focus_saler_id].keys():
                    dict_focus[focus_saler_id][user_id] = {car_id}
                if user_id in dict_focus[focus_saler_id].keys():
                    dict_focus[focus_saler_id][user_id].add(car_id)
        # manger level
        user_status = []
        if saler_perm == 1:
            if not state:
                user_status = self.DB.query(UserStatus). \
                    filter(UserStatus.saler_id.in_(saler_ids)).all()
            else:
                user_status = self.DB.query(UserStatus). \
                    filter(UserStatus.saler_id.in_(saler_ids)). \
                    filter(UserStatus.status == state).all()
        # common level
        if saler_perm == 2:
            if not state:
                user_status = self.DB.query(UserStatus). \
                    filter(UserStatus.saler_id == saler_id).all()
            else:
                user_status = self.DB.query(UserStatus). \
                    filter(UserStatus.saler_id == saler_id). \
                    filter(UserStatus.status == state).all()
        Bills = self.model("bills")
        bills = self.DB.query(Bills). \
            filter(Bills.saler_id.in_(saler_ids)).all()
        dict_bc = {}
        for bill in bills:
            sid = str(bill.saler_id)
            uid = str(bill.user_id)
            car_id = bill.car_id
            if sid not in dict_bc.keys():
                dict_bc[sid] = {}
                dict_bc[sid][uid] = set([car_id])
            if sid in dict_bc.keys():
                if uid not in dict_bc[sid].keys():
                    dict_bc[sid][uid] = set([car_id])
                if uid in dict_bc[sid].keys():
                    dict_bc[sid][uid].add(car_id)

        dealer = self.db.dealers.find_one({"id": dealer_id})
        if dealer:
            location = dealer.address
            dealer_name = dealer.name
        else:
            location = ''
            dealer_name = ''
        page_size = self.get_argument_int("page_size", 10)
        page = self.get_argument_int("page", 1)
        if page < 1:
            page = 1
        brand_id = self.get_argument_int("brand", 0)
        series_id = self.get_argument_int("series", 0)
        results_list = []
        # print("dict_look:",dict_look)
        # print("dict_focus:",dict_focus)
        # print("dict_bcv:",dict_bc)

        # search by series_id and state
        if series_id:
            # print("1begin")
            results_list = self._res_by_series(series_id=series_id,
                                               dict_look=dict_look,
                                               dict_focus=dict_focus,
                                               user_status=user_status,
                                               dict_bc=dict_bc,
                                               dealer_name=dealer_name,
                                               location=location,
                                               )
        # search by brand_id and state
        if brand_id and not series_id:
            # print("2begin")
            results_list = self._res_by_brand(brand_id=brand_id,
                                              dict_look=dict_look,
                                              dict_focus=dict_focus,
                                              user_status=user_status,
                                              dict_bc=dict_bc,
                                              dealer_name=dealer_name,
                                              location=location,
                                              )

        # search all by state
        if not brand_id and not series_id:
            # print("3begin")
            DealerBrand = self.model("dealer_brand")
            dealer_brands = self.DB.query(DealerBrand). \
                filter(DealerBrand.dealer_id == dealer_id).all()
            brand_ids = [ds.brand_id for ds in dealer_brands]
            results_list = []
            for brand_id in brand_ids:
                item = self._res_by_brand(brand_id=brand_id,
                                          dict_look=dict_look,
                                          dict_focus=dict_focus,
                                          user_status=user_status,
                                          dict_bc=dict_bc,
                                          dealer_name=dealer_name,
                                          location=location,
                                          )
                if not item:
                    continue
                results_list.extend(item)
        start = (page - 1) * page_size
        end = page * page_size
        results_list.sort(key=lambda x: x.get("latime"), reverse=True)
        new_list = []
        user_id_list = []
        for i in results_list:
            uid = i.get("user_id")
            if i.get("user_id") not in user_id_list:
                user_id_list.append(uid)
            else:
                continue
            new_list.append(i)
        results = new_list[start: end]
        total = len(new_list)
        for res in results:
            res["attentions"] = self._user_attention_cars(
                user_id=res["user_id"],
                saler_id=res["saler_id"],
                isfocus=res["isfocus"],
                dict_look=dict_look,
                dict_focus=dict_focus)
        self.render_json({"code": 200, "total": total, "results": results})


class V5BrandsHandler(BaseHandler):
    def check_xsrf_cookie(self):
        pass

    def get(self):

        connection = self.get_afsaas_connection()
        with connection.cursor() as cursor:
            sql = "select distinct(bid), bs.bname from (select distinct" \
                  "(brands.id) as bid, brands.name as bname, series.id as " \
                  "s_id from cheyixiao.brands right join series on brands.id=" \
                  "series.brand_id) as bs right join specs on specs.series_id=bs.s_id"
            cursor.execute(sql)
            brands = cursor.fetchall()
        if brands:
            stand_dict = {}
            for num in range(26):
                stand = chr(num + ord('a'))
                stand_list = []
                for brand_info in brands:
                    info = {}
                    name = brand_info['bname']
                    if name:
                        p_name = ''.join(pypinyin.lazy_pinyin(name))
                        if stand == p_name[0]:
                            info['pinyin'] = p_name
                            info['id'] = brand_info['bid']
                            info['name'] = name
                            info['status'] = 1
                            stand_list.append(info)
                if stand_list:
                    stand_dict[stand] = sorted(stand_list,
                                               key=lambda k: k['pinyin'])
            result = sorted(stand_dict.items(), key=itemgetter(0))
            results = []
            for res in result:
                dic = {}
                dic[res[0]] = res[1]
                results.append(dic)
            self.render_json({'code': 200, 'result': results})
