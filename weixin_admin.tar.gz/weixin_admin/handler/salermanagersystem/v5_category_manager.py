# coding=utf-8

from __future__ import absolute_import, print_function
from .basehandler import BaseHandler
import json


def __handlers(settings):
    return [
        (r"/v5/sms/car/scheme/index", V5SchemeIndexHandler),
        (r"/v5/sms/car/scheme/add", V5AddSchemeHandler),
        (r"/v5/sms/car/scheme/del", V5DelSchemeHandler),

        (r"/v5/sms/car/cate/index", V5CateIndexHandler),
        (r"/v5/sms/car/cate/add", V5AddCateHandler),
        (r"/v5/sms/car/cate/edit", V5EditCateHandler),
        (r"/v5/sms/car/cate/del", V5DelCateHandler),
    ]


class V5AddSchemeHandler(BaseHandler):

    def check_xsrf_cookie(self):
        pass

    # 添加或编辑的保存
    def post(self):
        session = self.DB
        car_id = self.get_argument("car_id")
        saler_id = self.saler_id
        dealer_id = self.db.salers.find_one({"id": saler_id}).dealer_id

        ids_str = self.get_argument("ids")
        id_list = ids_str.split(",")
        for cate_id in id_list:

            sql = "insert into cheyixiao.car_scheme(`category_id`, " \
                  "`car_id`, `dealer_id`) values(%s,%s,%s)"
            session.execute(sql % (cate_id, car_id, dealer_id))
        session.commit()
        self.render_json({"code": 200, "msg": "ok"})

    # 获得可添加精品列表
    def get(self):
        session = self.DB
        car_id = self.get_argument("car_id")
        saler_id = self.saler_id
        dealer_id = self.db.salers.find_one({"id": saler_id}).dealer_id
        # 找到该经销商下该车没有添加的那些精品
        sql_category = "select id,name from cheyixiao.car_part_category " \
                       "where dealer_id=%s and id not in(select category_id from" \
                       " cheyixiao.car_scheme where dealer_id=%s " \
                       "and car_id=%s); "
        res = session.execute(sql_category % (dealer_id, dealer_id, car_id))
        res_list = res.fetchall()
        results = []
        if len(res_list) > 0:
            for item in res_list:
                tmp_dict = dict()
                tmp_dict["id"] = item[0]
                tmp_dict["name"] = item[1]
        self.render_json({'code': 200, 'results': results})
        
        
class V5DelSchemeHandler(BaseHandler):

    def check_xsrf_cookie(self):
        pass

    def post(self):
        session = self.DB
        car_id = self.get_argument("car_id")
        cate_id = self.get_argument("cate_id")
        saler_id = self.saler_id
        dealer_id = self.db.salers.find_one({"id": saler_id}).dealer_id
        del_sql = "delete from cheyixiao.car_scheme where car_id=%s," \
                  "category_id=%s,dealer_id=%s;"
        session.execute(del_sql % (car_id, cate_id, dealer_id))
        session.commit()
        self.render_json({"code": 200, "msg": "操作成功！"})


# 添加和编辑都跳到此
class V5SchemeIndexHandler(BaseHandler):
    tokenpass = True
    def check_xsrf_cookie(self):
        pass

    def get(self):
        car_info = dict()
        session = self.DB
        saler_id = self.saler_id
        dealer_id = self.db.salers.find_one({"id": saler_id}).dealer_id
        # dealer_id = 3000
        car_id = self.get_argument("car_id")
        # car_id = 30899
        car_info_sql = "select t1.id,t1.name,t1.logo,t1.guide_price," \
                       "t2.id,t2.name,t3.nums,t3.naked_price from " \
                       "cheyixiao.specs as t1 join cheyixiao.series " \
                       "as t2 on t1.series_id=t2.id join " \
                       "cheyixiao.dealer_spec as t3 on " \
                       "t3.car_id=t1.id where " \
                       "t3.dealer_id=%s and t1.id=%s;"
        car_res = session.execute(car_info_sql % (dealer_id, car_id))
        info = car_res.fetchone()
        car_info["cid"] = info[0]
        car_info["name"] = info[1]
        car_info["img"] = info[2]
        car_info["guide"] = info[3]
        car_info["sid"] = info[4]
        car_info["sname"] = info[5]
        car_info["nums"] = info[6]
        car_info["naked"] = info[7]
        schemes = []
        category_sql = "select t1.id,t1.name,t1.price,t1.img_id,t4.url," \
              "t1.created_at,t3.category_id,t3.id,t3.name,t3.price,t3.img_id," \
              "t5.url,t3.created_at from cheyixiao.car_part_category " \
              "as t1 join cheyixiao.car_scheme as t2 on " \
              "t1.id=t2.category_id join cheyixiao.car_parts as " \
              "t3 on t1.id=t3.category_id join cheyixiao.imgs as t4 " \
              "on t1.img_id=t4.id join cheyixiao.imgs as t5 on " \
              "t3.img_id=t5.id where t2.dealer_id=%s and car_id=%s;"
        category_res = session.execute(category_sql % (dealer_id, car_id))
        category_list = category_res.fetchall()
        category_dict = dict()
        for category in category_list:
            if str(category[0]) not in category_dict.keys():
                category_dict[str(category[0])] = dict()
                category_dict[str(category[0])]["sid"] = category[0]
                category_dict[str(category[0])]["sname"] = category[1]
                category_dict[str(category[0])]["sprice"] = category[2]
                category_dict[str(category[0])]["simg_id"] = category[3]
                category_dict[str(category[0])]["simg"] = category[4]
                category_dict[str(category[0])]["created_at"] = \
                    str(category[5])[:-9]
                category_dict[str(category[0])]["options"] = []
                tmp = dict(
                    cid=category[7],
                    cname=category[8],
                    cprice=category[9],
                    cimg_id=category[10],
                    cimg=category[11],
                    created_at=str(category[12])[:-9]
                )
                category_dict[str(category[0])]["options"].append(tmp)
                continue
            if str(category[0]) in category_dict.keys():
                tmp = dict(
                    cid=category[7],
                    cname=category[8],
                    cprice=category[9],
                    cimg_id=category[10],
                    cimg=category[11],
                    created_at=str(category[12])[:-9]
                )
                category_dict[str(category[0])]["options"].append(tmp)
        for k in category_dict:
            schemes.append(category_dict[k])
        total = len(schemes)
        self.render_json({"code": 200, "total": total,
                          "car_info": car_info, "schemes": schemes})


class V5CateIndexHandler(BaseHandler):
    def get(self):
        session = self.DB
        saler_id = self.saler_id
        dealer_id = self.db.salers.find_one({"id": saler_id}).dealer_id
        sql = "select t1.id,t1.name,t1.price,t1.img_id,t4.url," \
              "t1.created_at,t3.category_id,t3.id,t3.name," \
              "t3.price,t3.img_id,t5.url,t3.created_at," \
              "t2.car_id,t8.name,t7.name,t6.name from " \
              "cheyixiao.car_part_category as t1 left join " \
              "cheyixiao.car_scheme as t2 on t1.id=t2.category_id " \
              "left join cheyixiao.car_parts as t3 on " \
              "t1.id=t3.category_id left join cheyixiao.imgs " \
              "as t4 on t1.img_id=t4.id left join cheyixiao.imgs " \
              "as t5 on t3.img_id=t5.id left join cheyixiao.specs " \
              "as t6 on t2.car_id=t6.id left join cheyixiao.series " \
              "as t7 on t6.series_id=t7.id left join cheyixiao.brands " \
              "as t8 on t8.id=t7.brand_id where t1.dealer_id=%s;"
        res = session.execute(sql % dealer_id)
        cate_list = res.fetchall()
        categories = []
        category_dict = dict()
        for category in cate_list:
            if str(category[0]) not in category_dict.keys():
                category_dict[str(category[0])] = dict()
                category_dict[str(category[0])]["cate_id"] = category[0]
                category_dict[str(category[0])]["cate_name"] = category[1]
                category_dict[str(category[0])]["cate_price"] = category[2]
                category_dict[str(category[0])]["cate_img"] = category[4]
                category_dict[str(category[0])]["created_at"] = \
                    str(category[5])[:-9]
                category_dict[str(category[0])]["options"] = []
                category_dict[str(category[0])]["options_id"] = set()
                category_dict[str(category[0])]["cars"] = []
                category_dict[str(category[0])]["cars_id"] = set()
                if category[7] and category[7] not in \
                        category_dict[str(category[0])]["options_id"]:
                    category_dict[str(category[0])]["options_id"].\
                        add(category[7])
                    tmp = dict(
                        part_id=category[7],
                        part_name=category[8],
                        part_price=category[9],
                        part_img=category[11],
                        created_at=str(category[12])[:-9]
                    )
                    category_dict[str(category[0])]["options"].append(tmp)
                if category[13] and category[13] not in \
                        category_dict[str(category[0])]["cars_id"]:
                    category_dict[str(category[0])]["cars_id"].\
                        add(category[13])
                    tmp_car = dict(
                        car_id=category[13],
                        brand_name=category[14],
                        series_name=category[15],
                        spec_name=category[16]
                    )
                    category_dict[str(category[0])]["cars"].append(tmp_car)
                continue
            if str(category[0]) in category_dict.keys():
                if category[7] and category[7] not in \
                        category_dict[str(category[0])]["options_id"]:
                    category_dict[str(category[0])]["options_id"].\
                        add(category[7])
                    tmp = dict(
                        part_id=category[7],
                        part_name=category[8],
                        part_price=category[9],
                        part_img=category[11],
                        created_at=str(category[12])[:-9]
                    )
                    category_dict[str(category[0])]["options"].append(tmp)
                if category[13] and category[13] not in \
                        category_dict[str(category[0])]["cars_id"]:
                    category_dict[str(category[0])]["cars_id"].\
                        add(category[13])
                    tmp_car = dict(
                        car_id=category[13],
                        brand_name=category[14],
                        series_name=category[15],
                        spec_name=category[16]
                    )
                    category_dict[str(category[0])]["cars"].append(tmp_car)
        for k in category_dict:
            del category_dict[k]["cars_id"]
            del category_dict[k]["options_id"]
            categories.append(category_dict[k])
        self.render_json({"code": 200, "categories": categories})


class V5AddCateHandler(BaseHandler):
    def check_xsrf_cookie(self):
        pass

    def post(self):
        json_data = self.get_argument("data", "")
        if not json_data:
            self.render_json({"code": 402, "msg": "请求数据为空！"})
            return
        data = json.loads(json_data)
        id = data["id"]
        if not id:
            id = ''
        name = data["name"]
        img_id = data["img_id"] or None
        if not img_id:
            img_id = 0
        price = data["price"]
        saler_id = self.session_saler_info("id", "")
        dealer_id = self.db.salers.find_one({"id": saler_id}).dealer_id
        info = dict(
            id=id,
            name=name,
            dealer_id=dealer_id,
            price=format(float(price), "0.2f"),
            img_id=int(img_id)
        )
        res = self.db.car_part_category.\
            find_one_and_update({'id': id}, {'$set': info}, upsert=True)

        data_list = data.get("subclass", [])
        category_id = res.id
        cp_ids = []
        for data in data_list:
            cprice = data["price"]
            temp_dict = {}
            temp_dict.update({"category_id": category_id})
            id = data["cp_id"]
            if not id:
                id = ''
            temp_dict["img_id"] = data["img_id"] or None
            temp_dict["name"] = data["name"]
            if cprice:
                temp_dict["price"] = format(float(cprice), "0.2f")
            else:
                temp_dict["price"] = 0
            res_cp = self.db.car_parts.\
                find_one_and_update({'id': id}, {'$set': temp_dict},
                                    upsert=True)
            cp_ids.append(res_cp.id)
        now_car_parts = self.db.car_parts.query().\
            filter_by(category_id=category_id).all()
        for car_part in now_car_parts:
            id = car_part.id
            if id not in cp_ids:
                self.db.car_parts.query().filter_by(id=id).delete()
                self.DB.commit()
        self.render_json({"code": 200, "msg": "操作成功！"})


class V5EditCateHandler(BaseHandler):

    def get(self):
        session = self.DB
        saler_id = self.saler_id
        dealer_id = self.db.salers.find_one({"id": saler_id}).dealer_id
        cate_id = self.get_argument("cate_id")
        sql = "select t1.id,t1.name,t1.price,t3.url,t2.id,t2.name," \
              "t2.price,t4.url from cheyixiao.car_part_category as" \
              " t1 join cheyixiao.car_parts t2 on t1.id =t2.category_id" \
              " join cheyixiao.imgs t3 on t1.img_id=t3.id" \
              " join cheyixiao.imgs t4 on t2.img_id=t4.id " \
              "where t1.id=%s and t1.dealer_id=%s;"
        res = session.execute(sql % (cate_id, dealer_id))
        res_list = res.fetchall()
        category_dict = dict()
        for category in res_list:
            if str(category[0]) not in category_dict.keys():
                category_dict[str(category[0])] = dict()
                category_dict[str(category[0])]["cate_id"] = category[0]
                category_dict[str(category[0])]["cate_name"] = category[1]
                category_dict[str(category[0])]["cate_price"] = category[2]
                category_dict[str(category[0])]["cate_img"] = category[3]
                category_dict[str(category[0])]["options"] = []
                category_dict[str(category[0])]["options_id"] = set()
                if category[4] and category[4] not in \
                        category_dict[str(category[0])]["options_id"]:
                    category_dict[str(category[0])]["options_id"].\
                        add(category[4])
                    tmp = dict(
                        part_id=category[4],
                        part_name=category[5],
                        part_price=category[6],
                        part_img=category[7],
                    )
                    category_dict[str(category[0])]["options"].append(tmp)
                continue
            if str(category[0]) in category_dict.keys():
                if category[4] and category[4] not in \
                        category_dict[str(category[0])]["options_id"]:
                    category_dict[str(category[0])]["options_id"].\
                        add(category[4])
                    tmp = dict(
                        part_id=category[4],
                        part_name=category[5],
                        part_price=category[6],
                        part_img=category[7],
                    )
                    category_dict[str(category[0])]["options"].append(tmp)
        results = []
        for k in category_dict:
            del category_dict[k]["options_id"]
            results.append(category_dict[k])
        self.render_json({"code": 200, "results": results})


class V5DelCateHandler(BaseHandler):

    def check_xsrf_cookie(self):
        pass

    # 添加或编辑的保存
    def post(self):
        session = self.DB
        cate_id = self.get_argument("cate_id")
        saler_id = self.saler_id
        dealer_id = self.db.salers.find_one({"id": saler_id}).dealer_id
        cate_sql = "delete from cheyixiao.car_part_category " \
                   "where id=%s and dealer_id=%s;"
        part_sql = "delete from cheyixiao.car_parts where category_id=%s;"
        car_scheme_sql = "delete from cheyixiao.car_scheme " \
                         "where category_id=%s and dealer_id=%s;"
        session.execute(cate_sql % (cate_id, dealer_id))
        session.execute(part_sql % cate_id)
        session.execute(car_scheme_sql % (cate_id, dealer_id))
        session.commit()
        self.render_json({"code": 200, "msg": "已删除！"})
