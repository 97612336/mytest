# coding=utf-8

from __future__ import absolute_import, print_function

from .basehandler import BaseHandler
import logging
import datetime
import os
import json
from tornado.httputil import urlencode
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest)
from tornado.escape import (json_encode, json_decode)
import tornado.gen
import qrcode
import threading

try:
    from StringIO import StringIO
except ImportError:
    from io import BytesIO as StringIO


def __handlers(settings):
    return [
        (r"/v2/sms/car/info", CarsInfoHandler),
        (r"/v2/sms/car/scheme/add", AddSchemeHandler),
        (r"/v2/sms/car/scheme/edit", EditSchemeHandler),
        (r"/v2/sms/car/scheme/del", DelSchemeHandler),
        (r"/v2/sms/car/schemes/cost", CarSchemesCostHandler),
    ]

# NOW USE IT
class CarsInfoHandler(BaseHandler):

    def get(self):
        #  handle car info
        saler_id = self.session_saler_info("id", '')
        dealer_id = self.db.salers.find_one({"id": saler_id}).dealer_id
        car_id = self.get_argument_int("car_id", 0)
        if not car_id:
            self.render_json({"code": 406, "msg": "缺失必要的请求参数car_id"})
            return
        car = self.db.specs.find_one({"id": car_id})
        if not car:
            self.render_json({"code": 407, "msg": "无此car_id的车型信息"})
            return
        series_id = car.series_id
        series = self.db.series.find_one({"id": series_id})
        car_info = dict(
            cid=car_id,
            name=car.name,
            img=car.logo,
            guide=car.guide_price,
            sid=car.series_id,
            sname=series.name
        )
        local_car = self.db.dealer_spec. \
            find_one({"car_id": car_id, "dealer_id": dealer_id})
        if local_car:
            car_info["nums"] = local_car.nums
            naked = 0
            if local_car.naked_price:
                naked = "%.2f" % round(local_car.naked_price / 10000, 2)
            car_info["naked"] = naked
        else:
            car_info["nums"] = ''
            car_info["naked"] = ''
        self.render_json({"code": 200, "car_info": car_info})


class AddSchemeHandler(BaseHandler):

    def get(self):
        page = self.get_argument_int("page", 1)
        pagesize = self.get_argument_int("pagesize", 10)
        CarPartCategory = self.model("car_part_category")
        CarParts = self.model("car_parts")
        saler_id = self.session_saler_info("id", "")
        dealer_id = self.db.salers.find_one({"id": saler_id}).dealer_id
        category_list = self.DB.query(CarPartCategory).\
            filter_by(dealer_id=dealer_id, status=2).all()
        res_list = []
        # category_mark = 0
        for category in category_list:
            # category_mark += 1
            sc_dict = dict()
            sc_dict["category_id"] = category.id
            sc_dict["sname"] = category.name
            sc_dict["sprice"] = category.price
            simg_id = category.img_id
            simg = self.db.imgs.find_one({"id": simg_id})
            if simg:
                sc_dict["simg"] = simg.url
            else:
                sc_dict["simg"] = ''
            sc_dict["simg_id"] = simg_id
            created_at = category.created_at
            if created_at:
                sc_dict["created_at"] = str(created_at)[:-3]
            else:
                sc_dict["created_at"] = ''
            option_list = self.DB.query(CarParts).\
                filter_by(category_id=category.id).all()
            tmp_list = []
            # cp_mark = 0
            for option in option_list:
                # cp_mark += 1
                op_dict = dict()
                op_dict["parts_id"] = option.id
                op_dict["cname"] = option.name
                op_dict["cprice"] = option.price
                cimg_id = option.img_id
                op_dict["cimg_id"] = cimg_id
                cimg = self.db.imgs.find_one({"id": cimg_id})
                if cimg:
                    op_dict["cimg"] = cimg.url
                else:
                    op_dict["cimg"] = ''
                created_at = option.created_at
                if created_at:
                    op_dict["created_at"] = str(created_at)[:-3]
                else:
                    op_dict["created_at"] = ''
                tmp_list.append(op_dict)
            sc_dict["options"] = tmp_list
            res_list.append(sc_dict)
        start = (page - 1) * pagesize
        end = page * pagesize
        results = res_list[start:end]
        total = len(res_list)
        self.render_json({"code": 200, "total": total,  "schemes": results})

    def check_xsrf_cookie(self):
        pass

    def thread_save(self, dealer_id, cs_id, scheme):
        # 存套餐
        tmp_scheme = {}
        tmp_scheme["name"] = scheme["sname"] or "未命名"
        tmp_scheme["price"] = scheme["sprice"] or 0
        tmp_scheme["img_id"] = scheme.get("simg_id", 0)
        tmp_scheme["dealer_id"] = dealer_id
        tmp_scheme["cs_id"] = cs_id

        res_scheme = self.db.schemes.insert_one(tmp_scheme)
        scheme_id = res_scheme.id

        # 存套餐选配
        option_list = scheme["options"]
        for option in option_list:
            tmp_option = {}
            tmp_option["scheme_id"] = scheme_id
            tmp_option["name"] = option["cname"] or "未命名"
            tmp_option["price"] = option["cprice"] or 0
            tmp_option["img_id"] = option.get("cimg_id", 0)
            self.db.scheme_options.insert_many(tmp_option)
        self.DB.commit()

    def post(self):
        saler_id = self.session_saler_info("id", "")
        dealer_id = self.db.salers.find_one({"id": saler_id}).dealer_id
        json_data = self.get_argument("data", '')
        data = json.loads(json_data)
        car_id = data["car_id"]

        car = self.db.specs.find_one({"id": car_id})
        if not car:
            self.render_json({"code": 202, "msg": "请求的车型不存在"})
            return

        # 将车型保存到经销店
        nums = data["nums"] or 0
        naked = data["naked"]
        if naked:
            nakedfmt = naked.replace("万", "").replace("元", "")
            naked = float(nakedfmt)*10000
        if not naked:
            naked = 0
        update_dict = dict(nums=nums,
                           naked_price=naked,
                           dealer_id=dealer_id,
                           car_id=car_id,
                           status=2)
        self.db.dealer_spec.find_one_and_update(
            {"car_id": car_id, 'dealer_id': dealer_id},
            {"$set": update_dict}, upsert=True)
        # 存套餐和car的关系
        car_scheme_dict = {}
        car_scheme_dict["car_id"] = car_id
        car_scheme_dict["status"] = 1
        car_scheme_dict["dealer_id"] = dealer_id
        res_car_scheme = self.db.car_scheme.insert_one(car_scheme_dict)
        cs_id = res_car_scheme.id
        scheme_list = data["schemes"]
        t = None
        THREADS = 30
        big = len(scheme_list) // THREADS
        small = len(scheme_list) % THREADS
        if big != 0:
            for i in range(big):
                threads = []
                for j in range(THREADS):
                    t = threading.Thread(target=self.thread_save,
                                         args=(
                                         dealer_id, cs_id,
                                         scheme_list[j+i-1]))
                    threads.append(t)
                for t in threads:
                    t.setDaemon(True)
                    t.start()
                t.join()
        if small != 0:
            threads = []
            for i in range(small):
                t = threading.Thread(target=self.thread_save,
                                     args=(
                                         dealer_id, cs_id,
                                         scheme_list[i]))
                threads.append(t)
            for t in threads:
                t.setDaemon(True)
                t.start()
            t.join()
        self.render_json({"code": 200, "msg": "操作成功！"})


class EditSchemeHandler(BaseHandler):

    def get(self):
        page = self.get_argument_int("page", 1)
        if page < 1:
            page = 1
        pagesize = self.get_argument_int("pagesize", 10)
        cs_id = self.get_argument("cs_id")
        #  handle car info
        saler_id = self.session_saler_info("id", '')
        dealer_id = self.db.salers.find_one({"id": saler_id}).dealer_id
        c_s = self.db.car_scheme.find_one({"id": cs_id})
        car_id = ''
        if c_s:
            car_id = c_s.car_id
        if not c_s:
            self.render_json({"code":402, "msg": "无此cs_id ！"})
            return
        car = self.db.specs.find_one({"id": car_id})
        car_info = None
        if car:
            series_id = car.series_id
            series = self.db.series.find_one({"id": series_id})
            car_info = dict(
                cid=car_id,
                name=car.name,
                img=car.logo,
                guide=car.guide_price,
                sid=car.series_id,
                sname=series.name
            )
        if not car:
            self.render_json({"code": 403,"msg": "店内无此车型！"})
            return
        local_car = self.db.dealer_spec. \
            find_one({"car_id": car_id, "dealer_id": dealer_id})
        if local_car:
            car_info["nums"] = local_car.nums
            naked = 0
            if local_car.naked_price:
                naked = "%.2f" % round(local_car.naked_price / 10000, 2)
            car_info["naked"] = naked
        else:
            car_info["nums"] = ''
            car_info["naked"] = ''
        # handle schemes info
        Schemes = self.model("schemes")
        SchemeOptions = self.model("scheme_options")
        scheme_list = self.DB.query(Schemes).filter_by(cs_id=cs_id).all()
        res_list = []
        for scheme in scheme_list:
            sc_dict = dict()
            sc_dict["sid"] = scheme.id
            sc_dict["sname"] = scheme.name
            sc_dict["sprice"] = scheme.price
            simg_id = scheme.img_id
            if simg_id:
                simg = self.db.imgs.find_one({"id": simg_id})
                if simg:
                    sc_dict["simg"] = simg.url
                else:
                    sc_dict["simg"] = ''
            else:
                sc_dict["simg"] = ''
            sc_dict["simg_id"] = simg_id

            created_at = scheme.created_at
            if created_at:
                sc_dict["created_at"] = str(created_at)[:-3]
            else:
                sc_dict["created_at"] = ''

            option_list = self.DB.query(SchemeOptions).\
                filter_by(scheme_id=scheme.id).all()
            tmp_list = []
            for option in option_list:
                op_dict = dict()
                op_dict["cid"] = option.id
                op_dict["cname"] = option.name
                op_dict["cprice"] = option.price
                cimg_id = option.img_id
                op_dict["cimg_id"] = cimg_id
                cimg = self.db.imgs.find_one({"id": cimg_id})
                if cimg:
                    op_dict["cimg"] = cimg.url
                else:
                    op_dict["cimg"] = ''
                created_at = option.created_at
                if created_at:
                    op_dict["created_at"] = str(created_at)[:-3]
                else:
                    op_dict["created_at"] = ''
                tmp_list.append(op_dict)
            sc_dict["options"] = tmp_list
            res_list.append(sc_dict)
        start = (page - 1) * pagesize
        end = page * pagesize
        total = len(res_list)
        results = res_list[start: end]
        self.render_json({"code": 200, "total": total,
                          "car_info": car_info, "schemes": results})

    def check_xsrf_cookie(self):
        pass

    def thread_update(self, dealer_id, cs_id, scheme, sid):
        # 强制更新套餐
        tmp_scheme = {}
        tmp_scheme["name"] = scheme["sname"]
        tmp_scheme["price"] = scheme["sprice"]
        tmp_scheme["img_id"] = scheme["simg_id"] or None
        tmp_scheme["dealer_id"] = dealer_id
        tmp_scheme["cs_id"] = cs_id
        res_scheme = self.db.schemes.find_one_and_update(
            {"id": sid}, {"$set": tmp_scheme}, upsert=True)
        scheme_id = res_scheme.id
        # 强制更新选配
        option_list = scheme["options"]
        for option in option_list:
            cid = option.get("cid", '')
            tmp_option = {}
            tmp_option["scheme_id"] = scheme_id
            tmp_option["name"] = option["cname"]
            tmp_option["price"] = option["cprice"]
            tmp_option["img_id"] = option["cimg_id"] or None
            self.db.scheme_options.find_one_and_update(
                {"id": cid}, {"$set": tmp_option}, upsert=True)

    def post(self):
        saler_id = self.session_saler_info("id", "")
        dealer_id = self.db.salers.find_one({"id": saler_id}).dealer_id
        json_data = self.get_argument("data", '')
        data = json.loads(json_data)

        car_id = data["car_id"]
        cs_id = data["cs_id"]
        self.db.car_scheme.find_one_and_update(
            {"id": cs_id}, {"$set": {"car_id": car_id}})
        # 将车型信息更新保存到经销店
        nums = data["nums"]
        naked = data["naked"]
        if naked:
            nakedfmt = naked.replace("万", "").replace("元", "")
            naked = int(float(nakedfmt)*10000)
        if not naked:
            naked = 0
        update_dict = dict(nums=nums,
                           car_id=car_id,
                           naked_price=naked,
                           dealer_id=dealer_id)
        self.db.dealer_spec.find_one_and_update(
            {"car_id": car_id, "dealer_id": dealer_id},
            {"$set": update_dict}, upsert=True)

        scheme_list = data["schemes"]
        print("*"*20)
        for i in scheme_list:
            print(i)
        print('*'*20)

        t = None
        THREADS = 20
        big = len(scheme_list) // THREADS
        small = len(scheme_list) % THREADS
        if big != 0:
            for i in range(big):
                threads = []
                for j in range(THREADS):
                    sid = scheme_list[j + i - 1].get("sid", "")
                    t = threading.Thread(target=self.thread_update,
                                         args=(
                                             dealer_id, cs_id,
                                             scheme_list[j + i - 1], sid))
                    threads.append(t)
                for t in threads:
                    t.setDaemon(True)
                    t.start()
                t.join()
        if small != 0:
            threads = []
            for i in range(small):
                sid = scheme_list[i].get("sid", '')
                t = threading.Thread(target=self.thread_update,
                                     args=(
                                         dealer_id, cs_id,
                                         scheme_list[i], sid))
                threads.append(t)
            for t in threads:
                t.setDaemon(True)
                t.start()
            t.join()
        self.render_json({"code": 200, "msg": "操作成功！"})


class DelSchemeHandler(BaseHandler):
    def get(self):
        sid = self.get_argument_int("sid", 0)
        if not sid:
            self.render_json({"code": 406, "msg": "请求失败，缺少必要参数sid！"})
        self.db.schemes.query().filter_by(id=sid).delete()
        self.db.scheme_options.query().filter_by(scheme_id=sid)\
            .delete(synchronize_session='fetch')
        self.DB.commit()
        self.render_json({"code": 200, "msg": "操作成功！"})


class CarSchemesCostHandler(BaseHandler):

    # provide choose page
    def get(self):
        bill_id = self.get_argument_int("bill_id")
        if not bill_id:
            self.render_json({"code": 402, "res":"缺少必要参数bill_id"})
            return
        bill_schemes = self.db.bill_schemes.query().\
            filter_by(bill_id=bill_id).all()
        if not bill_schemes:
            self.render_json({"code": 200, "res": []})
            return
        scheme_ids = [bs.scheme_id for bs in bill_schemes]
        res_list = []
        total_cost = 0
        for sc_id in scheme_ids:
            tmp_dict = {}
            scheme = self.db.schemes.find_one({"id": sc_id})
            if scheme:
                tmp_dict["scheme_id"] = scheme.id
                tmp_dict["name"] = scheme.name
                tmp_dict["price"] = scheme.price
            else:
                continue
            total_cost += scheme.price
            options = self.db.scheme_options.query().\
                filter_by(scheme_id=sc_id).all()
            op_list = []
            for op in options:
                tmp_op_dict = dict(
                    op_id=op.id,
                    name=op.name,
                    price=op.price
                )
                op_list.append(tmp_op_dict)
            tmp_dict["options"] = op_list
            res_list.append(tmp_dict)
        self.render_json({"code": 200,
                          "res": res_list,
                          "total_cost": total_cost})
