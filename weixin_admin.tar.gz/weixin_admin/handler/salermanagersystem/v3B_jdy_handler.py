# coding=utf-8

from __future__ import absolute_import, print_function

import pypinyin

from .basehandler import BaseHandler
import logging
import datetime
import os
from tornado.httputil import urlencode
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest)
from tornado.escape import (json_encode, json_decode)
import tornado.gen
import qrcode
import json
from io import BytesIO
import tornado.web
import datetime
from collections import OrderedDict
import base64, hashlib

try:
    from StringIO import StringIO
except ImportError:
    from io import BytesIO as StringIO


def __handlers(settings):
    return [
        (r"/v3B/sms/logistics/query", V3BQueryHandler),
        (r"/v3B/sms/user/district", V3BDistrictHandler),
        (r"/v3B/sms/logistics/circuit", V3BCircuitHandler),
    ]
JDY_APP_SECRET_KEY = os.getenv("JDY_APP_SECRET_KEY")
JDY_APP_KEY = os.getenv("JDY_APP_KEY")

class V3BDistrictHandler(BaseHandler):

    def get(self):
        JdyCities = self.model("jdy_cities")
        area_objs = self.db.jdy_cities.query(). \
            order_by(JdyCities.p_pinyin).all()
        province_dict = OrderedDict()
        for area in area_objs:
            if area.province not in province_dict.keys():
                province_dict[area.province] = {}
                province_dict[area.province]["province"] = area.province
                province_dict[area.province]["city"] = [area.city]
            elif area.province in province_dict.keys():
                province_dict[area.province]["city"].append(area.city)
        results = [value for value in province_dict.values()]
        self.render_json({"code": 200, "result": results})


class V3BQueryHandler(BaseHandler):

    def check_xsrf_cookie(self):
        pass

    @tornado.gen.coroutine
    def post(self):
        origin = self.get_argument("origin", None)
        destination = self.get_argument("destination", None)
        total_price = self.get_argument("total_price", None)
        car_type = self.get_argument("car_type", "0")
        car_num = self.get_argument("car_num", None)
        if_invoice = self.get_argument_int("if_invoice", 0)
        delivery_type = self.get_argument_int("delivery_type", 0)
        param_list = ["origin", "destination", "total_price", "car_type",
                      "car_num", "if_invoice", "delivery_type"]
        for param in param_list:
            if vars()[param] is None:
                self.render_json({"code": 202,
                                  "msg": "缺失必要参数%s" % param})
                return
        content = OrderedDict()
        content["origin"] = origin
        content["destination"] = destination
        content["totalCarPrice"] = total_price
        content["carType"] = car_type
        content["car_num"] = car_num
        content["if_invoice"] = if_invoice
        content["delivery_type"] = delivery_type
        data = json.dumps(content, ensure_ascii=False)
        secret = JDY_APP_SECRET_KEY
        tem = data + secret
        md5_str = hashlib.md5(tem.encode('utf-8')).digest()
        b_str = base64.b64encode(md5_str)
        appkey = JDY_APP_KEY
        digest = b_str.decode('utf-8')
        query_data = {"appkey": appkey, "digest": digest, "data": data}
        body = urlencode(query_data)
        url = 'https://api.dev.jdywl.cn/gateway/priceQuery'
        request = HTTPRequest(
            url=url,
            method='POST',
            body=body,
            connect_timeout=60,
            request_timeout=60,
        )
        client = AsyncHTTPClient()
        response = yield client.fetch(request)
        if response.error:
            logging.debug('response.error:%s',
                          response.error)
            self.render_json({"code": 205, "msg": "请求物流平台失败！"})
            return
        else:
            body = json_decode(response.body)
        err_code = body.get("errorCode")
        if err_code == "201":
            self.render_json({"code": 204, "msg": "该线路不存在，请重新选择路线"})
            return
        if err_code == "102":
            self.render_json({"code": 102, "msg": "签名验证失败！"})
            return
        if err_code == "100":
            result = {}
            jdy_data = body["data"]
            result["origin"] = origin
            result["destination"] = destination
            result["total_price"] = jdy_data.get("totalBill")
            result["market_price"] = jdy_data.get("marketPrice")
            result["insurance"] = jdy_data.get("insurance")
            result["deposit"] = jdy_data.get("deposit")
            result["invoice"] = jdy_data.get("invoice")
            result["deliveryFee"] = jdy_data.get("deliveryFee")
            result["period"] = jdy_data.get("period")
            self.render_json({"code": 200, "result": result})


class V3BCircuitHandler(BaseHandler):

    def check_xsrf_cookie(self):
        pass

    def _order_by_pinyin(self, item):
        return pypinyin.lazy_pinyin(item)[0]

    @tornado.gen.coroutine
    def post(self):
        origin = self.get_argument("origin", None)
        destination = None
        page = 1
        page_size = 600

        content = OrderedDict()
        content["origin"] = origin
        content["destination"] = destination
        content["page"] = page
        content["page_size"] = page_size

        data = json.dumps(content, ensure_ascii=False)
        secret = JDY_APP_SECRET_KEY
        tem = data + secret
        md5_str = hashlib.md5(tem.encode('utf-8')).digest()
        b_str = base64.b64encode(md5_str)
        appkey = JDY_APP_KEY
        digest = b_str.decode('utf-8')
        query_data = {"appkey": appkey, "digest": digest, "data": data}
        body = urlencode(query_data)
        url = 'https://api.dev.jdywl.cn/gateway/routeQuery'
        request = HTTPRequest(
            url=url,
            method='POST',
            body=body,
            connect_timeout=60,
            request_timeout=60,
        )
        client = AsyncHTTPClient()
        response = yield client.fetch(request)
        if response.error:
            logging.debug('response.error:%s',
                          response.error)
            self.render_json({"code": 205, "msg": "请求物流平台失败！"})
            return
        else:
            body = json_decode(response.body)
        err_code = body.get("errorCode")
        if err_code == "201":
            self.render_json({"code": 204, "msg": "该线路不存在，请重新选择路线"})
            return
        if err_code == "102":
            self.render_json({"code": 102, "msg": "签名验证失败！"})
            return
        if err_code == "100":

            # result = {}
            result_list = []
            jdy_data = body["data"]["data"]
            for item in jdy_data:
                result_list.append(item["destination"])

            result_list.sort(key=self._order_by_pinyin)

            self.render_json({"code": 200, "result": result_list,
                              "total": len(result_list)})