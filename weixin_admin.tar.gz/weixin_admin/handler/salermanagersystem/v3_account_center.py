# coding=utf-8

from __future__ import absolute_import, print_function

import hashlib
import time
from operator import itemgetter

from .basehandler import BaseHandler
import logging
import datetime
import os
import json
from tornado.httputil import urlencode
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest)
from tornado.escape import (json_encode, json_decode)
import tornado.gen
import qrcode
from app import Application
from util import baidu
from PIL import Image

try:
    from StringIO import StringIO
except ImportError:
    from io import BytesIO as StringIO


def __handlers(settings):
    return [
        (r"/v3/sms/user/register", RegisterHandler),
        (r"/v3/sms/user/login", LoginHandler),
        (r"/v3/sms/user/brand", BrandHandler),
        (r"/v3/sms/user/area", AreaHandler),
        (r"/v3/sms/user/certification", CertifictionHandler),
        (r"/v3/sms/user/img", ImgHandler),
        (r"/v3/sms/saler/info", V3SalerInfoHandler),
        (r"/v3/sms/bill/status", BillStatusHandler),
        (r"/v3/sms/userinfo/modify", ModifyHandler),
    ]


class RegisterHandler(BaseHandler):
    tokenpass = True

    def check_xsrf_cookie(self):
        pass

    def post(self):
        username = self.get_argument('username', '')
        dealers = self.db.dealers.find_one({'name': username})
        salers = self.db.salers.find_one({'username': username})
        if salers or dealers:
            self.render_json({'code': 406, 'msg': '账号已存在'})
            return
        passwd = self.get_argument('passwd', '')
        role = self.get_argument('role', '')
        brands = self.get_argument('brands', '')

        if not all((username, passwd, role, brands)):
            self.render_json({'code': 403, 'msg': '提交信息有误！'})
            return

        saler_info = {}
        saler_info['username'] = username
        saler_info['password'] = passwd
        saler_info['role'] = int(role)
        saler_info['brands'] = brands
        saler_info['perm'] = 1
        saler_info['cert_code'] = 0
        res_saler = self.db.salers.insert_one(saler_info)

        self.login_session_update(res_saler.id, res_saler.to_dict())
        redis = self.redis
        hkey = 'one:login:saler:id:{}'.format(res_saler.id)
        cur_time = str(datetime.datetime.now().replace(microsecond=0))
        token = self.gen_token()
        msid = token
        ip = self.request.remote_ip
        dic = {"msid": msid, "ip": str(ip), "time": cur_time}
        redis.hmset(hkey, dic)
        self.update_user_token(res_saler.id, token)

        self.render_json({"code": 200, "msg": "注册成功！",
                          'role': res_saler.role,
                          'perm': res_saler.perm,
                          'name': res_saler.name,
                          'avatar': res_saler.avatar,
                          'Cyx_token': token,
                          'Cyx_saler': res_saler.id,
                          'username': res_saler.username,
                          'cert_code': res_saler.cert_code,
                          'expire': False})


class LoginHandler(BaseHandler):
    tokenpass = True

    def check_xsrf_cookie(self):
        pass

    def post(self):
        username = self.get_argument('username', '')
        passwd = self.get_argument('passwd', '')
        if not all((username, passwd)):
            self.render_json({'code': 403, 'msg': '账号或密码错误'})
            return

        passwd_md5 = self.db.salers.to_password(username, passwd)
        query = {'username': username}
        saler = self.db.salers.find_one(query)

        if saler:
            if saler.password == passwd or saler.password == passwd_md5:
                saler_id = saler.id
                token = self.gen_token()
                now = datetime.datetime.now()
                created_at = saler.created_at
                delta = (now - created_at).days
                self.login_session_update(saler_id, saler.to_dict())
                redis = self.redis
                hkey = 'one:login:saler:id:{}'.format(saler.id)
                cur_time = str(datetime.datetime.now().replace(microsecond=0))
                msid = token
                ip = self.request.remote_ip
                dic = {"msid": msid, "ip": str(ip), "time": cur_time}
                redis.hmset(hkey, dic)
                self.update_user_token(saler.id, token)

                avatar = saler.avatar
                if not avatar:
                    avatar = ''
                if avatar == 'None':
                    avatar = ''
                cert_code = saler.cert_code
                if saler.address:
                    if delta >= 7:
                        cert_code = 2
                        self.db.salers.find_one_and_update(
                            {"id": saler_id},
                            {"$set": {'cert_code': cert_code}})
                ip = self.request.remote_ip
                style = 1
                login_info = dict(saler_id=saler_id,
                                  ip=ip,
                                  style=style)
                try:
                    self.db.login_record.insert_one(login_info)
                except Exception as e:
                    logging.debug("error:%s", e)

                self.render_json({'code': 200, 'msg': '登录成功',
                                  'expire': False,
                                  'name': saler.name,
                                  'avatar': avatar,
                                  'Cyx_token': token,
                                  'Cyx_saler': saler.id,
                                  'cert_code': cert_code,
                                  'role': saler.role,
                                  'username': saler.username})

            else:
                self.render_json({'code': 201, 'msg': '密码错误！'})
        else:
            self.render_json({'code': 202, 'msg': '用户名错误！'})


class BrandHandler(BaseHandler):
    tokenpass = True

    def check_xsrf_cookie(self):
        pass

    def get(self):
        Brands = self.model('brands')
        brands = tuple(self.DB.query(Brands.id,
                                     Brands.name,
                                     Brands.logo,
                                     Brands.pinyin,
                                     Brands.status).all())

        brand_list = []
        for b_info in brands:
            brand_dict = {}
            brand_dict['id'] = b_info[0]
            brand_dict['name'] = b_info[1]
            brand_dict['logo_url'] = b_info[2]
            brand_dict['pinyin'] = b_info[3]
            brand_dict['status'] = b_info[4]
            brand_list.append(brand_dict)
        res_brand = []
        for num in range(26):
            stand_dict = {}
            stand = chr(num + ord('a'))
            stand_list = []
            for info in brand_list:
                if info['status'] == 1:
                    pinyin_stand = info['pinyin'][0]
                    if stand == pinyin_stand:
                        stand_list.append(info)
                        stand_dict[stand] = stand_list
            if stand_dict:
                res_brand.append(stand_dict)

        result = {}
        result['brands'] = res_brand
        self.render_json({'code': 200, 'result': result})


class AreaHandler(BaseHandler):
    def check_xsrf_cookie(self):
        pass

    def get(self):
        Areas = self.model('areas')
        areas = tuple(self.DB.query(Areas.id, Areas.name, Areas.pid).all())

        pro_dict = {}
        for info in areas:
            if info[2] == 0:
                pro_dict[info[0]] = info[1]

        area_list = []
        for pid in pro_dict:
            area_dic = {}
            citys = []
            province = {}
            for info in areas:
                if info[2] == pid:
                    city = {}
                    city['id'] = info[0]
                    city['name'] = info[1]
                    citys.append(city)

                province['citys'] = sorted(citys, key=itemgetter('id'))
                province['name'] = pro_dict[pid]
                province['id'] = pid
                area_dic['province'] = province
            area_list.append(area_dic)

        result = {}
        result['areas'] = sorted(area_list, key=lambda k: k['province']['id'])

        self.render_json({'code': 200, 'result': result})


class CertifictionHandler(BaseHandler):
    def check_xsrf_cookie(self):
        pass

    def post(self):
        avatar_url = self.get_argument('avatar_url', '')
        name = self.get_argument('name', '')
        phone = self.get_argument('phone', '')
        address = self.get_argument('address', '')
        city = self.get_argument('city', '')
        if not all((name, phone, address, city)):
            self.render_json({'code': 500, 'msg': '个人信息不可为空！'})
            return
        saler_info = {}
        saler_info['avatar'] = avatar_url
        saler_info['name'] = name
        try:
            saler_info['phone'] = int(phone)
        except Exception as e:
            self.render_json({'code': 500, 'msg': '电话号码只能为数字！'})
            return
        saler_info['city'] = int(city)
        saler_info['address'] = address
        saler_info['cert_code'] = 1

        saler_id = self.session_saler_info('id', 0)
        if saler_id:
            Salers = self.model('salers')
            role = self.DB.query(Salers.role). \
                filter(Salers.id == saler_id).first()
            if role:
                role = role[0]
            # 角色为经销商
            if int(role) == 1:
                licence_url = self.get_argument('license', '')
                pic_door = self.get_argument('pic_door', '')
                pic_show = self.get_argument('pic_show', '')
                pic_rest = self.get_argument('pic_rest', '')
                pic_other = self.get_argument('pic_other', '')
                if not all((licence_url, pic_door,
                            pic_show, pic_rest, pic_other,)):
                    self.render_json({'code': 500, 'msg': '图片信息不可为空！'})
                    return
                store_name = self.get_argument('st_name', '')
                company = self.get_argument('company', '')
                store_address = self.get_argument('st_addr', '')
                store_phone = self.get_argument('st_phone', '')
                charge_name = self.get_argument('ch_name', '')
                charge_phone = self.get_argument('ch_phone', '')
                if not all((store_name, company, store_address,
                            store_phone, charge_name, charge_phone)):
                    self.render_json({'code': 500, 'msg': '门店信息不可为空！'})
                    return

                dealers_info = {}
                dealers_info['pic_door'] = pic_door
                dealers_info['pic_show'] = pic_show
                dealers_info['pic_rest'] = pic_rest
                dealers_info['pic_other'] = pic_other
                dealers_info['bus_licence'] = licence_url
                dealers_info['company'] = company
                dealers_info['address'] = store_address
                dealers_info['call'] = store_phone
                dealers_info['ch_name'] = charge_name
                try:
                    dealers_info['phone'] = int(charge_phone)
                except Exception as e:
                    self.render_json({'code': 500, 'msg': '电话号码只能为数字！'})
                    return

                Dealers = self.model('dealers')
                # 根据店名查到的
                dealers_id = self.DB.query(Dealers.id).filter(Dealers.name == store_name).all()
                # 根据saler_id查到的
                dealer_id = self.DB.query(Salers.dealer_id).filter(Salers.id == saler_id).first()

                # 如果老用户，更新，不存在，插入
                if dealer_id[0] != None:
                    if not dealers_id or dealers_id[0] == dealer_id:
                        dealers_info['name'] = store_name
                    else:
                        self.render_json({'code': 409, 'msg': '该店名已存在！'})
                        return
                    res_dealer = self.db.dealers.find_one_and_update(
                        {"id": dealer_id[0]}, {"$set": dealers_info})
                    saler_info['dealer_id'] = res_dealer.id
                else:
                    if not dealers_id:
                        dealers_info['name'] = store_name
                    else:
                        self.render_json({'code': 409, 'msg': '该店名已存在！'})
                        return
                    res_dealer = self.db.dealers.insert_one(dealers_info)
                    saler_info['dealer_id'] = res_dealer.id

            # 汽车经纪人与新手经纪人
            elif int(role) == 3 or int(role) == 4:
                Dealers = self.model('dealers')
                username = self.DB.query(Salers.username). \
                    filter(Salers.id == saler_id).first()
                if username:
                    username = username[0]
                if self.DB.query(Dealers.id).filter(
                        Dealers.name == username).first():
                    self.render_json({'code': 409, 'mag': '店名已存在！'})
                    return
                res_dealer = self.db.dealers.insert_one({'name': username})
                saler_info['dealer_id'] = res_dealer.id

                ID_face = self.get_argument('ID_face', '')
                ID_con = self.get_argument('ID_con', '')
                if not all((ID_face, ID_con)):
                    self.render_json({'code': 408, 'msg': '身份证信息不可为空！'})
                    return
                saler_info['ID_face'] = ID_face
                saler_info['ID_con'] = ID_con
            else:
                self.render_json({'code': 500, 'msg': '用户角色信息有误！'})
                return
            saler = self.db.salers.find_one_and_update(
                {"id": saler_id}, {"$set": saler_info}, upsert=True)

            dealer_brand_info = self.DB.query(Salers.dealer_id, Salers.brands). \
                filter(Salers.id == saler.id).first()
            if dealer_brand_info:
                dealer_id = dealer_brand_info[0]
                brands = ''
                if dealer_brand_info[1]:
                    brands = dealer_brand_info[1].split(',')
                for brand in brands:
                    dealer_brand = self.db.dealer_brand.insert_one \
                        ({'dealer_id': dealer_id, 'brand_id': brand,
                          "onsell": 0})
            self.render_json({'code': 200, 'msg': '提交成功！'})
        else:
            self.render_json({'code': 307, 'msg': '查询不到登录信息'})


class ImgHandler(BaseHandler):
    ALLOWED_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.gif'}

    def check_xsrf_cookie(self):
        pass

    def post(self):
        basic_domain = 'https://cheyixiao.autoforce.net'

        param = ['id', 'avatar', 'license', 'pic', 'invoice',
                 'dr_license', 'bill_loans', 'stock_loans', 'contract']
        for type in param:
            files = self.request.files.get(type)
            if files:
                extent_domain = type
                static_path = self.settings.get('static_path', '')
                if extent_domain == 'id':
                    extent_domain = 'ID'
                dirpath = os.path.join(static_path, extent_domain)
                if not os.path.exists(dirpath):
                    os.makedirs(dirpath)

                file_name = ''
                # filepath = ''
                for file in files:
                    fullname = os.path.basename(file['filename'])
                    fname, fext = os.path.splitext(fullname)
                    fext = fext.strip().lower()
                    if fext not in self.ALLOWED_EXTENSIONS:
                        continue
                    current_time = int(time.time())
                    file_name = str(current_time) + file['filename']
                    filepath = os.path.join(dirpath, file_name)
                    with open(filepath, 'wb') as f:
                        f.write(file['body'])
                # im = Image.open(filepath)
                # im.thumbnail((128,128))
                # im.save(os.path.join(dirpath,'small_'+file_name))

                url = basic_domain + "/static/" + \
                      extent_domain + '/' + file_name
                # small_url = basic_domain + "/static/" + \
                #       extent_domain + '/' + 'small_' + file_name
                self.render_json({'code': 200, 'url': url})


class V3SalerInfoHandler(BaseHandler):
    def check_xsrf_cookie(self):
        pass

    def get(self):
        saler_id = self.session_saler_info('id', 0)
        session = self.DB()
        Salers = self.model('salers')
        saler_Info = session.query(Salers.name,
                                   Salers.phone,
                                   Salers.address,
                                   Salers.city,
                                   Salers.role,
                                   Salers.cert_code,
                                   Salers.avatar,
                                   Salers.username). \
            filter(Salers.id == saler_id).first()

        name = saler_Info[0]
        phone = saler_Info[1]
        address = saler_Info[2]
        city = saler_Info[3]
        role = saler_Info[4]
        cert_code = saler_Info[5]
        avatar = saler_Info[6]
        if not avatar:
            avatar = ''
        if avatar == 'None':
            avatar = ''

        username = saler_Info[7]
        pro_dict = {}
        if city:
            Area = self.model('areas')
            city_info = tuple(self.DB.query(Area.id, Area.name, Area.pid). \
                              filter(Area.id == int(city)).first())
            pro_info = self.DB.query(Area.id, Area.name, Area.pid). \
                filter(Area.id == city_info[2]).first()
            city_dict = {}
            city_dict['id'] = city_info[0]
            city_dict['name'] = city_info[1]
            pro_dict['id'] = pro_info[0]
            pro_dict['name'] = pro_info[1]
            pro_dict['city'] = city_dict

        saler = self.db.salers.find_one({'id': saler_id})

        weixin_name = ''
        status = 0
        qrcode = ''
        res = self.db.wechat_bind.find_one({"saler_id": saler_id})
        if res and res.openid is not None:
            status = 1
            res_saler_id = res.saler_id
            weixin_name = session.query(Salers.name). \
                filter(Salers.id == res_saler_id).first()[0]
        else:
            qrcode = "https://cheyixiao.autoforce.net/static" \
                     "/qrcode/chexiaoyi.jpg"

        results = dict(salers_name=name,
                       salers_phone=phone,
                       salers_address=address,
                       salers_city=pro_dict,
                       salers_role=role,
                       salers_certcode=cert_code,
                       salers_avatar=avatar,
                       status=status,
                       weixin_name=weixin_name,
                       qrcode=qrcode,
                       saler_username=username
                       )
        if role == 1 or role == 2:
            dealer_id = session.query(Salers.dealer_id). \
                filter(Salers.id == saler_id).first()[0]
            Dealers = self.model('dealers')
            dealers_info = session.query(Dealers.name, Dealers.company,
                                         Dealers.address,
                                         Dealers.call, Dealers.ch_name,
                                         Dealers.phone,
                                         Dealers.bus_licence,
                                         Dealers.pic_door, Dealers.pic_show,
                                         Dealers.pic_rest, Dealers.pic_other). \
                filter(Dealers.id == dealer_id).first()
            if dealers_info:
                dealers_name = dealers_info[0]
                dealers_company = dealers_info[1]
                dealers_address = dealers_info[2]
                dealers_call = dealers_info[3]
                dealers_chname = dealers_info[4]
                dealers_phone = dealers_info[5]
                dealers_buslicense = dealers_info[6]
                pic_door = dealers_info[7]
                pic_show = dealers_info[8]
                pic_rest = dealers_info[9]
                pic_other = dealers_info[10]
            else:
                dealers_name = ''
                dealers_company = ''
                dealers_address = ''
                dealers_call = ''
                dealers_chname = ''
                dealers_phone = ''
                dealers_buslicense = ''
                pic_door = ''
                pic_show = ''
                pic_rest = ''
                pic_other = ''
            results['dealers_name'] = dealers_name
            results['dealers_company'] = dealers_company
            results['dealers_address'] = dealers_address
            results['dealers_call'] = dealers_call
            results['dealers_chname'] = dealers_chname
            results['dealers_phone'] = dealers_phone
            results['dealers_buslicense'] = dealers_buslicense
            results['pic_door'] = pic_door
            results['pic_show'] = pic_show
            results['pic_rest'] = pic_rest
            results['pic_other'] = pic_other

        elif role == 3 or role == 4:
            ID_info = self.DB.query(Salers.ID_face, Salers.ID_con). \
                filter(Salers.id == saler_id).first()
            ID_face = ID_info[0]
            ID_con = ID_info[1]
            results['ID_face'] = ID_face
            results['ID_con'] = ID_con
        else:
            self.render_json({'code': 203, 'msg': '该用户信息不存在'})
        self.render_json({'results': results, 'code': 200})


class BillStatusHandler(BaseHandler):
    def check_xsrf_cookie(self):
        pass

    def get(self):
        bill_id = self.get_argument('bill_id', '')
        if bill_id:
            bills = self.db.bills.find_one({'id': bill_id})
            if bills.order_fee:
                self.render_json(
                    {'code': 200, 'bill_status': 1, 'price': bills.order_fee / 100})
            else:
                self.render_json({'code': 200, 'bill_status': 0})
        else:
            self.render_json({'code': 201, 'msg': '缺失必要参数！'})


class ModifyHandler(BaseHandler):
    def check_xsrf_cookie(self):
        pass

    def post(self):
        saler_id = self.session_saler_info('id', 0)
        cert_code = self.db.salers.find_one({'id': saler_id}).cert_code
        # if cert_code == 0:
        #     self.render_json({'code':301,'mag':'您还未认证！'})
        #     return
        # elif cert_code == 1:
        #     self.render_json({'code': 302, 'mag': '审核未通过！'})
        #     return
        # elif cert_code == 2:
        #     pass
        avatar_url = self.get_argument('avatar_url', '')
        name = self.get_argument('name', '')
        phone = self.get_argument('phone', '')
        address = self.get_argument('address', '')
        city = self.get_argument('city', '')
        if not all((name, phone, address, city)):
            self.render_json({'code': 500, 'msg': '个人信息不可为空！'})
            return
        saler_info = {}
        saler_info['avatar'] = avatar_url
        saler_info['name'] = name
        try:
            saler_info['phone'] = int(phone)
        except Exception as e:
            self.render_json({'code': 500, 'msg': '电话号码只能为数字！'})
            return
        saler_info['city'] = int(city)
        saler_info['address'] = address

        if saler_id:
            Salers = self.model('salers')
            role = self.DB.query(Salers.role). \
                filter(Salers.id == saler_id).first()
            if role:
                role = role[0]
            # 角色为经销商
            if int(role) == 1:
                licence_url = self.get_argument('license', '')
                pic_door = self.get_argument('pic_door', '')
                pic_show = self.get_argument('pic_show', '')
                pic_rest = self.get_argument('pic_rest', '')
                pic_other = self.get_argument('pic_other', '')
                if not all((licence_url, pic_door,
                            pic_show, pic_rest, pic_other,)):
                    self.render_json({'code': 500, 'msg': '图片信息不可为空！'})
                    return
                store_name = self.get_argument('st_name', '')
                company = self.get_argument('company', '')
                store_address = self.get_argument('st_addr', '')
                store_phone = self.get_argument('st_phone', '')
                charge_name = self.get_argument('ch_name', '')
                charge_phone = self.get_argument('ch_phone', '')
                if not all((store_name, company, store_address,
                            store_phone, charge_name, charge_phone)):
                    self.render_json({'code': 500, 'msg': '门店信息不可为空！'})
                    return

                dealers_info = {}
                dealers_info['pic_door'] = pic_door
                dealers_info['pic_show'] = pic_show
                dealers_info['pic_rest'] = pic_rest
                dealers_info['pic_other'] = pic_other
                dealers_info['bus_licence'] = licence_url
                dealers_info['company'] = company
                dealers_info['address'] = store_address
                dealers_info['call'] = store_phone
                dealers_info['ch_name'] = charge_name
                try:
                    dealers_info['phone'] = int(charge_phone)
                except Exception as e:
                    self.render_json({'code': 500, 'msg': '电话号码只能为数字！'})
                    return

                dealer_id = self.db.salers.find_one({'id': saler_id}).dealer_id
                dealers = self.db.dealers.find_one({'name': store_name})
                dealers_id = ''
                if dealers:
                    dealers_id = dealers.id
                if not dealers_id:
                    dealers_info['name'] = store_name
                elif dealer_id == dealers_id:
                    dealers_info['name'] = store_name
                else:
                    self.render_json(
                        {'code': 409, 'msg': '该店名已存在！'})
                    return

                res_dealer = self.db.dealers.find_one_and_update(
                    {"id": dealer_id}, {"$set": dealers_info})
                saler_info['dealer_id'] = res_dealer.id
            # 汽车经纪人与新手经纪人
            elif int(role) == 3 or int(role) == 4:
                username = self.db.salers.find_one({'id': saler_id}).username
                dealers_id = self.db.dealers.find_one({'name': username}).id
                dealer_id = self.db.salers.find_one({'id': saler_id}).dealer_id
                # print(dealer_id, dealers_id, '=' * 100)
                if dealers_id:
                    if dealer_id != dealers_id:
                        self.render_json({'code': 409, 'mag': '用户名已存在！'})
                        return
                res_dealer = self.db.dealers.find_one_and_update \
                    ({'id': dealer_id}, {"$set": {'name': username}})
                saler_info['dealer_id'] = res_dealer.id

                ID_face = self.get_argument('ID_face', '')
                ID_con = self.get_argument('ID_con', '')
                if not all((ID_face, ID_con)):
                    self.render_json({'code': 408, 'msg': '身份证信息不可为空！'})
                saler_info['ID_face'] = ID_face
                saler_info['ID_con'] = ID_con
            else:
                self.render_json({'code': 500, 'msg': '用户角色信息有误！'})
                return
            self.db.salers.find_one_and_update(
                {"id": saler_id}, {"$set": saler_info})

            self.render_json({'code': 200, 'msg': '提交成功！'})
        else:
            self.render_json({'code': 307, 'msg': '查询不到登录信息'})
        # else:
        #     self.render_json({'code':})
