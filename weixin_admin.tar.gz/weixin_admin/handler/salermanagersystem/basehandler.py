# coding=utf-8

from __future__ import absolute_import, print_function
import basehandler
import os
import logging
from apis import func
import math
import datetime
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest)
from tornado.escape import json_encode
import tornado.gen


class BaseHandler(basehandler.BaseHandler):
    def prepare(self):

        super(BaseHandler, self).prepare()
        if hasattr(self, 'tokenpass'):
            if self.tokenpass:
                return
        tk = self.token
        logging.debug('parameter of token:%s', tk)
        if len(tk) < 1:
            logging.debug("no token argument")
            self.not_login()
            return

        if self.saler_id < 1:
            logging.debug("salerid < 1")
            self.not_login()
            return
        # r = self.redis
        # key = self.ukey(self.saler_id)
        # token = r.hget(key, "token")
        # if token != tk:
        #     logging.debug("token changed %s => %s", tk, token)
        #     self.not_login()
        #     return
        saler_id = self.saler_id
        self.session = dict()
        saler = self.db.salers.find_one({'id': saler_id})
        if saler:
            saler = saler.to_dict()
            self.session['Saler'] = saler
            saler_id = saler.get('id', 0)
            device_id = saler.get('device_id', 0)
            device = self.db.devices.find_one({'id': device_id})
            is_pay = saler.get('is_pay',0)
            if is_pay != 1:
                self.render_json({'code':403,'msg':'您还未交费，请付款后重新登陆！'})
                self.finish()
            if device:
                expire_at = device.expire_at
                if expire_at:
                    now = datetime.datetime.now()
                    delta = (expire_at - now).days
                    if delta < 0:
                        self.render_json({'code': 201, 'msg': ' 账号已到期!'})
                        self.finish()
                        return
            redis = self.redis
            hkey = 'one:login:saler:id:{}'.format(saler_id)
            msid = self.token
            try:
                session_msid = redis.hget(hkey, 'msid')
            except Exception as e:
                logging.debug('error:%s', e)
            else:
                if session_msid == msid:
                    pass
                else:
                    del self.session['Saler']
                    self.render_json({'code': 302,
                                      'msg': '账号已在别处登录，请重新登录'})
                    self.finish()
        else:
            self.not_login()
            return

    @tornado.gen.coroutine
    def wechat_info_push(self, bill_id, msg=''):
        bill = self.db.bills.find_one({'id': bill_id})
        openid = bill.openid
        if openid:
            car_id = bill.car_id
            saler_id = bill.saler_id
            user_id = bill.user_id
            session = self.DB()
            Dealers = self.model('dealers')
            Salers = self.model('salers')
            Specs = self.model('specs')
            UserStatus = self.model('user_status')
            status_int = session.query(UserStatus.status). \
                filter(UserStatus.saler_id == saler_id,
                       UserStatus.user_id == user_id). \
                order_by(UserStatus.id.desc()).limit(1).scalar()

            dealer_query = session.query(Dealers.name).join(
                Salers, Dealers.id == Salers.dealer_id). \
                filter(Salers.id == saler_id).first()
            dealer_name = ''
            if dealer_query:
                dealer_name = dealer_query[0]
            car_name = ''
            car_query = session.query(Specs.name). \
                filter(Specs.id == car_id).first()
            if car_query:
                car_name = car_query[0]
            status = '跟进中'
            if status_int in [2, 3]:
                status = '已下单'
            elif status_int == 4:
                status = '订单已完成'
            elif status_int in [5, 8]:
                status = '订单已取消'
            elif status_int == 6:
                status = '运输中'
            elif status_int == 7:
                status = '已到店'
            now = datetime.datetime.now().replace(microsecond=0)
            redis = self.redis
            access_token_key = 'Chexiaoyi:access_token'
            access_token = redis.get(access_token_key)
            if access_token:
                pass
            else:
                access_token = yield self.get_access_token()
            logging.debug('access_token:%s', access_token)
            url = 'https://api.weixin.qq.com/cgi-bin/message/template/send?' \
                  'access_token={}'.format(access_token)
            headers = {"content-type": "application/json"}
            body = json_encode({
                "touser": openid,
                "template_id": "ottq3oWx2O1H-b3ulhnybEZesA5gfCchoULpmokhUws",
                "data": {
                    "first": {
                        "value": "订单提醒！",
                        "color": "#173177"
                    },
                    "keyword1": {
                        "value": str(now),
                        "color": "#173177"
                    },
                    "keyword2": {
                        "value": "车辆订单",
                        "color": "#173177"
                    },
                    "keyword3": {
                        "value": status,
                        "color": "#173177"
                    },
                    "keyword4": {
                        "value": dealer_name,
                        "color": "#173177"
                    },
                    "keyword5": {
                        "value": car_name,
                        "color": "#173177"
                    },
                    "remark": {
                        "value": msg,
                        "color": "#173177"
                    }
                }
            })
            request = HTTPRequest(
                url=url,
                method='POST',
                headers=headers,
                body=body,
                connect_timeout=60,
                request_timeout=60,
            )
            client = AsyncHTTPClient()
            response = yield client.fetch(request)
            if response.error:
                logging.debug('template push %s', response.error)
                return 0
            else:
                return 1
        else:
            return 2
