# coding=utf-8

from __future__ import absolute_import, print_function

import hashlib
import time
from operator import itemgetter

from .basehandler import BaseHandler
import logging
import datetime
import os
import json
from tornado.httputil import urlencode
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest)
from tornado.escape import (json_encode, json_decode)
import tornado.gen
import qrcode
from app import Application
from util import baidu

try:
    from StringIO import StringIO
except ImportError:
    from io import BytesIO as StringIO


def __handlers(settings):
    return [
        (r"/v2/sms/saler/info", SalerInfoHandler),
        (r"/v2/sms/info/edit", InfoEditHandler),
        (r"/v2/sms/bind", BindHandler),
        (r"/v2/sms/password/modify", PasswordModifyHandler),
        (r"/v2/sms/find/car", FindCarHandler),
        (r"/v2/sms/upload", UploadHandler),


    ]


class SalerInfoHandler(BaseHandler):
    def check_xsrf_cookie(self):
        pass

    def get(self):
        saler = self.session.get('Saler', False)
        results = []
        salers_name = saler.get('name', '')
        phone = saler.get('phone', '')
        salers_phone = 0
        if phone == 0:
            salers_phone = ''
        else:
            salers_phone = phone
        salers_username = saler.get('username', '')
        dealer_id = saler.get('dealer_id', '')
        saler_id = saler.get('id', '')
        Dealers = self.model('dealers')
        Salers = self.model('salers')
        session = self.DB()
        weixin_name = ''
        status = 0
        qrcode = ''
        dealers_info = session.query(Dealers.name, Dealers.company,
                                     Dealers.pic_door, Dealers.pic_show,
                                     Dealers.pic_rest, Dealers.pic_other). \
            filter(Dealers.id == dealer_id).first()
        if dealers_info:
            dealers_name = dealers_info[0]
            dealers_company = dealers_info[1]
            pic_door = dealers_info[2]
            pic_show = dealers_info[3]
            pic_rest = dealers_info[4]
            pic_other = dealers_info[5]
        else:
            dealers_name = ''
            dealers_company = ''
            pic_door = ''
            pic_show = ''
            pic_rest = ''
            pic_other = ''
        res = self.db.wechat_bind.find_one({"saler_id": saler_id})
        if res and res.openid is not None:
            status = 1
            res_saler_id = res.saler_id
            weixin_name = session.query(Salers.name). \
                filter(Salers.id == res_saler_id).first()[0]
        else:
            qrcode = 'https://cheyixiao.autoforce.net/static/qrcode/chexiaoyi.jpg'

        avatar = saler.get('avatar', '')

        results = dict(salers_name=salers_name,
                       salers_phone=salers_phone,
                       dealers_name=dealers_name,
                       dealers_company=dealers_company,
                       avatar=avatar,
                       pic_door=pic_door,
                       pic_show=pic_show,
                       pic_rest=pic_rest,
                       pic_other=pic_other,
                       status=status,
                       salers_username=salers_username,
                       weixin_name=weixin_name,
                       qrcode=qrcode,
                       )
        self.render_json({'results': results, 'code': 200})


class InfoEditHandler(BaseHandler):

    def check_xsrf_cookie(self):
        pass

    def post(self):
        saler = self.session.get('Saler', False)
        dealer_id = saler.get('dealer_id', '')
        saler_id = saler.get('id', '')
        salers_name = self.get_argument("salers_name", '')
        salers_phone = self.get_argument_int("salers_phone")
        dealers_name = self.get_argument("dealers_name", '')
        dealers_company = self.get_argument("dealers_company", '')

        pic_door = self.get_argument('pic_door', '')
        pic_show = self.get_argument('pic_show', '')
        pic_rest = self.get_argument('pic_rest', '')
        pic_other = self.get_argument('pic_other', '')
        avatar = self.get_argument('avatar', '')
        info1 = {}
        if salers_name:
            info1['name'] = salers_name
        if salers_phone:
            info1['phone'] = int(salers_phone)
        else:
            info1['phone'] = 0

        if avatar:
            info1['avatar'] = avatar
        info2 = {}

        if dealers_name == '':
            pass
        else:
            dealer = self.db.dealers.find_one({'name': dealers_name})
            if dealer and dealer.id != dealer_id:
                self.render_json({'code': 409, 'msg': '经销店名重复'})
                return
            elif dealer is None or dealer.id == dealer_id:
                info2['name'] = dealers_name
                info2['company'] = dealers_company
                if pic_door:
                    info2['pic_door'] = pic_door
                if pic_show:
                    info2['pic_show'] = pic_show
                if pic_rest:
                    info2['pic_rest'] = pic_rest
                if pic_other:
                    info2['pic_other'] = pic_other

        self.db.salers.update_one({'id': saler_id}, {'$set': info1})
        saler = self.db.salers.find_one({"id": saler_id})
        self.session_update_saler(saler.to_dict())
        self.db.dealers.update_one({'id': dealer_id}, {'$set': info2})
        self.render_json({'code': 200, 'msg': '操作成功'})


class UploadHandler(BaseHandler):
    ALLOWED_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.gif'}

    def check_xsrf_cookie(self):
        pass

    def post(self):
        basic_domain = 'https://cheyixiao.autoforce.net'
        extent_domain = 'upload/users'
        static_path = self.settings.get('static_path', '')
        dirpath = os.path.join(static_path, extent_domain)
        if not os.path.exists(dirpath):
            os.makedirs(dirpath)
        files = self.request.files.get('file')
        filepath = ''
        file_name = ''
        for file in files:
            fullname = os.path.basename(file['filename'])
            fname, fext = os.path.splitext(fullname)
            fext = fext.strip().lower()
            if fext not in self.ALLOWED_EXTENSIONS:
                continue
            current_time = int(time.time())
            file_name = str(current_time) + file['filename']
            filepath = os.path.join(dirpath, file_name)
            with open(filepath, 'wb') as f:
                f.write(file['body'])
        url = basic_domain + "/static/" + extent_domain + '/' + file_name

        self.render_json({'code': 200, 'url': url})


class PasswordModifyHandler(BaseHandler):
    def check_xsrf_cookie(self):
        pass

    def put(self):
        old_passwd = self.get_argument("old_passwd", '')
        new_passwd = self.get_argument("new_passwd", '')
        new_passwd2 = self.get_argument("new_passwd2", '')
        saler = self.session.get('Saler', False)
        saler_id = saler.get('id', '')
        password = self.db.salers.find_one({"id": saler_id}).password
        username = saler.get('username', '')
        password_md5 = self.db.salers.to_password(username, old_passwd)
        if password_md5 != password:
            self.render_json({'code': 203, 'msg': '密码不正确'})
            return
        if new_passwd != new_passwd2:
            self.render_json({'code': 203, 'msg': '输入密码不一致'})
            return
        else:
            query = {'id': saler_id}
            new_passwd_md5 = self.db.salers.to_password(username, new_passwd)
            info = {'password': new_passwd_md5}
            try:
                self.db.salers.update_one(query, {'$set': info})
                self.render_json({'code': 200, 'msg': '操作成功'})
            except Exception as e:
                logging.debug("update %s dealer fail %s", query, e)
                self.render_json({'code': 203, 'msg': '操作失败'})
                return


class BindHandler(BaseHandler):
    def check_xsrf_cookie(self):
        pass

    def post(self):
        Wechat_Bind = self.model('wechat_bind')
        session = self.DB()
        saler = self.session.get('Saler', False)
        saler_id = saler.get('id', '')
        res = self.db.wechat_bind.find_one({"saler_id": saler_id})
        if res:
            session.query(Wechat_Bind). \
                filter(Wechat_Bind.saler_id == saler_id).delete()
            session.commit()
            self.render_json({'code': 200, 'msg': '操作成功'})
        else:
            self.render_json({'code': 203, 'msg': '操作失败'})


class FindCarHandler(BaseHandler):

    def get(self):
        self.IP.load(os.path.abspath("ipip/17monipdb.datx"))
        res = self.IP.find(self.request.remote_ip)
        province = res.split('	')[1]
        xibei = {'甘肃', '青海', '宁夏', '陕西'}
        huabei = {'北京', '天津', '河北'}
        huadong = {'江苏', '浙江'}

        contact = ''
        phone = 0
        if province == '本机地址':
            contact = '车易销-华北区-车源部'
            phone = 18518186365
        elif province == '局域网':
            contact = '车易销-华北区-车源部'
            phone = 18518186365
        elif province in xibei:
            contact = '车易销-西北区-车源部'
            phone = 13910901782
        elif province in huabei:
            contact = '车易销-华北区-车源部'
            phone = 18518186365
        elif province in huadong:
            contact = '车易销-华东区-车源部'
            phone = 13701209627
        elif province == '安徽':
            contact = '车易销-安徽区-车源部'
            phone = 13739252839

        self.render_json(dict(code=200,
                              contact=contact,
                              phone=phone))

