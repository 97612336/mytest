# coding=utf-8

from __future__ import absolute_import, print_function

from operator import itemgetter

from .basehandler import BaseHandler
import logging
import datetime
import os
from tornado.httputil import urlencode
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest)
from tornado.escape import (json_encode, json_decode)
import tornado.gen
import qrcode
import json
from io import BytesIO
import tornado.web
import datetime
from collections import defaultdict
import pypinyin

try:
    from StringIO import StringIO
except ImportError:
    from io import BytesIO as StringIO

def __handlers(settings):
    return [
        (r"/v5/sms/activity", Activity_is_in),
        (r"/v5/sms/activity/integral", User_integral),
        (r"/v5/sms/activity/exchange", ActivityExchange),
        (r"/v5/sms/activity/rule", ActivityRule)
    ]


# 判断是否参加活动
class Activity_is_in(BaseHandler):
    def check_xsrf_cookie(self):
        pass

    def get(self, *args, **kwargs):
        # 获取saler_id
        saler_id = self.session_saler_info("id", '')
        # 根据saler_id查询表,如果查询到is_in=1,否则等于0
        session = self.DB()
        sql = "select count(1) from activity_score where saler_id=%s;" % saler_id
        res = session.execute(sql)
        try:
            res_num = res.fetchone()[0]
        except:
            res_num = 0
        if res_num == 0:
            # 没有参与
            return self.render_json({
                "code": 200,
                "is_in": 0
            })
        else:
            # 参与
            return self.render_json({
                "code": 200,
                "is_in": 1
            })

    def post(self, *args, **kwargs):
        saler_id = self.session_saler_info("id", '')
        session = self.DB()
        # 获取当前时间
        now = datetime.datetime.now()
        # 写sql语句
        sql = 'insert into activity_score (saler_id,join_time) values(%s,"%s")' % (saler_id, now)
        try:
            session.execute(sql)
            session.commit()
        except:
            logging.debug("存储用户活动信息失败")
            return self.render_json({
                "code": 500,
                "msg": "保存失败"
            })
        return self.render_json({
            "code": 200,
            "msg": "保存成功"
        })


# 返回用户积分的接口
class User_integral(BaseHandler):
    def get(self, *args, **kwargs):
        saler_id = self.session_saler_info("id", '')
        session = self.DB()
        # 根据用户的id查询表结构
        sql = 'select score from activity_score where saler_id=%s;' % saler_id
        try:
            res = session.execute(sql)
            res_score = res.fetchone()[0]
        except:
            res_score = 0
        return self.render_json({
            "code": 200,
            "integral": res_score
        })


# 积分兑换接口
class ActivityExchange(BaseHandler):
    def get(self, *args, **kwargs):
        saler_id = self.session_saler_info("id", '')

        return self.render_json({
            "code": 200,
            "can_exchange": 0
        })


# 积分兑换规则
class ActivityRule(BaseHandler):
    def get(self, *args, **kwargs):
        return self.render_json({
            "code": 200,
            "rule_one": {
                "活动时间": "2018年8月1日--2019年1月31日",
                "参与方式": "在本次【活动界面】，点击【参与活动】按钮，视为参与活动",
                "参与条件": "在活动期间内的所有注册用户皆可参与",
                "活动奖励": "自参与活动之日起，3个月（90天）后，获得的积分以10:1比例，可等价兑换礼包"
            },
            "rule_two": [
                "自参与活动之日起，3个月（90天）内",
                "每月前两次下单的可获得积分，每单得880积分，每月两单后不得积分，持续3个月（90天）；",
                "每日登录时长大于2小时的可获得积分，每次得60积分，每月二十次后不得积分，持续3个月（90天）；",
                "活动积分上限是8800积分，达到上限之后将不再获得积分，可直接兑换礼包；",
                "当日获得的积分将在次日发放；",
                "积分在参与活动3个月（90天）后，有30天的兑换时间，超过兑换时间未兑换的积分将被清零；",
                "兑换的奖励，我们将在7个工作日内发放到获奖用户的账号中；",
                "本活动的最终解释权归“车易销”运营团队所有。"
            ]
        })
