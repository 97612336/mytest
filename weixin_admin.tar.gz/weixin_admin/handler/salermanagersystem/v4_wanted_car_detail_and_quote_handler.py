# coding=utf-8

from __future__ import absolute_import, print_function
from .basehandler import BaseHandler
from datetime import date, timedelta, datetime


def __handlers(settings):
    return [
        (r"/v4/sms/car/detail", V4CarSearchDetailHandler),
        (r"/v4/sms/car/quote", V4CarQuotelHandler),
        (r"/v4/sms/car/quote/info", V4CarQuoteInfolHandler),
    ]


class V4CarSearchDetailHandler(BaseHandler):
    def get(self):
        find_id = self.get_argument("find_id", 0)
        if not find_id:
            self.render_json({"code": 202, "msg": "缺失参数 find_id !"})
            return
        pub_info = self.db.find_car.find_one({"id": find_id})
        pub_saler_id = pub_info.saler_id
        saler_id = self.saler_id
        session = self.DB
        find_car_sql = "select t2.name,t1.created_at,t1.end_time," \
                       "t3.i1,t1.color,t4.name as plate_city,t1.fetch_area," \
                       "t1.order_fee,t1.expect_price,t1.special_need," \
                       "t1.remark,t1.`status`,t1.car_format from " \
                       "cheyixiao.find_car as t1 join cheyixiao.salers as " \
                       "t2 on t1.saler_id=t2.id join afsaas.specs as t3 on" \
                       " t3.id=t1.spec_id join cheyixiao.areas as t4 on " \
                       "t1.plate_city=t4.id where t1.id=%s;"
        find_car_exec = session.execute(find_car_sql % find_id)
        find_car_res = find_car_exec.fetchone()
        result = dict()
        name = ""
        if find_car_res[0]:
            name = find_car_res[0][0] + "**"
        result["name"] = name
        result["release_time"] = str(find_car_res[1])[:-9]
        result["expire_time"] = str(find_car_res[2])[:-9]
        result["spec"] = find_car_res[3]
        result["color"] = find_car_res[4]
        result["plate_city"] = find_car_res[5]
        result["fetch_area"] = find_car_res[6]
        result["order_fee"] = find_car_res[7]
        result["expect_price"] = find_car_res[8]
        result["special_requirements"] = find_car_res[9].split(",")
        if find_car_res[9] == "暂无" or not find_car_res[9]:
            result["special_requirements"] = []
        result["remark"] = find_car_res[10]
        result["status"] = find_car_res[11]
        result["car_format"] = find_car_res[12]
        if saler_id == pub_saler_id:
            self.render_json({"code": 200, "result": result, "own": 1})
            return
        self.render_json({"code": 200, "result": result, "own": 0})


class V4CarQuotelHandler(BaseHandler):
    def check_xsrf_cookie(self):
        pass

    def post(self):
        # is saler_id = ***: info_origin=1
        info_origin = 0
        saler_id = self.saler_id
        if saler_id == 4:
            info_origin = 1
        find_id = self.get_argument("find_id", None)
        car_location = self.get_argument_int("car_location", None)
        validity_time = self.get_argument("validity_time", None)
        quote = self.get_argument("quote", None)
        remark = self.get_argument("remark")
        param_list = ["find_id", "car_location", "validity_time", "quote"]
        for param in param_list:
            if vars()[param] is None:
                self.render_json({"code": 202,
                                  "msg": "参数%s缺失！" % param})
                return
        insert_data = dict(
            find_id=int(find_id),
            saler_id=saler_id,
            location=car_location,
            quote=quote,
            end_time=validity_time,
            remark=remark,
            info_origin=info_origin
        )
        self.db.quote.insert_one(insert_data)
        self.render_json({"code": 200, "msg": "发布报价成功！"})


class V4CarQuoteInfolHandler(BaseHandler):
    def get(self):
        page = self.get_argument_int("page", 1)
        page_size = self.get_argument_int("page_size", 10)
        start = (page-1) * page_size
        end = page * page_size
        find_id = self.get_argument_int("find_id")
        if not find_id:
            self.render_json({"code": 202, "msg": "缺失必要参数find_id"})
            return
        pub_info = self.db.find_car.find_one({"id": find_id})
        pub_saler_id = pub_info.saler_id
        saler_id = self.saler_id
        quote_info_sql = "select t1.avatar,t1.name,t1.phone,t3.address " \
                         "as dealer_address,t1.address as " \
                         "saler_address, t4.`name` as " \
                         "location,t2.quote,t2.end_time," \
                         "t2.remark, t2.info_origin, t2.saler_id from " \
                         "cheyixiao.salers " \
                         "as t1 right join cheyixiao.quote as t2 on " \
                         "t1.id=t2.saler_id right join cheyixiao.dealers as " \
                         "t3 on t1.dealer_id=t3.id left join cheyixiao.areas" \
                         " as t4 on t2.location=t4.id where t2.find_id=%d " \
                         "and end_time > \"%s\" " \
                         "order by t2.info_origin desc,t2.created_at desc ;"
        session = self.DB
        exec = session.execute(quote_info_sql %
                               (find_id, str(datetime.now())[:-7]))
        res_list = exec.fetchall()
        if not res_list:
            self.render_json({"code": 200, "results": []})
            return
        total = len(res_list)
        results = []
        if pub_saler_id == saler_id:
            for res in res_list[start: end]:
                tmp_dict = dict()
                tmp_dict["avatar"] = res[0] or ""
                tmp_dict["name"] = res[1] or ""
                tmp_dict["phone"] = res[2] or ""
                tmp_dict["address"] = res[3] or res[4] or ""
                tmp_dict["car_location"] = res[5]
                tmp_dict["quote"] = res[6]
                tmp_dict["validity_time"] = str(res[7])[:-9]
                tmp_dict["remark"] = res[8]
                info_origin = res[9]
                tmp_dict["origin"] = ""
                if info_origin == 1:
                    tmp_dict["origin"] = "车势科技报价"
                results.append(tmp_dict)
            self.render_json({"code": 200, "results": results,
                              "total": total})
            return
        for res in res_list[start: end]:
            tmp_dict = dict()
            tmp_dict["avatar"] = res[0] or ""
            name = ""
            if res[1]:
                name = res[1][0] + "**"
            tmp_dict["name"] = name
            phone = ""
            if res[2]:
                phone = str(res[2])[:3] + "********"
            tmp_dict["phone"] = phone
            address = ""
            if res[3]:
                address = res[3][:2] + "******"
            tmp_dict["address"] = address
            tmp_dict["remark"] = "******"
            tmp_dict["quote"] = "******"
            if res[10] == saler_id:
                tmp_dict["name"] = res[1] or ""
                tmp_dict["phone"] = res[2] or ""
                tmp_dict["address"] = res[3] or res[4] or ""
                tmp_dict["remark"] = res[8]
                tmp_dict["quote"] = res[6]
            tmp_dict["car_location"] = res[5]
            tmp_dict["validity_time"] = str(res[7])[:-9]
            info_origin = res[9]
            tmp_dict["origin"] = ""
            if info_origin == 1:
                tmp_dict["origin"] = "车势科技报价"
            results.append(tmp_dict)
        self.render_json({"code": 200, "results": results,
                          "total": total})

