# coding=utf-8

from __future__ import absolute_import, print_function

import hashlib
import time
from operator import itemgetter

from .basehandler import BaseHandler
import logging
import datetime
import os
import json
from tornado.httputil import urlencode
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest)
from tornado.escape import (json_encode, json_decode)
import tornado.gen
import qrcode
from app import Application
from util import baidu

try:
    from StringIO import StringIO
except ImportError:
    from io import BytesIO as StringIO


def __handlers(settings):
    return [
        (r"/v3B/sms/user/register", V3BRegisterHandler),
        (r"/v3B/sms/user/login", V3BLoginHandler),
        (r"/v3B/sms/user/certification", V3BCertifictionHandler),
        (r"/v3B/sms/saler/info", V3BSalerInfoHandler),
        (r"/v3B/sms/userinfo/modify", V3BModifyHandler),
    ]


class V3BRegisterHandler(BaseHandler):
    tokenpass = True

    def check_xsrf_cookie(self):
        pass

    def post(self):
        username = self.get_argument('username', '')
        dealers = self.db.dealers.find_one({'name': username})
        salers = self.db.salers.find_one({'username': username})
        if salers or dealers:
            self.render_json({'code': 406, 'msg': '账号已存在'})
            return
        passwd = self.get_argument('passwd', '')
        reference = self.get_argument('reference', '')

        if not all((username, passwd)):
            self.render_json({'code': 407, 'msg': '提交信息有误！'})
            return

        saler_info = {}
        saler_info['username'] = username
        saler_info['password'] = passwd
        saler_info['reference'] = reference
        saler_info['perm'] = 1
        saler_info['cert_code'] = 0
        saler_info['role'] = 1
        saler_info['is_pay'] = 0
        res_saler = self.db.salers.insert_one(saler_info)

        self.login_session_update(res_saler.id, res_saler.to_dict())
        redis = self.redis
        hkey = 'one:login:saler:id:{}'.format(res_saler.id)
        cur_time = str(datetime.datetime.now().replace(microsecond=0))
        token = self.gen_token()
        msid = token
        ip = self.request.remote_ip
        dic = {"msid": msid, "ip": str(ip), "time": cur_time}
        redis.hmset(hkey, dic)
        self.update_user_token(res_saler.id, token)

        self.render_json({"code": 200, "msg": "注册成功！",
                          'role': res_saler.role,
                          'perm': res_saler.perm,
                          'name': res_saler.name,
                          'avatar': res_saler.avatar,
                          'Cyx_token': token,
                          'Cyx_saler': res_saler.id,
                          'username': res_saler.username,
                          'cert_code': res_saler.cert_code,
                          'expire': False,
                          "register_fee": "2888元",
                          'pay_url': 'https://cheyixiao.autoforce.net/v3/wx/register/payment?saler_id=%s' % res_saler.id})


class V3BLoginHandler(BaseHandler):
    tokenpass = True

    def check_xsrf_cookie(self):
        pass

    def post(self):
        username = self.get_argument('username', '')
        passwd = self.get_argument('passwd', '')
        if not all((username, passwd)):
            self.render_json({'code': 208, 'msg': '账号或密码错误'})
            return

        passwd_md5 = self.db.salers.to_password(username, passwd)
        query = {'username': username}
        saler = self.db.salers.find_one(query)
        if saler:
            if saler.password == passwd or saler.password == passwd_md5:
                saler_id = saler.id
                token = self.gen_token()

                self.login_session_update(saler_id, saler.to_dict())
                redis = self.redis
                hkey = 'one:login:saler:id:{}'.format(saler.id)
                cur_time = str(datetime.datetime.now().replace(microsecond=0))
                msid = token
                ip = self.request.remote_ip
                dic = {"msid": msid, "ip": str(ip), "time": cur_time}
                redis.hmset(hkey, dic)
                self.update_user_token(saler.id, token)

                avatar = saler.avatar
                if not avatar or avatar == 'None':
                    avatar = ''

                if saler.is_pay == 1:
                    self.render_json({'code': 200, 'msg': '登录成功',
                                      'expire': False,
                                      'name': saler.name,
                                      'avatar': avatar,
                                      'Cyx_token': token,
                                      'Cyx_saler': saler.id,
                                      'cert_code': saler.cert_code,
                                      'role': saler.role,
                                      'username': saler.username})
                else:
                    is_paid = saler.is_pay
                    if is_paid != 1:
                        is_paid = 0
                    self.render_json({'code': 200, 'msg': '登陆失败，您尚未付款，请扫描二维码付款！',
                                      'is_paid': is_paid,
                                      "register_fee": "2888元",
                                      'pay_url': 'https://cheyixiao.autoforce.net/v3/wx/register/payment?saler_id=%s' % saler.id})
            else:
                self.render_json({'code': 207, 'msg': '密码错误！'})
        else:
            self.render_json({'code': 207, 'msg': '用户名错误！'})


class V3BCertifictionHandler(BaseHandler):
    def check_xsrf_cookie(self):
        pass

    def post(self):
        avatar_url = self.get_argument('avatar_url', '')
        name = self.get_argument('name', '')
        phone = self.get_argument('phone', '')
        address = self.get_argument('address', '')
        city = self.get_argument('city', '')

        saler_info = {}
        saler_info['avatar'] = avatar_url
        saler_info['name'] = name
        try:
            saler_info['phone'] = int(phone)
        except Exception as e:
            self.render_json({'code': 500, 'msg': '电话号码只能为数字！'})
            return
        saler_info['city'] = int(city)
        saler_info['address'] = address
        saler_info['cert_code'] = 1

        if not all((name, phone, address, city)):
            self.render_json({'code': 500, 'msg': '个人信息不可为空！'})
            return

        saler_id = self.session_saler_info('id', 0)
        if saler_id:
            Salers = self.model('salers')
            Dealers = self.model('dealers')
            role = self.DB.query(Salers.role). \
                filter(Salers.id == saler_id).first()
            if role:
                role = role[0]
            if int(role) == 1:
                licence_url = self.get_argument('license', '')
                if not licence_url:
                    self.render_json({'code': 500, 'msg': '营业执照不可为空！'})
                    return
                pic_door = self.get_argument('pic_door', '')
                pic_show = self.get_argument('pic_show', '')
                pic_rest = self.get_argument('pic_rest', '')
                pic_other = self.get_argument('pic_other', '')

                store_name = self.get_argument('st_name', '')
                if not store_name:
                    self.render_json({'code': 500, 'msg': '店名不可为空！'})
                    return
                company = self.get_argument('company', '')
                store_address = self.get_argument('st_addr', '')
                store_phone = self.get_argument('st_phone', '')
                charge_name = self.get_argument('ch_name', '')
                charge_phone = self.get_argument('ch_phone', '')

                dealers_info = {}
                dealers_info['pic_door'] = pic_door
                dealers_info['pic_show'] = pic_show
                dealers_info['pic_rest'] = pic_rest
                dealers_info['pic_other'] = pic_other
                dealers_info['bus_licence'] = licence_url
                dealers_info['company'] = company
                dealers_info['address'] = store_address
                dealers_info['call'] = store_phone
                dealers_info['ch_name'] = charge_name
                try:
                    dealers_info['phone'] = int(charge_phone)
                except Exception as e:
                    dealers_info['phone'] = 0

                # 根据店名查到的
                dealers_id = self.DB.query(Dealers.id).filter(Dealers.name == store_name).all()
                # 根据saler_id查到的
                dealer_id = self.DB.query(Salers.dealer_id).filter(Salers.id == saler_id).first()

                # 如果老用户，更新，不存在，插入
                if dealer_id[0] != None:
                    if not dealers_id or dealers_id[0] == dealer_id:
                        dealers_info['name'] = store_name
                    else:
                        self.render_json({'code': 409, 'msg': '该店名已存在！'})
                        return
                    res_dealer = self.db.dealers.find_one_and_update(
                        {"id": dealer_id[0]}, {"$set": dealers_info})
                    saler_info['dealer_id'] = res_dealer.id
                else:
                    if not dealers_id:
                        dealers_info['name'] = store_name
                    else:
                        self.render_json({'code': 409, 'msg': '该店名已存在！'})
                        return
                    res_dealer = self.db.dealers.insert_one(dealers_info)
                    saler_info['dealer_id'] = res_dealer.id
            else:
                self.render_json({'code': 500, 'msg': '用户角色信息有误！'})
                return

            res_saler = self.db.salers.find_one_and_update(
                {"id": saler_id}, {"$set": saler_info}, upsert=True)

            Brands = self.model('brands')
            brands = self.DB.query(Brands.id).all()
            if brands:
                for brand in brands:
                    if not self.db.dealer_brand.find_one(
                            {'dealer_id': res_saler.dealer_id, 'brand_id': brand[0]}):
                        self.db.dealer_brand.insert_one \
                            ({'dealer_id': res_saler.dealer_id, 'brand_id': brand[0],
                              "onsell": 0})

            self.render_json({'code': 200, 'msg': '提交成功！'})
        else:
            self.render_json({'code': 307, 'msg': '查询不到登录信息'})


class V3BSalerInfoHandler(BaseHandler):
    def check_xsrf_cookie(self):
        pass

    def get(self):
        saler_id = self.session_saler_info('id', 0)
        session = self.DB()
        Salers = self.model('salers')
        saler_Info = session.query(Salers.name,
                                   Salers.phone,
                                   Salers.address,
                                   Salers.city,
                                   Salers.role,
                                   Salers.cert_code,
                                   Salers.avatar,
                                   Salers.username,
                                   Salers.reference,
                                   Salers.reason). \
            filter(Salers.id == saler_id).first()

        name = saler_Info[0]
        phone = saler_Info[1]
        address = saler_Info[2]
        city = saler_Info[3]
        role = saler_Info[4]
        cert_code = saler_Info[5]
        avatar = saler_Info[6]

        if not avatar or avatar == 'None':
            avatar = ''
        username = saler_Info[7]
        reference = saler_Info[8]
        if not reference or reference == 'None':
            reference = ''
        pro_dict = {}
        if city:
            Area = self.model('areas')
            city_info = tuple(self.DB.query(Area.id, Area.name, Area.pid). \
                              filter(Area.id == int(city)).first())
            pro_info = self.DB.query(Area.id, Area.name, Area.pid). \
                filter(Area.id == city_info[2]).first()
            city_dict = {}
            city_dict['id'] = city_info[0]
            city_dict['name'] = city_info[1]
            pro_dict['id'] = pro_info[0]
            pro_dict['name'] = pro_info[1]
            pro_dict['city'] = city_dict

        self.db.salers.find_one({'id': saler_id})

        weixin_name = ''
        status = 0
        qrcode = ''
        res = self.db.wechat_bind.find_one({"saler_id": saler_id})
        if res and res.openid is not None:
            status = 1
            res_saler_id = res.saler_id
            weixin_name = session.query(Salers.name). \
                filter(Salers.id == res_saler_id).first()[0]
        else:
            qrcode = "https://cheyixiao.autoforce.net/static" \
                     "/qrcode/chexiaoyi.jpg"

        results = dict(salers_name=name,
                       salers_phone=phone,
                       salers_address=address,
                       salers_city=pro_dict,
                       salers_role=role,
                       salers_certcode=cert_code,
                       salers_avatar=avatar,
                       status=status,
                       weixin_name=weixin_name,
                       qrcode=qrcode,
                       saler_username=username,
                       reference=reference,
                       )
        if cert_code == 3:
            reason = saler_Info[9]
            if not reason or reason == 'None':
                results['reason'] = '您暂未通过审核，请修改信息后再次提交！'
            else:
                results['reason'] = reason
        if role == 1:
            dealer_id = session.query(Salers.dealer_id). \
                filter(Salers.id == saler_id).first()[0]
            Dealers = self.model('dealers')
            dealers_info = session.query(Dealers.name, Dealers.company,
                                         Dealers.address,
                                         Dealers.call, Dealers.ch_name,
                                         Dealers.phone,
                                         Dealers.bus_licence,
                                         Dealers.pic_door, Dealers.pic_show,
                                         Dealers.pic_rest, Dealers.pic_other). \
                filter(Dealers.id == dealer_id).first()
            if dealers_info:
                dealers_name = dealers_info[0]
                dealers_company = dealers_info[1]
                dealers_address = dealers_info[2]
                dealers_call = dealers_info[3]
                dealers_chname = dealers_info[4]
                dealers_phone = dealers_info[5]
                dealers_buslicense = dealers_info[6]
                pic_door = dealers_info[7]
                pic_show = dealers_info[8]
                pic_rest = dealers_info[9]
                pic_other = dealers_info[10]
                if dealers_company == 'None':
                    dealers_company = ''
                if not pic_door or pic_door == 'None':
                    pic_door = ''
                if not pic_show or pic_show == 'None':
                    pic_show = ''
                if not pic_rest or pic_rest == 'None':
                    pic_rest = ''
                if not pic_other or pic_other == 'None':
                    pic_other = ''
                if not dealers_chname or dealers_chname == 'None':
                    dealers_chname = ''
                if not dealers_call or dealers_call == 'None':
                    dealers_call = ''
                if not dealers_phone or dealers_phone == 0:
                    dealers_phone = ''
                if not dealers_address or dealers_address == 'None':
                    dealers_address = ''
            else:
                dealers_name = ''
                dealers_company = ''
                dealers_address = ''
                dealers_call = ''
                dealers_chname = ''
                dealers_phone = ''
                dealers_buslicense = ''
                pic_door = ''
                pic_show = ''
                pic_rest = ''
                pic_other = ''
            results['dealers_name'] = dealers_name
            results['dealers_company'] = dealers_company
            results['dealers_address'] = dealers_address
            results['dealers_call'] = dealers_call
            results['dealers_chname'] = dealers_chname
            results['dealers_phone'] = dealers_phone
            results['dealers_buslicense'] = dealers_buslicense
            results['pic_door'] = pic_door
            results['pic_show'] = pic_show
            results['pic_rest'] = pic_rest
            results['pic_other'] = pic_other
        elif role == 3 or role == 4:
            ID_info = self.DB.query(Salers.ID_face, Salers.ID_con). \
                filter(Salers.id == saler_id).first()
            ID_face = ID_info[0]
            ID_con = ID_info[1]
            results['ID_face'] = ID_face
            results['ID_con'] = ID_con
        else:
            self.render_json({'code': 203, 'msg': '该用户信息不存在'})
        self.render_json({'results': results, 'code': 200})


class V3BModifyHandler(BaseHandler):
    def check_xsrf_cookie(self):
        pass

    def post(self):
        saler_id = self.session_saler_info('id', 0)
        avatar_url = self.get_argument('avatar_url', '')
        name = self.get_argument('name', '')
        phone = self.get_argument('phone', '')
        address = self.get_argument('address', '')
        city = self.get_argument('city', '')
        if not all((name, phone, address, city)):
            self.render_json({'code': 500, 'msg': '个人信息不可为空！'})
            return
        saler_info = {}
        saler_info['avatar'] = avatar_url
        saler_info['name'] = name
        try:
            saler_info['phone'] = int(phone)
        except Exception as e:
            self.render_json({'code': 500, 'msg': '电话号码只能为数字！'})
            return
        saler_info['city'] = int(city)
        saler_info['address'] = address

        if saler_id:
            Salers = self.model('salers')
            role = self.DB.query(Salers.role). \
                filter(Salers.id == saler_id).first()
            if role:
                role = role[0]
            # 角色为经销商
            if int(role) == 1:
                licence_url = self.get_argument('license', '')
                pic_door = self.get_argument('pic_door', '')
                pic_show = self.get_argument('pic_show', '')
                pic_rest = self.get_argument('pic_rest', '')
                pic_other = self.get_argument('pic_other', '')
                if not licence_url:
                    self.render_json({'code': 500, 'msg': '营业执照不可为空！'})
                    return
                store_name = self.get_argument('st_name', '')
                company = self.get_argument('company', '')
                store_address = self.get_argument('st_addr', '')
                store_phone = self.get_argument('st_phone', '')
                charge_name = self.get_argument('ch_name', '')
                charge_phone = self.get_argument('ch_phone', '')
                if not store_name:
                    self.render_json({'code': 500, 'msg': '店名不可为空！'})
                    return

                dealers_info = {}
                dealers_info['pic_door'] = pic_door
                dealers_info['pic_show'] = pic_show
                dealers_info['pic_rest'] = pic_rest
                dealers_info['pic_other'] = pic_other
                dealers_info['bus_licence'] = licence_url
                dealers_info['company'] = company
                dealers_info['address'] = store_address
                dealers_info['call'] = store_phone
                dealers_info['ch_name'] = charge_name
                try:
                    dealers_info['phone'] = int(charge_phone)
                except Exception as e:
                    dealers_info['phone'] = 0

                dealer_id = self.db.salers.find_one({'id': saler_id}).dealer_id
                dealers = self.db.dealers.find_one({'name': store_name})
                dealers_id = ''
                if dealers:
                    dealers_id = dealers.id
                if dealers_id:
                    if dealers_id == dealer_id:
                        dealers_info['name'] = store_name
                    else:
                        self.render_json({'code': 409, 'msg': '该店名已存在！'})
                        return

                res_dealer = self.db.dealers.find_one_and_update(
                    {"id": dealer_id}, {"$set": dealers_info})
                saler_info['dealer_id'] = res_dealer.id
            else:
                self.render_json({'code': 500, 'msg': '用户角色信息有误！'})
                return
            self.db.salers.find_one_and_update(
                {"id": saler_id}, {"$set": saler_info})

            self.render_json({'code': 200, 'msg': '提交成功！'})
        else:
            self.render_json({'code': 307, 'msg': '查询不到登录信息'})
