# coding=utf-8

from __future__ import absolute_import, print_function
from .basehandler import BaseHandler
import logging
import datetime
import os
from tornado.httputil import urlencode
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest)
from tornado.escape import (json_encode, json_decode)
import tornado.gen
import qrcode
import json
from io import BytesIO
import tornado.web
import datetime
from collections import defaultdict

try:
    from StringIO import StringIO
except ImportError:
    from io import BytesIO as StringIO


def __handlers(settings):
    return [
        (r"/v4/sms/bill/complete", UploadBillHandler),
    ]


class UploadBillHandler(BaseHandler):

    def check_xsrf_cookie(self):
        pass

    def post(self):
        user_id = self.get_argument("user_id")
        invoice = self.get_argument("invoice")
        dr_license = self.get_argument("dr_license")
        if not invoice:
            self.render_json({"code": 407, "msg": "请传入必要参数 invoice"})
        session = self.DB
        STATUS = 4
        sql = "update user_status set status={0} " \
              "where user_id={1}"
        try:
            session.execute(sql.format(STATUS, user_id))
            session.commit()
        except Exception as e:
            logging.debug("update user_status error :{} !".format(e))
            self.render_json({"code": 502, "msg": "状态变更失败！"})
            return

        hkey = 'rank'
        saler_id = self.session_saler_info('id', 0)
        saler = self.db.salers.find_one({"id": saler_id})
        if saler:
            rank_info = self.redis.hget(hkey, key=saler_id)
            if not rank_info:
                self.redis.hset(hkey, saler_id, {"phone": saler.phone, "name": saler.name, "salernum": 1})
            else:
                rank = json.loads(rank_info.replace("'", '"'))
                salernum = rank.get('salernum') + 1
                self.redis.hset(hkey, saler_id, {"phone": saler.phone, "name": saler.name, "salernum": salernum})

        # invoice = invoice.strip("\n")
        if not dr_license:
            sql = """update bills set invoice='{0}' where user_id={1}"""
            try:
                session.execute(sql.format(invoice, user_id))
                session.commit()
            except Exception as e:
                logging.debug("update bills error:%s", e)
                self.render_json({"code": 406, "msg": "用户不存在"})
                return
            self.render_json({"code": 200, "msg": "操作成功", "status": STATUS})
            return
        # dr_license = dr_license.strip("\n")
        sql = """update bills set invoice='{0}',dr_license='{1}'
 where user_id={2}"""
        try:
            session.execute(sql.format(invoice, dr_license, user_id))
            session.commit()
        except Exception as e:
            logging.debug("update bills error:%s", e)
            self.render_json({"code": 409, "msg": "用户不存在"})
            return

        self.render_json({"code": 200, "msg": "操作成功", "status": STATUS})
