# coding=utf-8

from __future__ import absolute_import, print_function
from .basehandler import BaseHandler


def __handlers(settings):
    return [
        (r"/v4/sms/car/search", V4CarSearchHandler),
    ]


class V4CarSearchHandler(BaseHandler):

    def check_xsrf_cookie(self):
        pass

    def post(self):
        origin = self.get_argument('origin', '')
        spec_id = self.get_argument('spec_id', '')
        color = self.get_argument('color', '')
        plate_city = self.get_argument_int('plate_city', '')
        end_date = self.get_argument('end_date', '')
        fetch_area = self.get_argument('fetch_area', '')
        order_fee = self.get_argument_int('order_fee', '')
        expected_price = self.get_argument('expected_price', '')
        param_list = ["origin", "spec_id", "color", "plate_city",
                      "end_date", "fetch_area", "order_fee", "expected_price"]
        for param in param_list:
            if vars()[param] is '':
                self.render_json({"code": 202,
                                  "msg": "字段%s不可为空！" % param})
                return
        special_requirements = self.get_argument('special_requirements', '')
        remark = self.get_argument('remark', '')

        saler_id = self.saler_id

        find_info = dict(
            saler_id=saler_id,
            spec_id=spec_id,
            car_format=origin,
            color=color,
            plate_city=plate_city,
            fetch_area=fetch_area,
            end_time=end_date,
            order_fee=order_fee,
            expect_price=expected_price,
            special_need=special_requirements,
            remark=remark,
            status=1
        )
        self.db.find_car.insert_one(find_info)
        self.render_json({'code': 200, 'msg': '提交成功！正在为您发布寻车！'})


