# coding=utf-8

from __future__ import absolute_import, print_function

import base64
import hashlib
import time

from .basehandler import BaseHandler
import logging
import datetime
import os
import json
from tornado.httputil import urlencode
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest)
from tornado.escape import (json_encode, json_decode)
import tornado.gen
import qrcode
from app import Application

try:
    from StringIO import StringIO
except ImportError:
    from io import BytesIO as StringIO


def __handlers(settings):
    return [
        (r"/v2/sms/img", ImageHandler),
        (r"/v2/sms/car/parts", CarPartsHandler),
        (r"/v2/sms/car/part/up", UplineHandler),
        (r"/v2/sms/car/part/down", DownlineHandler),
        (r"/v2/sms/car/part", CarPartIndex),
    ]


class ImageHandler(BaseHandler):
    ALLOWED_EXTENSIONS = {'.png', '.jpg', '.jpeg'}
    # 当前开发用的域名
    BASIC_DOMAIN = "https://cheyixiao.autoforce.net/static/"
    def get(self):
        img_id = self.get_argument_int("img_id", 0)
        self.db.imgs.query().filter_by(id=img_id).delete()
        self.DB.commit()
        self.render_json({"code": 200, "msg": "操作成功！"})

    def check_xsrf_cookie(self):
        pass

    def post(self):
        # 服务器本地静态文件夹的绝对路径
        self.upload_path = os.path.join('JPimg')
        static_path = self.settings.get('static_path', '')
        if len(static_path) < 1:
            self.set_status(504)
            return
        # logging.debug("static_path:%s", static_path)
        upload_path = self.settings.get('upload_path', '')
        if len(upload_path) < 1:
            self.set_status(504)
            return
        # logging.debug("upload_path:%s", upload_path)

        prefix = ''
        if hasattr(self, 'upload_path'):
            prefix = self.upload_path  # /JPimg

        yearstr = datetime.date.today().strftime("%Y")
        datestr = datetime.date.today().strftime("%m-%d")
        # settings中默认upload_path为'upload'
        fullprefix = os.path.join(upload_path, prefix, yearstr, datestr)
        # 生成开发环境下的头像存储路径
        deploymentfullprefix = os.path.join(self.BASIC_DOMAIN, fullprefix)
        # /home.../static/upload/JPimg/年/月-日
        filepath = os.path.join(static_path, fullprefix)
        if not os.path.exists(filepath):
            os.makedirs(filepath)

        showname = ''

        bfile = self.get_argument('img', '')
        # logging.debug('bfile:%s', bfile)
        if len(bfile) > 0:
            data = bfile.split(';base64,')
            if len(data) < 2:
                self.set_status(504)
                return
            fext = data[0].split('/')[-1] or 'png'
            data = base64.decodebytes(str.encode(data[1]))
            m = hashlib.md5(str(time.ctime()).encode("utf-8"))
            picname = m.hexdigest()
            filename = picname + '.' + fext
            fullname = os.path.join(filepath, filename)
            showname = os.path.join(deploymentfullprefix, filename)
            # logging.debug('showname：%s', showname)
            # logging.debug('fullname：%s', fullname)
            with open(fullname, 'wb') as up:
                up.write(data)

        else:
            imgfile = self.request.files.get('img')
            # logging.debug('imgfile:%s', imgfile)
            for meta in imgfile:
                # 得到图片的名字
                originfilename = os.path.basename(meta['filename'])
                # logging.debug('res:%s', meta['filename'])
                fname, fext = os.path.splitext(originfilename)
                fext = fext.strip().lower()  # 得到图片的类型并进行小写转换
                if fext not in self.ALLOWED_EXTENSIONS:  # 判断图片类型合法性
                    self.render_json({"code": 408,
                                      "msg": "请上传png、jepg、jpg格式图片"})
                    return
                m = hashlib.md5(str(time.ctime()).encode("utf-8"))
                picname = m.hexdigest()  # 图片名统一使用经md5摘要过的
                filename = picname + fext  # 头像名+后缀
                # 服务器本地写入头像文件的绝对路径
                fullname = os.path.join(filepath, filename)
                # 生成存入数据库及返回给前端的头像文件url
                showname = os.path.join(deploymentfullprefix, filename)
                # logging.debug('showname：%s', showname)
                # logging.debug('fullname：%s', fullname)
                with open(fullname, 'wb') as up:
                    up.write(meta['body'])
        info = {'url': showname}
        try:
            res = self.db.imgs.insert_one(info)
        except Exception as e:
            # logging.debug("insert img fail %s %s", showname, e)
            self.render_json({'error': e})
            return
        else:
            pass
            # logging.debug('img:%s', showname)
        self.render_json({'id': res.id, 'url': showname, 'code': 200})


class CarPartsHandler(BaseHandler):

    def get(self):
        id = self.get_argument("id")
        self.db.car_part_category.query().filter_by(id=id).delete()
        self.db.car_parts.query().filter_by(category_id=id).\
            delete(synchronize_session='fetch')
        self.DB.commit()
        self.render_json({"code": 200, "msg": "操作成功！"})

    def check_xsrf_cookie(self):
        pass

    def post(self):
        json_data = self.get_argument("data", "")
        if not json_data:
            self.render_json({"code": 402, "msg": "请求数据为空！"})
            return
        data = json.loads(json_data)
        id = data["id"]
        if not id:
            id = ''
        name = data["name"]
        img_id = data["img_id"] or None
        if not img_id:
            img_id = 0
        price = data["price"]
        saler_id = self.session_saler_info("id", "")
        dealer_id = self.db.salers.find_one({"id": saler_id}).dealer_id
        info = dict(
            id=id,
            name=name,
            dealer_id=dealer_id,
            price=format(float(price), "0.2f"),
            img_id=int(img_id)
        )
        res = self.db.car_part_category.\
            find_one_and_update({'id': id}, {'$set': info}, upsert=True)

        data_list = data.get("subclass", [])
        category_id = res.id
        cp_ids = []
        for data in data_list:
            cprice = data["price"]
            temp_dict = {}
            temp_dict.update({"category_id": category_id})
            id = data["cp_id"]
            if not id:
                id = ''
            temp_dict["img_id"] = data["img_id"] or None
            temp_dict["name"] = data["name"]
            if cprice:
                temp_dict["price"] = format(float(cprice), "0.2f")
            else:
                temp_dict["price"] = 0
            res_cp = self.db.car_parts.\
                find_one_and_update({'id': id}, {'$set': temp_dict},
                                    upsert=True)
            cp_ids.append(res_cp.id)
        now_car_parts = self.db.car_parts.query().\
            filter_by(category_id=category_id).all()
        for car_part in now_car_parts:
            id = car_part.id
            if id not in cp_ids:
                self.db.car_parts.query().filter_by(id=id).delete()
                self.DB.commit()
        self.render_json({"code": 200, "msg": "操作成功！"})


class UplineHandler(BaseHandler):

    def get(self):
        id = self.get_argument_int('id')
        if not id:
            self.render_json({"code": 500, "msg": "请求错误！"})
        self.db.car_part_category.find_one_and_update(
            {'id': id}, {'$set': {'status': 2,
                                  'upline_at': datetime.datetime.now()}})

        self.render_json({"code": 200, "msg": "操作成功！"})


class DownlineHandler(BaseHandler):

    def get(self):
        id = self.get_argument_int('id')
        self.db.car_part_category.find_one_and_update(
            {'id': id}, {'$set': {'status': 1,
                                  'downline_at': datetime.datetime.now()}})
        self.render_json({"code": 200, "msg": "操作成功！"})


class CarPartIndex(BaseHandler):

    def get(self):
        page = self.get_argument_int("page", 1)
        pagesize = self.get_argument_int("pagesize", 10)
        saler_id = self.session_saler_info("id", 1)
        dealer_id = self.db.salers.find_one({"id": saler_id}).dealer_id
        res_list = []
        cp_category_list = self.db.car_part_category.query().\
            filter_by(dealer_id=dealer_id).all()
        for cp_category in cp_category_list:
            tmp_dict = {}
            cp_category_id = cp_category.id
            tmp_dict["id"] = cp_category.id
            tmp_dict["dealer_id"] = cp_category.dealer_id
            tmp_dict["name"] = cp_category.name
            tmp_dict["price"] = cp_category.price
            img = self.db.imgs.find_one({"id": cp_category.img_id})
            if not img:
                tmp_dict["img_url"] = ''
                tmp_dict["img_id"] = ''
            else:
                tmp_dict["img_url"] = img.url
                tmp_dict["img_id"] = img.id
            up = cp_category.upline_at
            if up:
                tmp_dict["upline_at"] = str(up)[:-3]
            else:
                tmp_dict["upline_at"] = ''
            created_at = cp_category.created_at
            if created_at:
                tmp_dict["created_at"] = str(created_at)[:-3]
            else:
                tmp_dict["created_at"] = ''
            tmp_dict["status"] = cp_category.status

            tmp_list = []
            cp_list = self.db.car_parts.query().\
                filter_by(category_id=cp_category_id).all()
            for cp in cp_list:
                tmp_cp_dict = {}
                tmp_cp_dict["cp_id"] = cp.id
                img = self.db.imgs.find_one({"id": cp.img_id})
                if not img:
                    tmp_cp_dict["img_url"] = ''
                    tmp_cp_dict["img_id"] = ''
                else:
                    tmp_cp_dict["img_url"] = img.url
                    tmp_cp_dict["img_id"] = img.id
                tmp_cp_dict["name"] = cp.name
                tmp_cp_dict["price"] = cp.price
                tmp_cp_dict["created_at"] = str(cp.created_at)[:-3]
                tmp_list.append(tmp_cp_dict)
            tmp_dict["cp"] = tmp_list
            res_list.append(tmp_dict)
        start = (page - 1) * pagesize
        end = page * pagesize
        total = len(res_list)
        results = res_list[start: end]
        self.render_json({"code": 200, "total": total, "res": results})
