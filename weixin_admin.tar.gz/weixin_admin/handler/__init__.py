# coding=utf-8

from __future__ import absolute_import, print_function

from tornado.ioloop import IOLoop


class PingPongMixin(object):
    @property
    def io_loop(self):
        if not hasattr(self, '_io_loop'):
            self._io_loop = IOLoop.current()
        return self._io_loop

    def start_ping(self):
        if hasattr(self, 'ping_timeout'):
            return
        self.ping_later()

    def ping_later(self):
        self.ping_timeout = self.io_loop.call_later(
                delay=self.get_ping_timeout(),
                callback=self._send_ping,
                )

    def stop_ping(self, clean=True):
        if hasattr(self, 'ping_timeout'):
            # clear timeout set by for ping pong (heartbeat) messages
            self.io_loop.remove_timeout(self.ping_timeout)
            if clean:
                del self.ping_timeout

    @staticmethod
    def get_ping_timeout():
        """
        Returns ping timeout for ping
        """
        return 10

    @staticmethod
    def get_pong_timeout():
        """
        Returns pong timeout for pong
        """
        return 60

    def on_pong(self, data):
        self.stop_ping(clean=False)
        self.ping_later()

    def _send_ping(self):
        """
        Send ping message to client.

        Creates a time out for pong message.
        If timeout is not cleared then closes the connection.
        """
        try:
            self.ping(b'a')
        except:
            self.stop_ping(clean=True)
            return
        self.ping_timeout = self.io_loop.call_later(
            delay=self.get_pong_timeout(),
            callback=self.on_pong_timeout,
        )

    def on_pong_timeout(self):
        pass
