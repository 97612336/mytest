drop table bill_schemes;
alter table parts_bill rename to bill_schemes;
alter table bill_schemes change category_id scheme_id int ;