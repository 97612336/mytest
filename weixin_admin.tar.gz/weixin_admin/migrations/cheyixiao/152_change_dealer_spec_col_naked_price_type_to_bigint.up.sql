alter table `cheyixiao`.`dealer_spec` modify `naked_price` bigint not null default 0 ;
