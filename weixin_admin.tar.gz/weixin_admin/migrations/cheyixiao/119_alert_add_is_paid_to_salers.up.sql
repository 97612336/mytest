ALTER TABLE `cheyixiao`.`salers` ADD COLUMN `is_pay` INT NULL DEFAULT NULL AFTER `created_at`;
ALTER TABLE `cheyixiao`.`salers` ADD COLUMN `reference` VARCHAR(128) NULL DEFAULT NULL AFTER `is_pay`;
