alter table look drop column is_test;
alter table dealers drop column is_test;
alter table salers drop column is_test;
alter table dealer_brand drop column is_test;
alter table user_status drop column is_test;