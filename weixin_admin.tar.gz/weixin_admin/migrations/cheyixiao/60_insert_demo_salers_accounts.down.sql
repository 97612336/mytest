delete from salers where username in ('cskj001', 'cskj002');
delete from devices where id in (18,19);
delete from dealers where id in (10012,10013);
delete from dealer_brand where dealer_id in (10012,10013);
delete from dealer_spec where dealer_id in (10012,10013);


