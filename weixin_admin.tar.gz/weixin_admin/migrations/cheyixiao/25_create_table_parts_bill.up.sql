create table if not exists parts_bill(
    id int not null primary key auto_increment,
    category_id int not null,
    bill_id int not null,
    created_at timestamp not null default current_timestamp,
    updated_at timestamp not null default current_timestamp on update current_timestamp,
    index `ix_join`(category_id, bill_id)
)engine=InnoDB default charset=utf8mb4;