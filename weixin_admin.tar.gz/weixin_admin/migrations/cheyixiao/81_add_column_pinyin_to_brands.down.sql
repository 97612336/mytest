ALTER TABLE `brands` DROP COLUMN `pinyin`;
