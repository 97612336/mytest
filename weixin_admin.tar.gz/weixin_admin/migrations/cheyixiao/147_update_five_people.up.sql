update cheyixiao.salers set is_pay=1 where username="zhangjinwei";
update cheyixiao.salers set is_pay=1 where username="liubei";
update cheyixiao.salers set is_pay=1 where username="zhongwen";
update cheyixiao.salers set is_pay=1 where username="songtao";
update cheyixiao.salers set is_pay=1 where username="zhudaoyuan";