
ALTER TABLE `bills` DROP COLUMN `cert_code`;
ALTER TABLE `bills` ADD COLUMN `order_status` INT(11) NULL DEFAULT 0 AFTER `total_cost`;