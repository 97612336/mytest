update dealer_spec set car_id=29447 where car_id=29443;
update car_scheme set car_id=29447 where car_id=29443;
update specs set id=29447 where id=29443;
update devices set dealer_id=10011 where id=17;
