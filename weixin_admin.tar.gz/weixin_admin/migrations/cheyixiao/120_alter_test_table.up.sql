alter table look add column is_test tinyint(1);
alter table dealers add column is_test tinyint(1);
alter table salers add column is_test tinyint(1);
alter table dealer_brand add column is_test tinyint(1);
alter table user_status add column is_test tinyint(1);

