update cheyixiao.series set brand_id=44 where brand_id=55 and id=93;
insert into cheyixiao.brands values
(44,1, '雷诺', 'https://cheyixiao.autoforce.net/static/brand/leinuo.png','leinuo');