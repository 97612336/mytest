alter table `cheyixiao`.`bill_loans` drop `status`;
alter table `cheyixiao`.`stock_loans` drop `status`;