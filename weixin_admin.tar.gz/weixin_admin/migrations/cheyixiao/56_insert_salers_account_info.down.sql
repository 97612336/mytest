alter table `salers` add column openid varchar(32);

delete from `salers` where username='chenhaoxing';

delete from devices where id=11;

delete from dealers where id=10006;

delete from dealer_brand where dealer_id=10006;

delete from dealer_spec where dealer_id=10006;

update `salers` set device_id=5 where id=4;

delete from dealer_brand where dealer_id=5000;
