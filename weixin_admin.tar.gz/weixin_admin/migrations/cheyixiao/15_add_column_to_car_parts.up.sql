alter table car_parts add column upline_at datetime null;
alter table car_parts add column downline_at datetime null;