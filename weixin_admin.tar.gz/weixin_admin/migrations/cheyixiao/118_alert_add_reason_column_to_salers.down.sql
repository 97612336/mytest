ALTER TABLE cheyixiao.salers DROP COLUMN `reason`;
