alter table `cheyixiao`.`bills` add `fetch_addr` varchar(64) default null;
