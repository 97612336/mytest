ALTER TABLE cheyixiao.salers DROP COLUMN `is_pay`;
ALTER TABLE cheyixiao.salers DROP COLUMN `reference`;
