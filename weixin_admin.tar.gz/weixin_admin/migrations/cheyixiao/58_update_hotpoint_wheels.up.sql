update car_wheels set logo='https://cheyixiao.autoforce.net/static/wheels/28327/wheel_01.png' where car_id=28327 and ename='Wheel_01';
update car_wheels set logo='https://cheyixiao.autoforce.net/static/wheels/28327/wheel_02.png' where car_id=28327 and ename='Wheel_02';

update hotpoints set ename='28327_2' where id=49;
update hotpoints set ename='28327_16' where id=50;
update hotpoints set ename='28327_12' where id=51;
update hotpoints set ename='28327_30' where id=52;
update hotpoints set ename='28327_25' where id=53;
update hotpoints set ename='28327_31' where id=54;
update hotpoints set ename='28327_9' where id=55;
update hotpoints set ename='28327_4' where id=56;