create table if not exists brands(
    id int not null primary key auto_increment,
    status int not null,
    logo varchar(255),
    name varchar(64)
)engine=InnoDB default charset=utf8mb4;