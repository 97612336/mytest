delete from salers where id<31;

delete from devices where id<6;

delete from dealers where id in (1000, 2000, 3000, 4000, 5000);