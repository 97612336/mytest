create table if not exists salers(
    id int not null primary key auto_increment,
    username varchar(32) not null unique,
    password varchar(32) not null,
    name varchar(32),
    phone bigint,
    openid varchar(32),
    device_id int,
    dealer_id int,
    perm int,
    avatar varchar(256),
    updated_at timestamp not null default current_timestamp,
    created_at timestamp not null default current_timestamp on update CURRENT_TIMESTAMP,
    index(username)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;