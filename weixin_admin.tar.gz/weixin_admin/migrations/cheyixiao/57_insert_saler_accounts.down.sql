delete from salers where username in ('zhaohailong','wangzhaopu', 'yipei');
delete from devices where id in (12,13,14);
delete from dealers where id in (10007,10008,10009);
delete from dealer_brand where dealer_id in (10007,10008,10009);
delete from dealer_spec where dealer_id in (10007,10008,10009);


