create table if not exists user_status(
    id int not null primary key auto_increment,
    status int not null default 1,
    saler_id int not null,
    user_id int not null,
    car_id int,
    created_at timestamp not null default current_timestamp,
    updated_at timestamp not null default current_timestamp on update current_timestamp,
    index `ix_saler_id`(saler_id)
)engine=InnoDB default charset=utf8mb4;