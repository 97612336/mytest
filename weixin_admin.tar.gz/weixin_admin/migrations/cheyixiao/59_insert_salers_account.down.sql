delete from salers where username in ('zhangsheng', 'yubin001');
delete from devices where id in (16, 17);
delete from  dealers where id in (10010, 10011);
delete from dealer_brand where dealer_id in (10010, 10011);