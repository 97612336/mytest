DELETE FROM `cheyixiao`.`dealer_spec` WHERE `dealer_id`=10012;
