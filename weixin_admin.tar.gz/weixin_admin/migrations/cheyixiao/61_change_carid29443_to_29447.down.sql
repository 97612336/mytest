update dealer_spec set car_id=29443 where car_id=29447;
update car_scheme set car_id=29443 where car_id=29447;
update specs set id=29443 where id=29447;
update devices set dealer_id=10007 where id=17;
