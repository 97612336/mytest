alter table cheyixiao.swiper drop `status`, drop `car_id`;
