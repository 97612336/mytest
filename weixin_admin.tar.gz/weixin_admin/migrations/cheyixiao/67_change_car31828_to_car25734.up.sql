update specs set id=25734,
name="雷克萨斯GS 2016款 300h 豪华版",
guide_price="59.90万"
 where id=31828;

update car_color set car_id=25734 where car_id=31828;
update car_wheels set car_id=25734 where car_id=31828;
update car_scheme set car_id=25734 where car_id=31828;
update dealer_spec set car_id=25734 where car_id=31828;
update focus_car set car_id=25734  where car_id=31828;
update hotpoints set car_id=25734 where car_id=31828;
update look set car_id=25734 where car_id=31828;
update user_status set car_id=25734 where car_id=31828;
update bills set car_id=25734 where car_id=31828;



