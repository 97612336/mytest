update cheyixiao.salers set city=110100 where city is null and cert_code = 2;
