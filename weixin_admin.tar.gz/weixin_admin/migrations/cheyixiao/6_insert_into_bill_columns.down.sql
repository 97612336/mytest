delete from bill_columns where id<17;
