alter table dealer_spec drop column naked_price,
drop column nums;
