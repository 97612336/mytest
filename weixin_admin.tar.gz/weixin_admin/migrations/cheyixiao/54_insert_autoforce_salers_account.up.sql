INSERT INTO `salers`(id, username, password, name,phone,openid,device_id,dealer_id,perm,avatar) VALUES(31,'haoshijie','798572579ffc27616acd58515da3b082','郝世杰',18519765457,NULL,6,10001,1,NULL),
(32,'yangchao','328d9c477e7cb915b7d568fd90d87d51','杨超',13426295476,NULL,7,10002,1,NULL),
(33,'zhaoyajing','edb0722f873f6d0b77693510b078f88f','杨雅静',18833001593  ,NULL,8,10003,1,NULL),
(34,'zhaochennan','b8675c7ede5f04563a8c52988e8ac50b','赵晨楠',13811353541,NULL,9,10004,1,NULL),
(35, 'weiwei', 'd6c3bd50a154938aecb956ab5d72f52a','卫伟', 18518186365, NULL, 10, 10005, 1, NULL);

update `salers` set phone=13701209627 where id=18;


insert into devices(id, name,dealer_id,expire_at) values(6, 'pad6',10001,'2019-01-01');
insert into devices(id, name,dealer_id,expire_at) values(7, 'pad7',10002,'2019-01-01');
insert into devices(id, name,dealer_id,expire_at) values(8, 'pad8',10003,'2019-01-01');
insert into devices(id, name,dealer_id,expire_at) values(9, 'pad9',10004,'2019-01-01');
insert into devices(id, name,dealer_id,expire_at) values(10, 'pad10',10005,'2019-01-01');


insert into dealers(id,name, company,address) values(10001,'北京车势科技1','北京车势科技有限公司','北京朝阳区东大桥尚都北塔A座1001');
insert into dealers(id,name, company,address) values(10002,'北京车势科技2','北京车势科技有限公司','北京朝阳区东大桥尚都北塔A座1001');
insert into dealers(id,name, company,address) values(10003,'北京车势科技3','北京车势科技有限公司','北京朝阳区东大桥尚都北塔A座1001');
insert into dealers(id,name, company,address) values(10004,'北京车势科技4','北京车势科技有限公司','北京朝阳区东大桥尚都北塔A座1001');
insert into dealers(id,name, company,address) values(10005,'北京车势科技5','北京车势科技有限公司','北京朝阳区东大桥尚都北塔A座1001');


insert into dealer_brand(dealer_id, brand_id, onsell) values(2000,20, 0),(2000,21, 0),(2000,6, 0),(2000,22,0),
(2000,27,0),(2000,11,0),(2000,18,0),(2000,31,0),(2000,29,0),(2000,24,0);

insert into dealer_brand(dealer_id, brand_id, onsell) values(10001,20, 0),(10001,21, 0),(10001,6, 0),(10001,22,0),
(10001,27,0),(10001,11,0),(10001,18,0),(10001,31,0),(10001,29,0),(10001,24,0);

insert into dealer_brand(dealer_id, brand_id, onsell) values(10002,20, 0),(10002,21, 0),(10002,6, 0),(10002,22,0),
(10002,27,0),(10002,11,0),(10002,18,0),(10002,31,0),(10002,29,0),(10002,24,0);

insert into dealer_brand(dealer_id, brand_id, onsell) values(10003,20, 0),(10003,21, 0),(10003,6, 0),(10003,22,0),
(10003,27,0),(10003,11,0),(10003,18,0),(10003,31,0),(10003,29,0),(10003,24,0);

insert into dealer_brand(dealer_id, brand_id, onsell) values(10004,20, 0),(10004,21, 0),(10004,6, 0),(10004,22,0),
(10004,27,0),(10004,11,0),(10004,18,0),(10004,31,0),(10004,29,0),(10004,24,0);

insert into dealer_brand(dealer_id, brand_id, onsell) values(10005,20, 0),(10005,21, 0),(10005,6, 0),(10005,22,0),
(10005,27,0),(10005,11,0),(10005,18,0),(10005,31,0),(10005,29,0),(10005,24,0);