alter table specs add naked_price float not null default 0,
add nums int(4) not null default 0,
add status int(1) not null default 1;
