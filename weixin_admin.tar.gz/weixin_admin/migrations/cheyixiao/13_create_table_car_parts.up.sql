create table if not exists car_parts(
    id int not null primary key auto_increment,
    category_id int not null,
    name varchar(32) not null,
    price float not null,
    img_id int,
    status int not null default 1,
    created_at timestamp not null default current_timestamp,
    updated_at timestamp not null default current_timestamp on update CURRENT_TIMESTAMP,
    index `idx_category_id`(category_id)
)engine=InnoDB default charset=utf8mb4;