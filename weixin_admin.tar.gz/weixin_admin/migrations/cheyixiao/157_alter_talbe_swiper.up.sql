alter table `cheyixiao`.`swiper` add `car_id` int default null after `url`,
add `status` tinyint not null default 1 after `img_url`;
