INSERT INTO `salers`(username, password, name,phone,device_id,dealer_id,perm,avatar)
VALUES('zhangsheng','48b737418b8f09b55808ba3aba2785f7','章胜',15236507780,16,10010,1,NULL);

insert into devices(id, name,dealer_id,expire_at) values(16, 'pad16',10010,'2020-01-01');

insert into dealers(id,name, company,address) values(10010,'车势科技安徽一区','北京车势科技有限公司','北京朝阳区东大桥尚都北塔A座1001');

insert into dealer_brand(dealer_id, brand_id, onsell) values(10010,20, 1),(10010,21, 1),(10010,6, 1),(10010,22,1),
(10010,27,1),(10010,11,1),(10010,18,1),(10010,31,1),(10010,29,1),(10010,24,1);


INSERT INTO `salers`(username, password, name,phone,device_id,dealer_id,perm,avatar)
VALUES('yubin001','fb65f4700be7094ede6ee1d967f0ae14','余斌',15236507780,17,10011,1,NULL);

insert into devices(id, name,dealer_id,expire_at) values(17, 'pad17',10007,'2020-01-01');

insert into dealers(id,name, company,address) values(10011,'车势科技安徽二区','北京车势科技有限公司','北京朝阳区东大桥尚都北塔A座1001');

insert into dealer_brand(dealer_id, brand_id, onsell) values(10011,20, 1),(10011,21, 1),(10011,6, 1),(10011,22,1),
(10011,27,1),(10011,11,1),(10011,18,1),(10011,31,1),(10011,29,1),(10011,24,1);