update brands set name="北京汽车",pinyin="beijingqiche"
where name="北京" and pinyin="beijing";