alter table user_status drop end_status;


