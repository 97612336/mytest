alter table car_scheme drop column dealer_id;
