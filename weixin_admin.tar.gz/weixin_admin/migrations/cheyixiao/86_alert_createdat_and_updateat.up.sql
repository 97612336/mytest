alter table salers modify created_at timestamp not null default current_timestamp;
alter table salers modify updated_at timestamp not null default current_timestamp on update current_timestamp;

alter table bills modify created_at timestamp not null default current_timestamp;
alter table bills modify updated_at timestamp not null default current_timestamp on update current_timestamp;

alter table dealers modify created_at timestamp not null default current_timestamp;
alter table dealers modify updated_at timestamp not null default current_timestamp on update current_timestamp;

alter table devices modify created_at timestamp not null default current_timestamp;
alter table devices modify updated_at timestamp not null default current_timestamp on update current_timestamp;

alter table look modify created_at timestamp not null default current_timestamp;
alter table look modify updated_at timestamp not null default current_timestamp on update current_timestamp;

alter table users modify created_at timestamp not null default current_timestamp;
alter table users modify updated_at timestamp not null default current_timestamp on update current_timestamp;

alter table wechat_bind modify created_at timestamp not null default current_timestamp;
alter table wechat_bind modify updated_at timestamp not null default current_timestamp on update current_timestamp;
