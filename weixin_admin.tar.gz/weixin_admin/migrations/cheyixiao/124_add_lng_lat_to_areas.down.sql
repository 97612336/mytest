ALTER TABLE cheyixiao.areas DROP COLUMN `lng`;
ALTER TABLE cheyixiao.areas DROP COLUMN `lat`;