create table if not exists car_wheels(
    id int not null primary key auto_increment,
    car_id int not null,
    ename varchar(16),
    `name` varchar(32),
    logo varchar(256),
    index `idx_car_id`(car_id),
    unique key `car_name` (car_id,name)
)engine=InnoDB default charset=utf8mb4;