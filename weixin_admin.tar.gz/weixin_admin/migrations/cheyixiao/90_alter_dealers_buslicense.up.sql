ALTER TABLE `dealers` CHANGE COLUMN `bus_licence` `bus_licence` VARCHAR(256) NULL DEFAULT NULL ;
