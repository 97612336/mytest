update car_color set car_id=28327 where car_id=28237;

update car_wheels set car_id=28327 where car_id=28237;

update hotpoints set car_id=28327 where car_id=28237;