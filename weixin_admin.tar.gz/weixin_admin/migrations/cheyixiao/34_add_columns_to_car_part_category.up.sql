alter table car_part_category add column upline_at datetime null,
add column downline_at datetime null,
add column status int not null default 1;
