update salers set role=2 where perm=2;
update salers set role=1 where perm=1;
update salers set role=3 where id=63;
update salers set role=3 where id=65;
