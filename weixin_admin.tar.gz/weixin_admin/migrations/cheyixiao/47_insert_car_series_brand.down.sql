delete from brands where id<33;

delete from series where id in (1,2,3,4,5,6,7,8,9,10,11,12,13,14,26,27);

delete from specs where id in (24967,28327,29447,30781,31215,31721,32004,32831,27900,28439,30059,30899,31704,31828,32522,1003213);