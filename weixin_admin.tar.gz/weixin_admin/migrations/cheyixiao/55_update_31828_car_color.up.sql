update car_color set color='rgb(0,47,130)' where car_id=31828 and ename='Color_03';
update car_color set color='rgb(50,62,89)' where car_id=31828 and ename='Color_06';