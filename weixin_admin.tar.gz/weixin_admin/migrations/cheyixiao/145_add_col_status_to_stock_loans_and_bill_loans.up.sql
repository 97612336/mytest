alter table `cheyixiao`.`bill_loans` add `status` tinyint default 0 after deposit;
alter table `cheyixiao`.`stock_loans` add `status` tinyint default 0 after deposit;