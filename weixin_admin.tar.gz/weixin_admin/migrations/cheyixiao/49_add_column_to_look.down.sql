alter table look drop column lon;

alter table look drop column lat;