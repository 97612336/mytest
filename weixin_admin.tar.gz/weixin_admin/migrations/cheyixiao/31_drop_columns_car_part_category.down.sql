alter table car_part_category add car_id int;
