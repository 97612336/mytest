CREATE TABLE cheyixiao.swiper (
  id INT NOT NULL AUTO_INCREMENT,
  title VARCHAR(128) NULL DEFAULT NULL,
  url VARCHAR(256) NULL DEFAULT NULL,
  img_name VARCHAR(128) NULL DEFAULT NULL,
  img_url VARCHAR(256) NULL DEFAULT NULL,
  updated_at timestamp not null default current_timestamp on update CURRENT_TIMESTAMP,
  created_at timestamp not null default current_timestamp,
  PRIMARY KEY (`id`)
  )ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
