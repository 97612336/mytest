create table if not exists car_scheme(
    id int not null primary key auto_increment,
    car_id int not null,
    status int not null default 1,
    created_at timestamp not null default current_timestamp,
    updated_at timestamp not null default current_timestamp on update CURRENT_TIMESTAMP
)engine=InnoDB default charset=utf8mb4;