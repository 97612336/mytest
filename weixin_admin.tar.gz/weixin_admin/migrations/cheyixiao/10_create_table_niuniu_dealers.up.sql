create table if not exists niuniu_dealers(
    id int not null primary key,
    company varchar(64),
    address varchar(128),
    phone varchar(32),
    phones varchar(125),
    main_brand varchar(32),
    area varchar(64),
    brand varchar(128),
    manager_mobile varchar(16),
    manager_name varchar(16)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;