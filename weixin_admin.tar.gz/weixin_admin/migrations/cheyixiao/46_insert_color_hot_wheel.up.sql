insert into car_color(car_id, ename, name, color) values(31721, 'Color_00', '极地白', 'rgb(230,230,230)'),
(31721, 'Color_01', '卡库金', 'rgb(200,160,40)'),
(31721, 'Color_02', '风暴蓝', 'rgb(43,31,113)'),
(31721, 'Color_03', '凯撒金', 'rgb(151,151,151)'),
(31721, 'Color_04', '太平洋蓝', 'rgb(0,130,220)'),
(31721, 'Color_05', '玛雅红', 'rgb(131,38,47)'),
(31721, 'Color_06', '塔希提金', 'rgb(209,194,179)'),
(31721, 'Color_07', '深黑', 'rgb(20,20,20)');
insert into car_wheels(car_id, name, ename, logo) values(31721, '17英寸运动轮毂', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/31721/wheel_01.png'), (31721, '16英寸轮毂', 'Wheel_02','https://cheyixiao.autoforce.net/static/wheels/31721/wheel_02.png'), (31721, '16英寸运动轮毂', 'Wheel_03','https://cheyixiao.autoforce.net/static/wheels/31721/wheel_03.png');
insert into hotpoints(car_id, name, ename) values(31721, '新“X”前脸造型', '31721_1'),(31721, '热成型钢板+正弦激光焊接工艺', '31721_12'),(31721, '高级全lED尾灯', '31721_16'),
(31721, '智能泊车辅助系统', '31721_17'),(31721, '全新EA211发动机', '31721_4'),(31721, '电子手刹+Autohold', '31721_22'),(31721, '恒温自动空调', '31721_20'),(31721, '全液晶仪表盘', '31721_23');


insert into car_color(car_id, ename, name, color) values(30781, 'Color_00', '流光紫', 'rgb(23,14,17)'),
(30781, 'Color_01', '繁星蓝', 'rgb(46,62,70)'),
(30781, 'Color_02', '霓虹', 'rgb(46,62,72)'),
(30781, 'Color_03', '炫动红', 'rgb(104,0,7)'),
(30781, 'Color_04', '月光白', 'rgb(215,219,214)'),
(30781, 'Color_05', '尊贵黑', 'rgb(6,7,10)');
insert into car_wheels(car_id, name, ename, logo) values(30781, '17寸铝合金轮毂', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/30781/wheel_01.png'), (30781, '16寸铝合金轮毂', 'Wheel_02','https://cheyixiao.autoforce.net/static/wheels/30781/wheel_02.png');
insert into hotpoints(car_id, name, ename) values(30781, '进气格栅', '30781_1'),(30781, 'LED大灯', '30781_2'),(30781, '轮毂', '30781_7'),
(30781, '全景天窗', '30781_11'),(30781, '10.25寸全液晶仪表盘', '30781_23'),(30781, '座椅', '30781_25'),(30781, '视网膜中控大屏', '30781_18'),(30781, 'ACC自适应巡航', '30781_19');

insert into car_color(car_id, ename, name, color) values(32004, 'Color_00', '凯撒金', 'rgb(147,112，93)'),
(32004, 'Color_01', '幻影黑', 'rgb(0,0,0)'),
(32004, 'Color_02', '雅士银', 'rgb(233,234,250)'),
(32004, 'Color_03', '橡木棕', 'rgb(134,125,124)'),
(32004, 'Color_04', '普鲁士灰', 'rgb(87,94,111)'),
(32004, 'Color_05', '极地白', 'rgb(255,255,255)'),
(32004, 'Color_06', '开罗金', 'rgb(158,126,109)'),
(32004, 'Color_07', '罗曼尼红', 'rgb(162,56,76)'),
(32004, 'Color_08', '流沙金', 'rgb(187,168,153)');
insert into car_wheels(car_id, name, ename, logo) values(32004, '18英寸轮毂', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/32004/wheel_01.png'),
(32004, '17英寸十辐', 'Wheel_02', 'https://cheyixiao.autoforce.net/static/wheels/32004/wheel_02.png'),
(32004, '17英寸5辐', 'Wheel_03', 'https://cheyixiao.autoforce.net/static/wheels/32004/wheel_03.png'),
(32004, '16英寸5辐', 'Wheel_04', 'https://cheyixiao.autoforce.net/static/wheels/32004/wheel_04.png'),
(32004, '17英寸运动', 'Wheel_05', 'https://cheyixiao.autoforce.net/static/wheels/32004/wheel_05.png');
insert into hotpoints(car_id, name, ename) values(32004, '全新前脸造型', '32004_1'),(32004, '凌犀全LED高级前大灯', '32004_2'),(32004, 'LED尾灯', '32004_16'),
(32004, 'FPK数字液晶仪表盘', '32004_23'),(32004, 'MIB High导航', '32004_18'),(32004, '尊贵内饰氛围灯', '32004_31'),(32004, '预碰撞保护系统', '32004_25'),(32004, '全车360度安全气囊保护', '32004_22');


insert into car_color(car_id, ename, name, color) values(30899, 'Color_00', '炫动红', 'rgb(162,14,35)'),
(30899, 'Color_01', '繁星蓝', 'rgb(40,97,127)'),
(30899, 'Color_02', '尊贵黑', 'rgb(21,21,21)'),
(30899, 'Color_03', '金缕棕', 'rgb(105,65,33)'),
(30899, 'Color_04', '月光白', 'rgb(231,232,230)');
insert into car_wheels(car_id, name, ename, logo) values(30899, '18寸双色', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/30899/wheel_01.png'), (30899, '17寸铝合金', 'Wheel_02', 'https://cheyixiao.autoforce.net/static/wheels/30899/wheel_02.png');
insert into hotpoints(car_id, name, ename) values(30899, '六边盾型前脸', '30899_1'),(30899, 'C型LED日间行车灯', '30899_3'),(30899, '全景天窗', '30899_11'),
(30899, '悬浮式中控', '30899_18'),(30899, '高强度钢架', '30899_12'),(30899, '爱信6AT变速箱', '30899_21'),(30899, '独立悬架底盘', '30899_13'),(30899, 'ACC自适应巡航', '30899_19');

insert into car_color(car_id, ename, name, color) values(29447, 'Color_00', '安第斯灰', 'rgb(50,51,53)'),
(29447, 'Color_01', '尊贵黑', 'rgb(1,0,14)'),
(29447, 'Color_02', '大地棕', 'rgb(69,42,25)'),
(29447, 'Color_03', '琥珀金黄', 'rgb(94,93,72)'),
(29447, 'Color_04', '霓虹', 'rgb(94,15,20)'),
(29447, 'Color_05', '月光白', 'rgb(239,239,239)');
insert into car_wheels(car_id, name, ename, logo) values(29447, '18寸铝合金', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/29447/wheel_01.png'), (29447, '17寸铝合金', 'Wheel_02', 'https://cheyixiao.autoforce.net/static/wheels/29447/wheel_02.png');
insert into hotpoints(car_id, name, ename) values(29447, '硬朗前格栅+流畅腰线设计', '29447_10'),(29447, '全景天窗', '29447_11'),(29447, '7英寸液晶仪表盘', '29447_23'),
(29447, '2700mm 轴距大尺寸空间', '29447_12'),(29447, '8英寸中控屏幕', '29447_18'),(29447, '360度全景影像系统', '29447_19'),(29447, '自动泊车辅助系统', '29447_17'),(29447, 'ACC自适应巡航', '29447_1');

insert into car_color(car_id, ename, name, color) values(31215, 'Color_00', '月光白', 'rgb(239,239,239)'),
(31215, 'Color_01', '金缕棕', 'rgb(66,53,45)'),
(31215, 'Color_02', '霓虹', 'rgb(94,15,20)'),
(31215, 'Color_03', '繁星蓝', 'rgb(63,96,115)'),
(31215, 'Color_04', '尊贵黑', 'rgb(2,0,14)'),
(31215, 'Color_05', '冰川银灰', 'rgb(105,105,105)');
insert into car_wheels(car_id, name, ename, logo) values(31215, '16寸炫动', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/31215/wheel_01.png'), (31215, '16寸镭射', 'Wheel_02', 'https://cheyixiao.autoforce.net/static/wheels/31215/wheel_02.png');
insert into hotpoints(car_id, name, ename) values(31215, '三幅镀铬前脸', '31215_1'),(31215, '鹰眼型大灯', '31215_2'),(31215, '超大可变储物空间', '31215_15'),
(31215, '星空全景天窗', '31215_11'),(31215, '智能车载互联系统', '31215_18'),(31215, '高强度车身安全舱', '31215_12'),(31215, '全软质内舱', '31215_30'),(31215, 'LCDA并线辅助系统', '31215_19');

insert into car_color(car_id, ename, name, color) values(28237, 'Color_00', '珍珠白', 'rgb(255,255,255)'),
(28237, 'Color_01', '烟墨灰', 'rgb(121,131,123)'),
(28237, 'Color_02', '香槟金', 'rgb(236,214,173)'),
(28237, 'Color_03', '紫檀红', 'rgb(111,79,80)');
insert into car_wheels(car_id, name, ename, logo) values(28237, '17寸豪华', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/28237/wheel_01.png'), (28237, '17寸优雅', 'Wheel_02', 'https://cheyixiao.autoforce.net/static/wheels/28237/wheel_02.png');
insert into hotpoints(car_id, name, ename) values(28237, '23颗高亮全LED大灯', '28237_2'),(28237, '57颗LED构成的尾灯', '28237_16'),(28237, '自动侧滑门', '28237_12'),
(28237, '精湛工艺内饰', '28237_30'),(28237, '长途舒适座椅', '28237_25'),(28237, '41处便利储物空间', '28237_31'),(28237, 'ACC自适应巡航系统', '28237_9'),(28237, '2.0T SIDI直喷涡轮增压发动机', '28237_4');



insert into car_color(car_id, ename, name, color) values(30059, 'Color_00', '雪域白', 'rgb(242,242,242)'),
(30059, 'Color_01', '西伯利亚银', 'rgb(186,185,184)'),
(30059, 'Color_02', '艾尔斯灰', 'rgb(142,142,142)'),
(30059, 'Color_03', '炫晶黑', 'rgb(14,14,14)'),
(30059, 'Color_04', '维多利亚紫', 'rgb(87,76,107)'),
(30059, 'Color_05', '施华洛蓝', 'rgb(30,84,164)'),
(30059, 'Color_06', '马尔斯红', 'rgb(199,19,13)');
insert into car_wheels(car_id, name, ename, logo) values(30059, '21寸磨光黑', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/30059/wheel_01.png'),
(30059, '21寸Y型', 'Wheel_02', 'https://cheyixiao.autoforce.net/static/wheels/30059/wheel_02.png'),
(30059, '20寸V型', 'Wheel_03', 'https://cheyixiao.autoforce.net/static/wheels/30059/wheel_03.png'),
(30059, '20寸U型', 'Wheel_04', 'https://cheyixiao.autoforce.net/static/wheels/30059/wheel_04.png');
insert into hotpoints(car_id, name, ename) values(30059, '劲致外形', '30059_10'),(30059, '智慧大灯', '30059_2'),(30059, '轮毂', '30059_7'),
(30059, '智能座椅', '30059_25'),(30059, '12.3寸全彩虚拟仪表盘', '30059_23'),(30059, 'Infinity高保真音响', '30059_27'),(30059, 'Climate Control空调系统', '30059_20'),(30059, '坚固车身', '30059_12');


insert into car_color(car_id, ename, name, color) values(31828, 'Color_00', '臻黑色', 'rgb(0,0,0)'),
(31828, 'Color_01', '晶亮白', 'rgb(238,243,245)'),
(31828, 'Color_02', '超音速石英白', 'rgb(249,245,235)'),
(31828, 'Color_03', '蓝焰色', 'rgb(0,53,133)'),
(31828, 'Color_04', '酒红云母', 'rgb(142,28,45)'),
(31828, 'Color_05', '超音速钛银', 'rgb(149,147,143)'),
(31828, 'Color_06', '宝石蓝', 'rgb(0,64,108)'),
(31828, 'Color_07', '超音速银', 'rgb(214,221,221)'),
(31828, 'Color_08', '琥珀色', 'rgb(59,12,12)');
insert into car_wheels(car_id, name, ename, logo) values(31828, 'R18豪华', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/31828/wheel_01.png'), (31828, 'R17领先', 'Wheel_02', 'https://cheyixiao.autoforce.net/static/wheels/31828/wheel_02.png');
insert into hotpoints(car_id, name, ename) values(31828, '纺锤形进气格栅', '25734_1'),(31828, '矩阵式LED灯组', '25734_2'),(31828, 'LED尾灯组合', '25734_16'),
(31828, 'F sport专属尾翼', '25734_15'),(31828, '12.3英寸中控屏', '25734_18'),(31828, '半苯胺高级真皮座椅', '25734_25'),(31828, '8速运动型变速箱', '25734_21'),(31828, '高强韧度车身', '25734_12');


insert into car_color(car_id, ename, name, color) values(31704, 'Color_00', '黑色', 'rgb(0,0,0)'),
(31704, 'Color_01', '恒星蓝', 'rgb(68,112,178)'),
(31704, 'Color_02', '幻影银', 'rgb(211,213,216)'),
(31704, 'Color_03', '珠光白', 'rgb(233,237,240)'),
(31704, 'Color_04', '珀钢灰', 'rgb(83,84,89)'),
(31704, 'Color_05', '水晶魄动红', 'rgb(179,18,41)');
insert into car_wheels(car_id, name, ename, logo) values(31704, ' R19 旗舰', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/31704/wheel_01.png'), (31704, 'R17 智享', 'Wheel_02', 'https://cheyixiao.autoforce.net/static/wheels/31704/wheel_02.png');


insert into car_color(car_id, ename, name, color) values(32522, 'Color_00', '晶黑', 'rgb(0,0,0)'),
(32522, 'Color_01', '皓白', 'rgb(255,250,255)'),
(32522, 'Color_02', '冰川银', 'rgb(170,177,187)'),
(32522, 'Color_03', '晶红珠光', 'rgb(175,47,44)'),
(32522, 'Color_04', '晶岩浅灰', 'rgb(171,171,171)'),
(32522, 'Color_05', '层云灰', 'rgb(73,73,73)'),
(32522, 'Color_06', '钛银', 'rgb(166,166,166)'),
(32522, 'Color_07', '烈焰橙', 'rgb(198,69,19)');
insert into car_wheels(car_id, name, ename, logo) values(32522, 'R17臻享', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/32522/wheel_01.png'),
 (32522, 'R17驭享', 'Wheel_02', 'https://cheyixiao.autoforce.net/static/wheels/32522/wheel_02.png'),
 (32522, 'R17高性能', 'Wheel_03', 'https://cheyixiao.autoforce.net/static/wheels/32522/wheel_03.png'),
 (32522, 'R17家享', 'Wheel_04', 'https://cheyixiao.autoforce.net/static/wheels/32522/wheel_04.png');


insert into car_color(car_id, ename, name, color) values(32831, 'Color_00', '战斗灰', 'rgb(73,86,93)');
insert into car_wheels(car_id, name, ename, logo) values(32831, 'R19 TS', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/32831/wheel_01.png');
insert into hotpoints(car_id, name, ename) values(32831, '菱形几何家族化设计', '32831_1'),(32831, '高强度合成钢材', '32831_12'),(32831, '全方位气囊', '32831_22'),
(32831, '全液晶仪表盘', '32831_23'),(32831, '豪华中控台', '32831_20'),(32831, '全时四驱系统', '32831_14'),(32831, '德系发动机', '32831_4'),(32831, '饱满尾部设计', '32831_15');



insert into car_color(car_id, ename, name, color) values(1003213, 'Color_00', '坦途黑', 'rgb(0,0,0)'),
(1003213, 'Color_01', '魅影灰', 'rgb(134,134,134)'),
(1003213, 'Color_02', '朱鹭白', 'rgb(249,245,245)')
;
insert into car_wheels(car_id, name, ename, logo) values(1003213, 'R15豪华', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/1003213/wheel_01.png'), (1003213, 'R15基本', 'Wheel_02', 'https://cheyixiao.autoforce.net/static/wheels/1003213/wheel_02.png');


insert into car_color(car_id, ename, name, color) values(24967, 'Color_00', '黑色', 'rgb(0,0,0)'),
(24967, 'Color_01', '大地棕', 'rgb(139,104,69)'),
(24967, 'Color_02', '朱鹭白', 'rgb(249,245,245)'),
(24967, 'Color_03', '中国蓝', 'rgb(23,113,209)'),
(24967, 'Color_04', '波尔多红', 'rgb(188，4，19)')
;
insert into car_wheels(car_id, name, ename, logo) values(24967, 'R15 尊贵', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/24967/wheel_01.png');


insert into car_color(car_id, ename, name, color) values(28439, 'Color_00', '黑色', 'rgb(0,0,0)'),
(28439, 'Color_01', '象牙白', 'rgb(245,243,245)'),
(28439, 'Color_02', '闪耀金', 'rgb(160,116,24)'),
(28439, 'Color_03', '勃艮第红', 'rgb(98,41,56)'),
(28439, 'Color_04', '香槟灰', 'rgb(181,162,123)'),
(28439, 'Color_05', '琥珀金', 'rgb(185,118,57)'),
(28439, 'Color_06', '摩卡棕', 'rgb(87,56,40)')
;
insert into car_wheels(car_id, name, ename, logo) values(28439, 'R18 运动', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/28439/wheel_01.png'), (28439, 'R17 时尚', 'Wheel_02', 'https://cheyixiao.autoforce.net/static/wheels/28439/wheel_02.png'), (28439, 'R17 舒适', 'Wheel_03', 'https://cheyixiao.autoforce.net/static/wheels/28439/wheel_03.png');
insert into hotpoints(car_id, name, ename) values(28439, '凌云翼家族形象', '28439_1'),(28439, 'LED日行灯', '28439_3'),
(28439, '悬浮360内饰', '28439_20'),(28439, '自由空间布局', '28439_31'),(28439, '豪华座椅', '28439_25'),(28439, '6气囊保护', '28439_22'),(28439, 'AES大灯随动转向系统', '28439_2');

insert into car_color(car_id, ename, name, color) values(27900, 'Color_00', '黑色', 'rgb(0,0,0)'),
(27900, 'Color_01', '珍珠白', 'rgb(238,243,245)'),
(27900, 'Color_02', '勃艮第红', 'rgb(98,41,56)'),
(27900, 'Color_03', '冰川蓝', 'rgb(84,141,199)'),
(27900, 'Color_04', '咖啡棕', 'rgb(91,45,28)')
;
insert into car_wheels(car_id, name, ename, logo) values(27900, 'R18 豪华', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/27900/wheel_01.png'), (27900, 'R19 至尊', 'Wheel_02', 'https://cheyixiao.autoforce.net/static/wheels/27900/wheel_02.png');
insert into hotpoints(car_id, name, ename) values(27900, '硬派镀铬前脸', '27900_1'),(27900, '矩阵式LED大灯', '27900_2'),(27900, '豪华内饰设计', '27900_25'),
(27900, '宽阔乘坐空间', '27900_31'),(27900, '多种组合扶手箱', '27900_29'),(27900, '车载互联系统', '27900_19'),(27900, '人性化娱乐空间', '27900_21'),(27900, '第二代320T发动机', '27900_4');


insert into car_color(car_id, ename, name, color) values
(25384, 'Color_00', '锐利银', 'rgb(90,90,90)'),
(25384, 'Color_01', '极地白', 'rgb(200,200,200)'),
(25384, 'Color_02', '风格红', 'rgb(200,0,0)'),
(25384, 'Color_03', '星耀黄', 'rgb(200,175,100)'),
(25384, 'Color_04', '流光绿', 'rgb(90,133,25)');
insert into car_wheels(car_id, name, ename, logo) values
(25384, '15寸豪华', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/25384/wheel_01.png'),
(25384, '14寸风尚', 'Wheel_02','https://cheyixiao.autoforce.net/static/wheels/25384/wheel_02.png');
insert into hotpoints(car_id, name, ename) values
(25384, '凌厉格栅', '25384_1'),
(25384, '劲酷车尾', '25384_10'),
(25384, '多点喷射发动机', '25384_4'),
(25384, '六速自动变速箱', '25384_21'),
(25384, '全方位六气囊', '25384_22'),
(25384, 'ESP电子稳定系统', '25384_14'),
(25384, '电动加热折叠后视镜', '25384_9'),
(25384, '弯道照明辅助系统', '25384_2');


insert into car_color(car_id, ename, name, color) values
(25717, 'Color_00', '典雅黑', 'rgb(0,0,0)'),
(25717, 'Color_01', '象牙白', 'rgb(246,246,246)'),
(25717, 'Color_02', '勃艮第红', 'rgb(98,41,56)'),
(25717, 'Color_03', '摩卡棕', 'rgb(88,56,38)'),
(25717, 'Color_04', '香槟金', 'rgb(181,162,121)'),
(25717, 'Color_05', '丝缎银', 'rgb(178,178,178)');
insert into car_wheels(car_id, name, ename, logo) values
(25717, 'R16 舒适', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/25717/wheel_01.png'),
(25717, 'R17 精英', 'Wheel_02','https://cheyixiao.autoforce.net/static/wheels/25717/wheel_02.png'),
(25717, 'R16 尊贵', 'Wheel_03','https://cheyixiao.autoforce.net/static/wheels/25717/wheel_03.png'),
(25717, 'R17 豪华', 'Wheel_04','https://cheyixiao.autoforce.net/static/wheels/25717/wheel_04.png');


insert into car_color(car_id, ename, name, color) values
(27284, 'Color_00', '闪光炫彩橙黄', 'rgb(202,96,56)'),
(27284, 'Color_01', '闪光深海蓝', 'rgb(0,122,171)'),
(27284, 'Color_02', '闪光宝石红', 'rgb(147,22,40)'),
(27284, 'Color_03', '雪域白', 'rgb(232,232,230)'),
(27284, 'Color_04', '闪光珠光黑', 'rgb(16,17,19)'),
(27284, 'Color_05', '闪光璀璨金黄', 'rgb(153,145,109)'),
(27284, 'Color_06', '闪光星河银', 'rgb(198,198,200)');
insert into car_wheels(car_id, name, ename, logo) values
(27284, '16寸双色铝合金轮毂', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/27284/wheel_01.png'),
(27284, '16寸单色铝合金轮毂', 'Wheel_02','https://cheyixiao.autoforce.net/static/wheels/27284/wheel_02.png');
insert into hotpoints(car_id, name, ename) values
(27284, '凌厉前格栅', '27284_1'),
(27284, '全景天窗', '27284_11'),
(27284, '39处灵动储物', '27284_15'),
(27284, 'inCall智能车载互联', '27284_19'),
(27284, '钢结构', '27284_12'),
(27284, '净爽花粉过滤器', '27284_28'),
(27284, '高效能发动机', '27284_4'),
(27284, '定速巡航系统', '27284_22');


insert into car_color(car_id, ename, name, color) values
(28248, 'Color_00', '天鹅绒棕', 'rgb(71,44,15)'),
(28248, 'Color_01', '冰岛银', 'rgb(181,177,179)'),
(28248, 'Color_02', '极光白', 'rgb(245,245,245)'),
(28248, 'Color_03', '峻岭棕', 'rgb(100,67,54)'),
(28248, 'Color_04', '玛瑙红', 'rgb(67,32,44)'),
(28248, 'Color_05', '天漠金', 'rgb(170,149,61)'),
(28248, 'Color_06', '玄武黑', 'rgb(0,0,0)'),
(28248, 'Color_07', '耀石灰', 'rgb(82,85,88)');
insert into car_wheels(car_id, name, ename, logo) values
(28248, '20寸抛光铝合金', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/28248/wheel_01.png'),
(28248, '18寸铝合金', 'Wheel_02','https://cheyixiao.autoforce.net/static/wheels/28248/wheel_02.png'),
(28248, '19寸精车铝合金', 'Wheel_03','https://cheyixiao.autoforce.net/static/wheels/28248/wheel_03.png');
insert into hotpoints(car_id, name, ename) values
(28248, '一体式蜂巢格栅', '28248_1'),
(28248, '双透镜LED大灯', '28248_2'),
(28248, '矩阵式LED尾灯', '28248_16'),
(28248, '尊享内饰空间', '28248_20'),
(28248, '丹拿12音响系统', '28248_27'),
(28248, '超大后备箱空间', '28248_15'),
(28248, '4motion智能四驱', '28248_14'),
(28248, 'DQ500 双离合变速器', '28248_21'),
(28248, '12.3英寸全数字液晶仪表', '28248_18');


insert into car_color(car_id, ename, name, color) values
(28493, 'Color_00', '大地棕', 'rgb(63,43,32)'),
(28493, 'Color_01', '帕米尔棕', 'rgb(60,40,38)'),
(28493, 'Color_02', '安第斯灰', 'rgb(88,91,98)'),
(28493, 'Color_03', '闪光霓虹', 'rgb(176,1,37)'),
(28493, 'Color_04', '闪光尊贵黑', 'rgb(0,0,0)'),
(28493, 'Color_05', '闪光月光白', 'rgb(255,255,255)');
insert into car_wheels(car_id, name, ename, logo) values
(28493, '19寸', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/28493/wheel_01.png'),
(28493, '18寸', 'Wheel_02','https://cheyixiao.autoforce.net/static/wheels/28493/wheel_02.png');
insert into hotpoints(car_id, name, ename) values
(28493, '蓝鲸2.0T GDI发动机', '28493_4'),
(28493, '前C型灯', '28493_3'),
(28493, 'LED大灯', '28493_2'),
(28493, '超越同级车身尺寸', '28493_31'),
(28493, '全景天窗', '28493_11'),
(28493, '舒适底盘', '28493_13'),
(28493, '博格华纳四驱系统', '28493_14'),
(28493, 'In call车载互联系统', '28493_19');


insert into car_color(car_id, ename, name, color) values
(30153, 'Color_00', '熔岩红', 'rgb(169,28,53)'),
(30153, 'Color_01', '琉璃橙', 'rgb(206,106,63)'),
(30153, 'Color_02', '湛海蓝', 'rgb(10,83,146)'),
(30153, 'Color_03', '碳晶黑', 'rgb(0,0,0)'),
(30153, 'Color_04', '棕榈绿', 'rgb(173,164,118)'),
(30153, 'Color_05', '冰峰白', 'rgb(255,255,255)');
insert into car_wheels(car_id, name, ename, logo) values
(30153, '19寸铝合金轮毂', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/30153/wheel_01.png'),
(30153, '18寸铝合金轮毂', 'Wheel_02','https://cheyixiao.autoforce.net/static/wheels/30153/wheel_02.png'),
(30153, '17寸铝合金轮毂', 'Wheel_03','https://cheyixiao.autoforce.net/static/wheels/30153/wheel_03.png');


insert into car_color(car_id, ename, name, color) values
(30667, 'Color_00', '冰川白', 'rgb(255,255,255)'),
(30667, 'Color_01', '斯科巴蓝', 'rgb(37,56,98)'),
(30667, 'Color_02', '探戈红', 'rgb(210,24,12)'),
(30667, 'Color_03', '哥特兰绿', 'rgb(42,67,54)'),
(30667, 'Color_04', '季风灰', 'rgb(108,109,111)');
insert into car_wheels(car_id, name, ename, logo) values
(30667, 'R18 双5辐', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/30667/wheel_01.png'),
(30667, 'R18 10辐', 'Wheel_02','https://cheyixiao.autoforce.net/static/wheels/30667/wheel_02.png'),
(30667, 'R18 单五辐', 'Wheel_03','https://cheyixiao.autoforce.net/static/wheels/30667/wheel_03.png'),
(30667, 'R18 豪华五辐', 'Wheel_04','https://cheyixiao.autoforce.net/static/wheels/30667/wheel_04.png');


insert into car_color(car_id, ename, name, color) values
(31487, 'Color_00', '黑色', 'rgb(0,0,0)'),
(31487, 'Color_01', '晶亮白', 'rgb(238,243,245)'),
(31487, 'Color_02', '超音速石英白', 'rgb(249,245,235)'),
(31487, 'Color_03', '晶亮流星蓝', 'rgb(0,101,173)'),
(31487, 'Color_04', '蓝焰色', 'rgb(0,53,133)'),
(31487, 'Color_05', '超音速钛银', 'rgb(149,147,143)'),
(31487, 'Color_06', '白金灰', 'rgb(204,211,213)'),
(31487, 'Color_07', '水银灰云母', 'rgb(73,80,90)'),
(31487, 'Color_08', '酒红云母', 'rgb(142,28,45)'),
(31487, 'Color_09', '琥珀色', 'rgb(59,12,12)'),
(31487, 'Color_10', '炙橙', 'rgb(236,108,0)');
insert into car_wheels(car_id, name, ename, logo) values
(31487, 'R18 运动', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/31487/wheel_01.png'),
(31487, 'R18 豪华', 'Wheel_02','https://cheyixiao.autoforce.net/static/wheels/31487/wheel_02.png'),
(31487, 'R18 锋致', 'Wheel_03','https://cheyixiao.autoforce.net/static/wheels/31487/wheel_03.png'),
(31487, 'R17 10辐', 'Wheel_04','https://cheyixiao.autoforce.net/static/wheels/31487/wheel_04.png');
insert into hotpoints(car_id, name, ename) values
(31487, '纺锤形前脸', '31487_1'),
(31487, '矩阵式LED前大灯', '31487_2'),
(31487, '非接触式电动行李箱', '31487_16'),
(31487, '开阔空间', '31487_31'),
(31487, 'Mark Levinson 高级音响系统', '31487_27'),
(31487, '多功能方向盘', '31487_22'),
(31487, '全混动科技', '31487_13'),
(31487, '盲点监测系统', '31487_9');


insert into car_color(car_id, ename, name, color) values
(31824, 'Color_00', '黑色', 'rgb(0,0,0)'),
(31824, 'Color_01', '铂金珍珠白', 'rgb(238,243,245)'),
(31824, 'Color_02', '琥珀棕', 'rgb(81,40,31)'),
(31824, 'Color_03', '欧泊银', 'rgb(109,109,109)'),
(31824, 'Color_04', '珊瑚红', 'rgb(146,25,30)'),
(31824, 'Color_05', '海钻蓝', 'rgb(21,75,145)');
insert into car_wheels(car_id, name, ename, logo) values
(31824, '18寸 Y型', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/31824/wheel_01.png'),
(31824, '16寸 V型', 'Wheel_02','https://cheyixiao.autoforce.net/static/wheels/31824/wheel_02.png'),
(31824, '17寸 10辐', 'Wheel_03','https://cheyixiao.autoforce.net/static/wheels/31824/wheel_03.png');


insert into car_color(car_id, ename, name, color) values
(31988, 'Color_00', '贻贝蓝', 'rgb(71,79,92)'),
(31988, 'Color_01', '玛瑙黑', 'rgb(0,0,0)'),
(31988, 'Color_02', '璀璨银', 'rgb(150,150,150)'),
(31988, 'Color_03', '水晶白', 'rgb(255,255,255)'),
(31988, 'Color_04', '耀目沙', 'rgb(184,168,133)'),
(31988, 'Color_05', '枫木棕', 'rgb(97,83,80)');
insert into car_wheels(car_id, name, ename, logo) values
(31988, '19寸10辐', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/31988/wheel_01.png'),
(31988, '18寸10辐', 'Wheel_02','https://cheyixiao.autoforce.net/static/wheels/31988/wheel_02.png'),
(31988, '18寸5辐', 'Wheel_03','https://cheyixiao.autoforce.net/static/wheels/31988/wheel_03.png'),
(31988, '17寸7辐', 'Wheel_04','https://cheyixiao.autoforce.net/static/wheels/31988/wheel_04.png');


insert into car_color(car_id, ename, name, color) values
(32459, 'Color_00', '波斯灰', 'rgb(176,176,176)'),
(32459, 'Color_01', '雅士银', 'rgb(211,213,229)'),
(32459, 'Color_02', '极地白', 'rgb(255,255,255)'),
(32459, 'Color_03', '凯旋金', 'rgb(136,105,87)'),
(32459, 'Color_04', '深黑', 'rgb(0,0,0)'),
(32459, 'Color_05', '唐古拉白', 'rgb(206,206,206)'),
(32459, 'Color_06', '提拉米苏', 'rgb(166,112,103)'),
(32459, 'Color_07', '孔雀蓝', 'rgb(4,4,233)'),
(32459, 'Color_08', '玛雅红', 'rgb(48,27,45)');
insert into car_wheels(car_id, name, ename, logo) values
(32459, 'R17 熠动', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/32459/wheel_01.png'),
(32459, 'R16 舒适', 'Wheel_02','https://cheyixiao.autoforce.net/static/wheels/32459/wheel_02.png'),
(32459, 'R17 R-line', 'Wheel_03','https://cheyixiao.autoforce.net/static/wheels/32459/wheel_03.png'),
(32459, 'R17 旗舰', 'Wheel_04','https://cheyixiao.autoforce.net/static/wheels/32459/wheel_04.png'),
(32459, 'R16 时尚', 'Wheel_05','https://cheyixiao.autoforce.net/static/wheels/32459/wheel_05.png');
insert into hotpoints(car_id, name, ename) values
(32459, '全新X型前脸', '32459_1'),
(32459, 'LED尾灯', '32459_16'),
(32459, '全新尾部设计', '32459_15'),
(32459, '炮筒形仪表盘', '32459_23'),
(32459, '8向电动调节座椅', '32459_25'),
(32459, '定速巡航功能', '32459_24'),
(32459, '多方位安全气囊', '32459_22'),
(32459, 'Start-stop发动机启停功能', '32459_4');


insert into car_color(car_id, ename, name, color) values
(33746, 'Color_00', '伯爵棕', 'rgb(126,99,84)'),
(33746, 'Color_01', '北极白', 'rgb(243,243,245)'),
(33746, 'Color_02', '烈焰红', 'rgb(254,15,15)'),
(33746, 'Color_03', '炫动蓝', 'rgb(65,150,255)'),
(33746, 'Color_04', '热力橙', 'rgb(254,107,0)');
insert into car_wheels(car_id, name, ename, logo) values
(33746, '17寸10辐', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/33746/wheel_01.png'),
(33746, '17寸5辐', 'Wheel_02','https://cheyixiao.autoforce.net/static/wheels/33746/wheel_02.png');
insert into hotpoints(car_id, name, ename) values
(33746, '六边形前格栅', '33746_1'),
(33746, '双色运动轮毂', '33746_7'),
(33746, '悬浮中控', '33746_18'),
(33746, '炮筒仪表盘', '33746_23'),
(33746, '爱信变速箱', '33746_21'),
(33746, '运动悬架', '33746_13'),
(33746, '加强3H结构车身', '33746_12'),
(33746, '双色车身设计', '33746_10');


insert into car_color(car_id, ename, name, color) values(32048, 'Color_00', '白鲸棕', 'rgb(72,40,7)'),
(32048, 'Color_01', '冰川白', 'rgb(246,246,246)'),
(32048, 'Color_02', '海南蓝', 'rgb(63,99,131)'),
(32048, 'Color_03', '季风灰', 'rgb(55,74,74)'),
(32048, 'Color_04', '魔力黑', 'rgb(0,0,0)'),
(32048, 'Color_05', '探戈红', 'rgb(137,3,10)')
;
insert into car_wheels(car_id, name, ename, logo) values(32048, '18英寸5支臂抛光', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/32048/wheel_01.png'), (32048, '17英寸10辐', 'Wheel_02','https://cheyixiao.autoforce.net/static/wheels/32048/wheel_02.png'), (32048, '17英寸5辐', 'Wheel_03','https://cheyixiao.autoforce.net/static/wheels/32048/wheel_03.png'), (32048, '18英寸Audi Sport', 'Wheel_04','https://cheyixiao.autoforce.net/static/wheels/32048/wheel_04.png');


insert into car_color(car_id, ename, name, color) values(29522, 'Color_00', '落霞红', 'rgb(200,0,0)'),
(29522, 'Color_01', '皓白', 'rgb(245,245,245)'),
(29522, 'Color_02', '烈焰橙', 'rgb(199,70,0)'),
(29522, 'Color_03', '激情黄', 'rgb(243,235,23)'),
(29522, 'Color_04', '层云灰', 'rgb(73,73,73)'),
(29522, 'Color_05', '青柠绿', 'rgb(91,171,5)'),
(29522, 'Color_06', '晶黑色金属漆', 'rgb(0,0,0)'),
(29522, 'Color_07', '佛洛依德紫', 'rgb(185,0,126)'),
(29522, 'Color_08', '深海蓝', 'rgb(0,32,79)'),
(29522, 'Color_09', '冰川银', 'rgb(199,199,199)'),
(29522, 'Color_10', '芒果橙', 'rgb(252,111,45)');
insert into car_wheels(car_id, name, ename, logo) values(29522, '18英寸铝合金轮毂', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/29522/wheel_01.png'),
(29522, '17英寸铝合金轮毂', 'Wheel_02','https://cheyixiao.autoforce.net/static/wheels/29522/wheel_02.png'),
(29522, '18英寸拉丝', 'Wheel_03','https://cheyixiao.autoforce.net/static/wheels/29522/wheel_03.png'),
(29522, '18英寸抛光', 'Wheel_04','https://cheyixiao.autoforce.net/static/wheels/29522/wheel_04.png');


insert into car_color(car_id, ename, name, color) values(32017, 'Color_00', '阿格斯棕', 'rgb(0,0,0)'),
(32017, 'Color_01', '朱鹭白', 'rgb(57,55,56)'),
(32017, 'Color_02', '白金色', 'rgb(247,246,246)'),
(32017, 'Color_03', '花剑银', 'rgb(183,171,146)'),
(32017, 'Color_04', '季风灰', 'rgb(210,210,210)'),
(32017, 'Color_05', '传奇黑', 'rgb(55,74,74)'),
(32017, 'Color_06', '探戈红', 'rgb(137,3,10)');
insert into car_wheels(car_id, name, ename, logo) values(32017, '18英寸对比灰半抛光5辐', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/32017/wheel_01.png'),
(32017, '17英寸5辐旋风造型', 'Wheel_02', 'https://cheyixiao.autoforce.net/static/wheels/32017/wheel_02.png'),
(32017, '17英寸10辐水晶形', 'Wheel_03', 'https://cheyixiao.autoforce.net/static/wheels/32017/wheel_03.png'),
(32017, '17英寸5辐Y形', 'Wheel_04', 'https://cheyixiao.autoforce.net/static/wheels/32017/wheel_04.png'),
(32017, '17英寸5辐对比灰局部抛光', 'Wheel_05', 'https://cheyixiao.autoforce.net/static/wheels/32017/wheel_05.png'),(32017, '18英寸10辐V形', 'Wheel_06', 'https://cheyixiao.autoforce.net/static/wheels/32017/wheel_06.png');


insert into car_color(car_id, ename, name, color) values(26934, 'Color_00', '朱鹭白', 'rgb(245,245,245)'),
(26934, 'Color_01', '琥珀金', 'rgb(197,180,104)');
insert into car_wheels(car_id, name, ename, logo) values(26934, '17英寸铝合金轮毂', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/26934/wheel_01.png');


insert into car_color(car_id, ename, name, color) values(32748, 'Color_00', '朱鹭白', 'rgb(245,245,245)'),
(32748, 'Color_01', '波多尔红', 'rgb(211,2,32)');
insert into car_wheels(car_id, name, ename, logo) values(32748, '17寸旋风式运动双色', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/32748/wheel_01.png');


insert into car_color(car_id, ename, name, color) values(30268, 'Color_00', '月光银', 'rgb(35,42,48)'),
(30268, 'Color_01', '雪山白', 'rgb(216,202,180)'),
(30268, 'Color_02', '矿石白', 'rgb(245,245,245)'),
(30268, 'Color_03', '开米士银', 'rgb(231,231,231)'),
(30268, 'Color_04', '碳黑', 'rgb(231,232,250)'),
(30268, 'Color_05', '宝石青', 'rgb(36,34,36)');
insert into car_wheels(car_id, name, ename, logo) values(30268, '18英寸634型', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/30268/wheel_01.png'),
 (30268, '18英寸632型', 'Wheel_02', 'https://cheyixiao.autoforce.net/static/wheels/30268/wheel_02.png'),
 (30268, '18英寸662M型', 'Wheel_03', 'https://cheyixiao.autoforce.net/static/wheels/30268/wheel_03.png'),
 (30268, '19英寸664M型', 'Wheel_04', 'https://cheyixiao.autoforce.net/static/wheels/30268/wheel_04.png');
insert into hotpoints(car_id, name, ename) values(30268, '家族设计前脸', '30268_1'),(30268, '复合材料车身', '30268_12'),(30268, 'B系列发动机', '30268_4'),
(30268, '先进的底盘技术', '30268_13'),(30268, '驾驶体验控制系统', '30268_21'),(30268, '云端互联技术', '30268_19'),(30268, '10.25英寸中控屏幕', '30268_18'),(30268, 'Bowers & Wilkins钻石环绕音响', '30268_27');


insert into car_color(car_id, ename, name, color) values(31154, 'Color_00', '雪山白', 'rgb(245,245,245)'),
(31154, 'Color_01', '地中海蓝', 'rgb(33,113,167)');
insert into car_wheels(car_id, name, ename, logo) values(31154, '18英寸豪华', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/31154/wheel_01.png'),
(31154, '18英寸运动', 'Wheel_02', 'https://cheyixiao.autoforce.net/static/wheels/31154/wheel_02.png');
insert into hotpoints(car_id, name, ename) values(31154, 'LED车灯设计', '31154_2'),(31154, '全景玻璃天窗', '31154_11'),(31154, '高雅氛围内饰', '31154_30'),
(31154, '宽敞内部空间', '31154_31'),(31154, 'Twinpower涡轮增加发动机', '31154_4'),(31154, '手自一体变速箱', '31154_21'),(31154, '智能紧急呼叫', '31154_6'),(31154, '实时路况信息', '31154_19');


insert into car_color(car_id, ename, name, color) values(30235, 'Color_00', '晶莹澈黑', 'rgb(0,0,0)'),
(30235, 'Color_01', '珍钻羽白', 'rgb(210,210,210)'),
(30235, 'Color_02', '锋励锐灰', 'rgb(32,32,32)'),
(30235, 'Color_03', '醇醉樱红', 'rgb(180,30,35)'),
(30235, 'Color_04', '黑曜石蓝', 'rgb(32,48,74)'),
(30235, 'Color_05', '深谷岩棕', 'rgb(68,52,37)');
insert into car_wheels(car_id, name, ename, logo) values(30235, ' R20享驭', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/30235/wheel_01.png'),
(30235, 'R20 基本', 'Wheel_02', 'https://cheyixiao.autoforce.net/static/wheels/30235/wheel_02.png');
insert into hotpoints(car_id, name, ename) values(30235, '矩阵式LED大灯', '30235_2'),(30235, 'R20超大轮圈', '30235_7'),(30235, '豪华座舱设计', '30235_25'),
(30235, '高保真音响', '30235_27'),(30235, '按键换挡设计', '30235_21'),(30235, '多媒体电视', '30235_18'),(30235, '超大后备箱', '30235_15');


insert into car_color(car_id, ename, name, color) values(31441, 'Color_00', '至臻黑', 'rgb(0,0,0)'),
(31441, 'Color_01', '晶亮白', 'rgb(238,243,245)'),
(31441, 'Color_02', '超音速石英白', 'rgb(238,238,238)'),
(31441, 'Color_03', '晶亮流星蓝', 'rgb(0,53,70)'),
(31441, 'Color_04', '蓝焰色', 'rgb(0,47,130)'),
(31441, 'Color_05', '超音速钛银', 'rgb(155,156,151)'),
(31441, 'Color_06', '白金灰', 'rgb(205,211,213)'),
(31441, 'Color_07', '水银灰云母', 'rgb(74,80,91)'),
(31441, 'Color_08', '酒红云母', 'rgb(142,28,45)'),
(31441, 'Color_09', '琥珀色', 'rgb(59,12,12)'),
(31441, 'Color_10', '炙橙', 'rgb(219,84,37)'),
(31441, 'Color_11','宝石蓝', 'rgb(50,62,89)');
insert into car_wheels(car_id, name, ename, logo) values(31441, 'R16 F sport', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/31441/wheel_01.png'),
 (31441, 'R16 精英', 'Wheel_02', 'https://cheyixiao.autoforce.net/static/wheels/31441/wheel_02.png');
insert into hotpoints(car_id, name, ename) values(31441, '纺锤形网状进气格栅', '31441_1'),(31441, 'LED前大灯', '31441_2'),(31441, 'L型后灯组', '31441_16'),
(31441, '旋转式信息操作系统', '31441_21'),(31441, '竹炭扬声器', '31441_27'),(31441, 'ECVT无级变速系统', '31441_20'),(31441, '能量控制单元系统', '31441_13'),(31441, '8个SRS气囊', '31441_22');


insert into car_color(car_id, ename, name, color) values(26331, 'Color_00', '幻影黑', 'rgb(0,0,0)'),
(26331, 'Color_01', '北极白', 'rgb(245,245,245)'),
(26331, 'Color_02', '烈焰红', 'rgb(131,26,41)'),
(26331, 'Color_03', '玛瑙红', 'rgb(178,40,53)'),
(26331, 'Color_04', '水晶银', 'rgb(190,190,192)');
insert into car_wheels(car_id, name, ename, logo) values(26331, 'R16 运动', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/26331/wheel_01.png'),
(26331, 'R16 豪华', 'Wheel_02', 'https://cheyixiao.autoforce.net/static/wheels/26331/wheel_02.png');
insert into hotpoints(car_id, name, ename) values(26331, '黑色车顶设计', '26331_11'),(26331, '一键启动系统', '26331_24'),(26331, '6速自动变速箱', '26331_21'),
(26331, '舒适座椅', '26331_25'),(26331, '1.4T黄金排量发动机', '26331_4'),(26331, '独立悬架', '26331_13'),(26331, '胎压监测系统', '26331_23'),(26331, '3H结构车身', '26331_12');


insert into car_color(car_id, ename, name, color) values(33412, 'Color_00', '埃斯托蓝', 'rgb(20,53,148)'),
(33412, 'Color_01', '雪山白', 'rgb(250,250,250)'),
(33412, 'Color_02', '墨尔本红', 'rgb(97,3,3)'),
(33412, 'Color_03', '地中海蓝', 'rgb(29,62,105)'),
(33412, 'Color_04', '矿石白', 'rgb(231,231,231)'),
(33412, 'Color_05', '曙光金', 'rgb(191,141,50)'),
(33412, 'Color_06', '开士米银', 'rgb(230,232,250)'),
(33412, 'Color_07', '铂金银', 'rgb(96,95,87)');
insert into car_wheels(car_id, name, ename, logo) values(33412, '18英寸484型', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/33412/wheel_01.png'),
(33412, '16英寸541型', 'Wheel_02', 'https://cheyixiao.autoforce.net/static/wheels/33412/wheel_02.png'),
(33412, '17英寸385型', 'Wheel_03', 'https://cheyixiao.autoforce.net/static/wheels/33412/wheel_03.png'),
(33412, '17英寸481型', 'Wheel_04', 'https://cheyixiao.autoforce.net/static/wheels/33412/wheel_04.png'),
(33412, '17英寸549型', 'Wheel_05', 'https://cheyixiao.autoforce.net/static/wheels/33412/wheel_05.png');
insert into hotpoints(car_id, name, ename) values(33412, 'LED车灯设计', '33412_2'),(33412, '家族式前脸', '33412_1'),(33412, '后视镜转向灯', '33412_8'),
(33412, '多功能方向盘', '33412_22'),(33412, '豪华内饰设计', '33412_30'),(33412, '灵活装载功能', '33412_31'),(33412, '8AT变速箱', '33412_21'),(33412, '驾驶辅助系统', '33412_18'),(33412, '紧急救援协助', '33412_6');


insert into car_color(car_id, ename, name, color) values(33371, 'Color_00', '阿布扎比棕', 'rgb(128,110,80)'),
(33371, 'Color_01', '喀纳斯白', 'rgb(245,245,245)'),
(33371, 'Color_02', '北极黑', 'rgb(5,5,5)'),
(33371, 'Color_03', '西西里灰', 'rgb(67,67,67)'),
(33371, 'Color_04', '波尔多红', 'rgb(166,0,0)'),
(33371, 'Color_05', '斐济蓝', 'rgb(35,120,187)');
insert into car_wheels(car_id, name, ename, logo) values(33371, '19寸summit', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/33371/wheel_01.png'),
(33371, '19寸overland', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/33371/wheel_02.png');
insert into hotpoints(car_id, name, ename) values(33371, '家族横贯前脸设计', '33371_1'),(33371, '2. 家族梯形轮眉', '33371_7'),(33371, '矩阵式LED大灯', '33371_2'),
(33371, '8.4英寸Uconnect智能交互系统', '33371_18'),(33371, '流媒体显示屏', '33371_6'),(33371, '全景天窗', '33371_11'),(33371, '自由组合空间', '33371_31'),(33371, 'ZF进口9速变速箱', '33371_21');



insert into car_color(car_id, ename, name, color) values
(32561, 'Color_00', '极地白', 'rgb(255,255,255)'),
(32561, 'Color_01', '水晶银', 'rgb(171,176,179)'),
(32561, 'Color_02', '开罗金', 'rgb(147,112,93)'),
(32561, 'Color_03', '波尔多红', 'rgb(152,21,55)'),
(32561, 'Color_04', '幻影黑', 'rgb(0,0,0)');
insert into car_wheels(car_id, name, ename, logo) values
(32561, '17英寸旗舰', 'Wheel_01','https://cheyixiao.autoforce.net/static/wheels/32561/wheel_01.png'), 
(32561, '17英寸尊贵', 'Wheel_02','https://cheyixiao.autoforce.net/static/wheels/32561/wheel_02.png');
insert into hotpoints(car_id, name, ename) values
(32561, '全新前脸造型', '32561_1'),
(32561, 'LED日间行车灯', '32561_3'),
(32561, '轿跑车身设计', '32561_12'),
(32561, '电动全景天窗', '32561_11'),
(32561, '无边框车门', '32561_10'),
(32561, '3.0 V6缸内直喷发动机', '32561_4'),
(32561, '全新内饰氛围灯（扶手下方）', '32561_30'),
(32561, '丹拿高级音响', '32561_27'),
(32561, 'DCC底盘控制系统', '32561_13');