ALTER TABLE `cheyixiao`.`specs` ADD COLUMN `real_price` VARCHAR(45) NULL DEFAULT NULL AFTER `guide_price`;
