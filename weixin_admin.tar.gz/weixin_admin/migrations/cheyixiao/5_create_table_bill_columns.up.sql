create table if not exists bill_columns(
    id int not null primary key auto_increment,
    name varchar(32),
    ename varchar(32)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;