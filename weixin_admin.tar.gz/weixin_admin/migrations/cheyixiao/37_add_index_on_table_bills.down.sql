alter table bills drop index `index_user_id`,
drop index `index_saler_id`;
