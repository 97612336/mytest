drop table bills;
