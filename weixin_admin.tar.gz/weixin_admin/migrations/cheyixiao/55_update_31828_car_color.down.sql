update car_color set color='rgb(0,53,133)' where car_id=31828 and ename='Color_03';
update car_color set color='rgb(0,64,108)' where car_id=31828 and ename='Color_06';