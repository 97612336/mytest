alter table specs drop column look_way;
