create table if not exists users(
    id int not null primary key auto_increment,
    openid varchar(32),
    nickname varchar(64),
    name varchar(32),
    phone bigint,
    pic varchar(256),
    utype int,
    note varchar(256),
    updated_at timestamp not null default current_timestamp,
    created_at timestamp not null default current_timestamp on update CURRENT_TIMESTAMP
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;