alter table bill_schemes change scheme_id category_id int;
alter table bill_schemes rename to parts_bill;
create table if not exists bill_schemes(
    id int not null primary key auto_increment,
    bill_id int not null,
    scheme_id int not null,
    created_at timestamp not null default current_timestamp,
    updated_at timestamp not null default current_timestamp on update current_timestamp,
    index `idx_bill_id`(bill_id)
)engine=InnoDB default charset=utf8mb4;
