alter table schemes modify name varchar(32) not null default "未命名",
modify price float not null default 0;
alter table scheme_options modify price float not null default 0,
modify name varchar(32) not null default "未命名";
alter table car_parts modify name varchar(32) not null default "未命名",
modify price float not null default 0;
alter table car_part_category modify name varchar(32) not null default "未命名",
modify price float not null default 0;