alter table bills drop column order_status;
alter table bills add column order_fee int;