

ALTER TABLE `salers` DROP COLUMN `role`;
ALTER TABLE `salers` DROP COLUMN `city`;
ALTER TABLE `salers` DROP COLUMN `address`;
ALTER TABLE `salers` DROP COLUMN `brands`;
ALTER TABLE `salers` DROP COLUMN `cert_code`;
ALTER TABLE `salers` DROP COLUMN `ID_face`;
ALTER TABLE `salers` DROP COLUMN `ID_con`;