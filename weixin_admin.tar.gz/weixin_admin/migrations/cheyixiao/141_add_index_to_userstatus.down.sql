ALTER TABLE `cheyixiao`.`user_status` DROP INDEX `ix_saler_id` ;
ALTER TABLE `cheyixiao`.`user_status` ADD INDEX `ix_saler_id` (`saler_id` ASC, `status` ASC);