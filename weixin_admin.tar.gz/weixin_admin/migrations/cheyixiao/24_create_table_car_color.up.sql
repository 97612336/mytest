create table if not exists car_color(
    id int not null primary key auto_increment,
    car_id int not null,
    ename varchar(16) not null,
    name varchar(32) not null,
    color varchar(20),
    index `ix_car_id`(car_id),
    unique key `car_ename` (car_id,ename)
)engine=InnoDB default charset=utf8mb4;