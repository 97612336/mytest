DELETE FROM user_status where id not in
(select id from (select min(id) as id from user_status group by user_id) as b);