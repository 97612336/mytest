alter table dealer_spec add naked_price float not null default 0,
add nums int(4) not null default 0;
