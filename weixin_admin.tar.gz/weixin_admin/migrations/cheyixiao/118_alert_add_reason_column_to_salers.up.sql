ALTER TABLE cheyixiao.salers ADD COLUMN `reason` varchar(128) NULL DEFAULT NULL AFTER `cert_code`;
