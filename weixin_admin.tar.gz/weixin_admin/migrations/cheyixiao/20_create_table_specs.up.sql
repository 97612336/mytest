create table if not exists specs(
    id int not null primary key,
    series_id int not null,
    logo varchar(255),
    name varchar(64),
    created_at timestamp not null default current_timestamp,
    updated_at timestamp not null default current_timestamp on update current_timestamp,
    index `ix_series_id`(series_id)
)engine=InnoDB default charset=utf8mb4;