delete from car_color where car_id in (23362,24224,27119,31422,32045,32713,32788,34031);
delete from car_wheels where car_id in (23362,24224,27119,31422,32045,32713,32788,34031);
delete from hotpoints where car_id in (23362,24224,27119,31422,32045,32713,32788,34031);
