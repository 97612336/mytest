alter table bills
drop dr_license,
drop invoice;


