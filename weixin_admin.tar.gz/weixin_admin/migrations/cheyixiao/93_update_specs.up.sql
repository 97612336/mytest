update specs set series_id = 2 where id=30899;
update specs set series_id = 3 where id=29447;
update specs set series_id = 1 where id=31215;

