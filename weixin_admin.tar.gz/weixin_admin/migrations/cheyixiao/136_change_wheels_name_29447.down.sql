update cheyixiao.car_wheels set name="18寸铝合金" where car_id=29447 and ename="Wheel_01";
update cheyixiao.car_wheels set name="17寸铝合金" where car_id=29447 and ename="Wheel_02";