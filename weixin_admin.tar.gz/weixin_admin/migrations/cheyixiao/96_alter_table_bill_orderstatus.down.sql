
ALTER TABLE `bills` DROP COLUMN `order_status`;
ALTER TABLE `bills` ADD COLUMN `cert_code` INT(11) NULL DEFAULT NULL AFTER `total_cost`;
