drop table bill_loans, stock_loans, stock_loans_cars;






