alter table salers add index `index_dealer_id`(`dealer_id`);
