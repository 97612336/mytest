alter table `salers` drop column openid;

INSERT INTO `salers`(username, password, name,phone,device_id,dealer_id,perm,avatar)
VALUES('chenhaoxing','7eeb22e9bd3d8a1f8915dc6885e4da82','陈昊星',15236507780,11,10006,1,NULL);

insert into devices(id, name,dealer_id,expire_at) values(11, 'pad11',10006,'2020-01-01');

insert into dealers(id,name, company,address) values(10006,'车易销','北京车势科技有限公司','北京朝阳区东大桥尚都北塔A座1001');

insert into dealer_brand(dealer_id, brand_id, onsell) values(10006,20, 1),(10006,21, 1),(10006,6, 1),(10006,22,1),
(10006,27,1),(10006,11,1),(10006,18,1),(10006,31,1),(10006,29,1),(10006,24,1);

insert into dealer_spec(dealer_id, car_id, status) values(10006,30781, 2),(10006,28327, 2),(10006,30059, 2),(10006,31828,2),
(10006,31704,2),(10006,32522,2),(10006,32831,2),(10006,1003213,2),(10006,24967,2),(10006,28439,2),
(10006,27900,2),(10006,31215,2),(10006,30899,2),(10006,29443,2),(10006,31721,2),(10006,32004,2);

update `salers` set device_id=2 where id=4;

insert into dealer_brand(dealer_id, brand_id, onsell) values(5000,20, 1),(5000,21, 1),(5000,6, 1),(5000,22,1),
(5000,27,1),(5000,11,1),(5000,18,1),(5000,31,1),(5000,29,1),(5000,24,1);
