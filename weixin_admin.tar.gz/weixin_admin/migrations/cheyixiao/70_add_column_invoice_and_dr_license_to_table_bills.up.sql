alter table bills
add dr_license varchar(128) default null after total_cost,
add invoice varchar(128) default null after total_cost;


