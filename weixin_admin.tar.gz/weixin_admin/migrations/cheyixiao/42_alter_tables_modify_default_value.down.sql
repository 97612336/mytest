alter table schemes modify name varchar(32) not null,
modify price float not null;
alter table scheme_options modify price float not null,
modify name varchar(32) not null;
alter table car_parts modify name varchar(32) not null,
modify price float not null;
alter table car_part_category modify name varchar(32) not null,
modify price float not null;