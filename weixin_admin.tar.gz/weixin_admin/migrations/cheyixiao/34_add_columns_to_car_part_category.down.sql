alter table car_part_category drop column upline_at,
drop column downline_at,
drop column status;