update car_color set color="rgb(41,72,114)" where car_id=33412 and ename="Color_00";
update car_color set color="rgb(140,45,56)" where car_id=33412 and ename="Color_02";
update car_color set color="rgb(30,71,134)" where car_id=33412 and ename="Color_03";
update car_color set color="rgb(191,141,50)" where car_id=33412 and ename="Color_05";
update car_color set color="rgb(124,134,155)" where car_id=33412 and ename="Color_06";
update car_color set color="rgb(99,103,103)" where car_id=33412 and ename="Color_07";
