alter table car_scheme add dealer_id int not null;
