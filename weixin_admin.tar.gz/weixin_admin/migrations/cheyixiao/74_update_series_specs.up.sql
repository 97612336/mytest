truncate series;
truncate specs;

insert into series(id,brand_id, name,logo,resource_url) values(1,20, "凌轩", 'https://cheyixiao.autoforce.net/static/series/lingxuan.png','https://cdn.autoforce.net/ixiao/'),
(2,20, 'cs55', 'https://cheyixiao.autoforce.net/static/series/cs55.png','https://cdn.autoforce.net/ixiao/'),
(3,20, 'cs75', 'https://cheyixiao.autoforce.net/static/series/cs75.png','https://cdn.autoforce.net/ixiao/'),
(4,21, '高尔夫', 'https://cheyixiao.autoforce.net/static/series/golf.png','https://cdn.autoforce.net/ixiao/'),
(5,21, '迈腾', 'https://cheyixiao.autoforce.net/static/series/maiteng.png','https://cdn.autoforce.net/ixiao/'),
(6, 20, '睿骋CC', 'https://cheyixiao.autoforce.net/static/series/rcCC.png','https://cdn.autoforce.net/ixiao/'),
(7, 6, '别克GL8', 'https://cheyixiao.autoforce.net/static/series/bkGL8.png','https://cdn.autoforce.net/ixiao/'),
(8, 22, 'WEY VV7', 'https://cheyixiao.autoforce.net/static/series/weyVV7.png','https://cdn.autoforce.net/ixiao/'),
(9, 27, '雷克萨斯GS', 'https://cheyixiao.autoforce.net/static/series/lkssGS.png','https://cdn.autoforce.net/ixiao/'),
(10, 11, '马自达CX5', 'https://cheyixiao.autoforce.net/static/series/mzdCX5.png','https://cdn.autoforce.net/ixiao/'),
(11, 18, '指南者', 'https://cheyixiao.autoforce.net/static/series/jeepZNZ.png','https://cdn.autoforce.net/ixiao/'),
(12, 31, '宝沃BX7 TS', 'https://cheyixiao.autoforce.net/static/series/bwBX7TS.png','https://cdn.autoforce.net/ixiao/'),
(13, 29, '北汽幻速H6', 'https://cheyixiao.autoforce.net/static/series/bqhsH6.png','https://cdn.autoforce.net/ixiao/'),
(14, 29, '北汽幻速H3F', 'https://cheyixiao.autoforce.net/static/series/bqhsH3F.png','https://cdn.autoforce.net/ixiao/'),
(26,24,"GS4","https://cheyixiao.autoforce.net/static/series/gqcqGS4.png","https://cdn.autoforce.net/ixiao/"),
(27,24,"GS8","https://cheyixiao.autoforce.net/static/series/gqcqGS8.png","https://cdn.autoforce.net/ixiao/");
insert into series(id,brand_id, name,logo,resource_url) values
(22,27,"NX","https://cheyixiao.autoforce.net/static/series/lkssNX.png","https://cdn.autoforce.net/ixiao/"),
(23,7,"凯美瑞","https://cheyixiao.autoforce.net/static/series/kaimeirui.png","https://cdn.autoforce.net/ixiao/"),
(24,32,"B50","https://cheyixiao.autoforce.net/static/series/bentengB50.png","https://cdn.autoforce.net/ixiao/"),
(25,32,"X40","https://cheyixiao.autoforce.net/static/series/bentengX40.png","https://cdn.autoforce.net/ixiao/"),
(28,24,"GA6","https://cheyixiao.autoforce.net/static/series/chuanqiGA6.png","https://cdn.autoforce.net/ixiao/"),
(29,27,"CT","https://cheyixiao.autoforce.net/static/series/lkssCT.png","https://cdn.autoforce.net/ixiao/"),
(30,30,"MDX","https://cheyixiao.autoforce.net/static/series/ogeMDX.png","https://cdn.autoforce.net/ixiao/"),
(42,27,"RX","https://cheyixiao.autoforce.net/static/series/42lkssRX.png","https://cdn.autoforce.net/ixiao/"),
(43,16,"科沃兹","https://cheyixiao.autoforce.net/static/series/43kwz.png","https://cdn.autoforce.net/ixiao/"),
(44,28,"XT5","https://cheyixiao.autoforce.net/static/series/44XT5.png","https://cdn.autoforce.net/ixiao/"),
(45,12,"艾瑞泽5","https://cheyixiao.autoforce.net/static/series/45arz5.png","https://cdn.autoforce.net/ixiao/"),
(46,6,"新君越","https://cheyixiao.autoforce.net/static/series/46xjy.png","https://cdn.autoforce.net/ixiao/")
;

insert into series(id,brand_id, name,logo,resource_url) values(15,21,"速腾","https://cheyixiao.autoforce.net/static/series/car_32459.png","https://cdn.autoforce.net/ixiao/"),
(16,21,"CC","https://cheyixiao.autoforce.net/static/series/car_32561.png","https://cdn.autoforce.net/ixiao/"),
(17,20,"CS15","https://cheyixiao.autoforce.net/static/series/car_27284.png","https://cdn.autoforce.net/ixiao/"),
(18,20,"CS95","https://cheyixiao.autoforce.net/static/series/car_28493.png","https://cdn.autoforce.net/ixiao/"),
(19,21,"POLO","https://cheyixiao.autoforce.net/static/series/car_25384.png","https://cdn.autoforce.net/ixiao/"),
(20,26,"S90","https://cheyixiao.autoforce.net/static/series/car_31988.png","https://cdn.autoforce.net/ixiao/"),
(47,21,"凌渡","https://cheyixiao.autoforce.net/static/series/car_32713.png","https://cdn.autoforce.net/ixiao/"),
(31,1,"A4L","https://cheyixiao.autoforce.net/static/series/car_32017.png","https://cdn.autoforce.net/ixiao/"),
(32,1,"A3","https://cheyixiao.autoforce.net/static/series/car_32048.png","https://cdn.autoforce.net/ixiao/"),
(48,1,"A3","https://cheyixiao.autoforce.net/static/series/car_32045.png","https://cdn.autoforce.net/ixiao/"),
(33,18,"自由侠","https://cheyixiao.autoforce.net/static/series/car_29522.png","https://cdn.autoforce.net/ixiao/"),
(34,18,"大指挥官","https://cheyixiao.autoforce.net/static/series/car_33371.png","https://cdn.autoforce.net/ixiao/"),
(35,12,"瑞虎7","https://cheyixiao.autoforce.net/static/series/car_30153.png","https://cdn.autoforce.net/ixiao/"),
(36,2,"1系","https://cheyixiao.autoforce.net/static/series/car_33412.png","https://cdn.autoforce.net/ixiao/"),
(37,2,"X1","https://cheyixiao.autoforce.net/static/series/car_31154.png","https://cdn.autoforce.net/ixiao/"),
(38,2,"5系","https://cheyixiao.autoforce.net/static/series/car_30268.png","https://cdn.autoforce.net/ixiao/"),
(39,21,"途昂","https://cheyixiao.autoforce.net/static/series/car_28248.png","https://cdn.autoforce.net/ixiao/"),
(49,27,"ES","https://cheyixiao.autoforce.net/static/series/car_23362.png","https://cdn.autoforce.net/ixiao/"),
(40,29,"S7","https://cheyixiao.autoforce.net/static/series/car_32748.png","https://cdn.autoforce.net/ixiao/"),
(41,29,"S3L","https://cheyixiao.autoforce.net/static/series/car_26934.png","https://cdn.autoforce.net/ixiao/");


insert into specs(id, series_id, name, logo,guide_price) values(30899,1,"长安CS55 2017款 1.5T 自动 炫耀型","https://cheyixiao.autoforce.net/static/series/cs55.png","13.29万"),
(29447,2,"长安CS75 2017款 尚酷版 1.8T 自动四驱尊贵型","https://cheyixiao.autoforce.net/static/series/cs75.png","14.88万"),
(31215,3,"凌轩 2017款 1.5T 手动乐活幸福型","https://cheyixiao.autoforce.net/static/series/lingxuan.png","8.19万"),
(30781,6,"睿骋CC 2018款 1.5T 自动尊雅型","https://cheyixiao.autoforce.net/static/series/rcCC.png","14.50万"),
(31721,4,"高尔夫 2018款 280TSI 自动旗舰型","https://cheyixiao.autoforce.net/static/series/golf.png","18.29万"),
(32004,5,"迈腾 2018款 380TSI DSG 旗舰型","https://cheyixiao.autoforce.net/static/series/maiteng.png","31.69万"),
(28327,7,"别克GL8 2017款 28T 豪华型","https://cheyixiao.autoforce.net/static/series/bkGL8.png","36.99万"),
(30059,8,"WEY VV7 2017款 VV7s 旗舰型","https://cheyixiao.autoforce.net/static/series/weyVV7.png","18.88万"),
(25734,9,"雷克萨斯GS 2016款 300h 豪华版","https://cheyixiao.autoforce.net/static/series/lkssGS.png","49.90万"),
(31704,10,"马自达CX-5 2017款 2.5L 自动四驱旗舰型","https://cheyixiao.autoforce.net/static/series/mzdCX5.png","24.58万"),
(32522,11,"指南者 2017款 200T 自动家享四驱版","https://cheyixiao.autoforce.net/static/series/jeepZNZ.png","19.58万"),
(32831,12,"宝沃BX7 2018款 2.0T TS 四驱旗舰型","https://cheyixiao.autoforce.net/static/series/bwBX7TS.png","30.28万"),
(1003213,13,"北汽幻速H6 2016款 1.8L 豪华型M18A","https://cheyixiao.autoforce.net/static/series/bqhsH6.png","7.53万~7.58万"),
(24967,14,"北汽幻速H3F 2016款 1.5L 尊贵型","https://cheyixiao.autoforce.net/static/series/bqhsH3F.png","6.78万"),
(28439,26,"传祺GS4 2017款 235T 自动四驱尊贵版","https://cheyixiao.autoforce.net/static/series/gqcqGS4.png","16.18万"),
(27900,27,"传祺GS8 2017款 320T 四驱至尊版","https://cheyixiao.autoforce.net/static/series/gqcqGS8.png","25.98万");

insert into specs(id, series_id, name, logo,guide_price) values
(31487,22,"雷克萨斯NX 2017款 300h 全驱 F SPORT","https://cheyixiao.autoforce.net/static/series/lkssNX.png","56.90万"),
(26331,24,"奔腾B50 2016款 1.4T 自动运动尊贵型","https://cheyixiao.autoforce.net/static/series/bentengB50.png","11.78万"),
(31441,29,"雷克萨斯CT 2017款 CT200h F SPORT 双色","https://cheyixiao.autoforce.net/static/series/lkssCT.png","30.10万"),
(31824,23,"凯美瑞 2018款 2.5HQ 旗舰版","https://cheyixiao.autoforce.net/static/series/kaimeirui.png","27.98万"),
(33746,25,"奔腾X40 2018款 网红版 1.6L 自动互联智酷型","https://cheyixiao.autoforce.net/static/series/bentengX40.png","8.98万"),
(30235,30,"讴歌MDX 2017款 3.0L 享驭版","https://cheyixiao.autoforce.net/static/series/ogeMDX.png","78.80万"),
(25717,28,"传祺GA6 2016款 235T 自动尊贵版","https://cheyixiao.autoforce.net/static/series/chuanqiGA6.png","16.38万"),
(24224,42,"雷克萨斯RX 2016款 200t 四驱F SPORT版","https://cheyixiao.autoforce.net/static/series/42lkssRX.png","53.80万"),
(34031,43,"科沃兹 2019款 325T 双离合欣悦版","https://cheyixiao.autoforce.net/static/series/43kwz.png","10.49万"),
(31422,44,"凯迪拉克XT5 2018款 28T 四驱豪华型","https://cheyixiao.autoforce.net/static/series/44XT5.png","41.99万"),
(27119,45,"艾瑞泽5 2017款 SPORT 1.5T CVT尊贵版","https://cheyixiao.autoforce.net/static/series/45arz5.png","9.79万"),
(32788,46,"君越 2018款 28T 豪华型","https://cheyixiao.autoforce.net/static/series/46xjy.png","28.98万");


insert into specs(id, series_id, name, logo,guide_price) values(32459,15,"速腾 2018款 280TSI DSG豪华型","https://cheyixiao.autoforce.net/static/series/car_32459.png","17.28万"),(32561,16,"一汽-大众CC 2018款 2.0TSI 豪华型","https://cheyixiao.autoforce.net/static/series/car_32561.png","28.38万"),(27284,17,"长安CS15 2016款 1.5L 自动豪华版","https://cheyixiao.autoforce.net/static/series/car_27284.png","7.79万"),(28493,18,"长安CS95 2017款 2.0T 四驱智尊版","https://cheyixiao.autoforce.net/static/series/car_28493.png","22.98万"),(25384,19,"POLO 2016款 1.6L 自动豪华型","https://cheyixiao.autoforce.net/static/series/car_25384.png","11.59万"),(31988,20,"沃尔沃S90 2018款 T5 智尊版","https://cheyixiao.autoforce.net/static/series/car_31988.png","55.18万"),(32713,47,"凌渡 2018款 330TSI DSG豪华版","https://cheyixiao.autoforce.net/static/series/car_32713.png","21.59万"),(32017,31,"奥迪A4L 2018款 30周年年型 40 TFSI 运动型","https://cheyixiao.autoforce.net/static/series/car_32017.png","36.98万"),(32048,32,"奥迪A3 2018款 30周年年型 Limousine 35 TFSI 风尚型","https://cheyixiao.autoforce.net/static/series/car_32048.png","24.15万"),(32045,48,"奥迪A3 2018款 30周年年型 Sportback 40 TFSI 运动型","https://cheyixiao.autoforce.net/static/series/car_32045.png","25.25万"),(29522,33,"自由侠 2017款  180TS 自动四驱全能敞篷版","https://cheyixiao.autoforce.net/static/series/car_29522.png","19.68万"),(33371,34,"大指挥官 2018款  2.0T 四驱御享版","https://cheyixiao.autoforce.net/static/series/car_33371.png","40.98万"),(30153,35,"瑞虎7 2017款 SPORT 1.5T 自动尊贵版","https://cheyixiao.autoforce.net/static/series/car_30153.png","15.09万"),(33412,36,"宝马1系 2018款 125i 运动型","https://cheyixiao.autoforce.net/static/series/car_33412.png","31.98万"),(31154,37,"宝马X1新能源 2018款 xDrive25Le 豪华型","https://cheyixiao.autoforce.net/static/series/car_31154.png","39.88万"),(30268,38,"宝马5系 2018款 540Li 行政版","https://cheyixiao.autoforce.net/static/series/car_30268.png","66.39万"),(28248,39,"途昂 2017款 530 V6 四驱至尊旗舰版","https://cheyixiao.autoforce.net/static/series/car_28248.png","51.89万"),(23362,49,"雷克萨斯ES 2015款 300h 豪华版","https://cheyixiao.autoforce.net/static/series/car_23362.png","42.80万"),(32748,40,"北汽幻速S7 2018款 1.5T 自动智尊型","https://cheyixiao.autoforce.net/static/series/car_32748.png","11.58万"),(26934,41,"北汽幻速S3L 2016款 1.5L 手动尊贵型","https://cheyixiao.autoforce.net/static/series/car_26934.png","6.98万");
