create table if not exists dealer_series(
    id int not null primary key auto_increment,
    dealer_id int not null,
    series_id int not null,
    created_at timestamp not null default current_timestamp,
    updated_at timestamp not null default current_timestamp on update current_timestamp,
    index `ix_dealer_id`(dealer_id)
)engine=InnoDB default charset=utf8mb4;