
INSERT INTO `salers`(id, username, password, name,phone,openid,device_id,dealer_id,perm,avatar) VALUES (1,'huangyu','3be8c3ea09923ea575bafcb43d94ec9f','黄玉3',0,NULL,1,1000,2,NULL),
(2,'guojiangqiao','fece5873101ef54c8a1f6194e788aa28','郭江桥',0,NULL,1,1000,1,NULL),
(3,'caolei','239d28ca09595832c69269506df38ba6','曹磊123456',0,NULL,4,3000,1,'https://cheyixiao.autoforce.net/static/users/152618123599D5D8F9-D237-4958-A0B9-7A274645CFEC.jpeg'),
(4,'lililiang','7b79b8bba9883c237194694c45c9efeb','梦启迪路付费',0,NULL,5,5000,1,'https://cheyixiao.autoforce.net/static/users/15260293730A196BDB-13AC-412C-9F12-B411CE3E18E3.jpeg'),
(5,'zhh@autoforce.net','19ac4911b8c522f150723b439215de29','翟会会',NULL,NULL,1,5000,2,NULL),
(6,'shiboxin','5823adef22d861b7fde194e87f05dfa1','史博心1',0,NULL,1,1000,2,NULL),
(7,'yangting','d755ea877c421c6f7010cf175d21cb70','杨婷',18500000001,NULL,1,1000,1,'https://cheyixiao.autoforce.net/static/users/1526121230image.jpg'),
(8,'duzhen','bc1169ac175ee34a6bca9af07804b40d','杜帧',NULL,NULL,1,1000,2,NULL),
(9,'autoforce','a12fc41bd3a55283121d1a929d4455f2','111xupeng123',123456666,NULL,1,1000,1,'https://cheyixiao.autoforce.net/static/avatar/15252478181-1F92Q14941.jpg'),
(10,'fengxiaomao','af24da033f12a73bb2138b81366b74ef','冯小猫',NULL,NULL,1,1000,2,NULL),
(11,'lililiang1','87192aaf7e5645568004ed296a1f192f','力量22222',0,NULL,1,1000,1,NULL),
(12,'lililiang2','a5e5ed32670dc3cf0e4499c02873ef6e','力量2',18700000000,NULL,1,1000,2,NULL),
(13,'lililiang3','7b79b8bba9883c237194694c45c9efeb','力量3',15130078689,NULL,1,1000,2,'https://cheyixiao.autoforce.net/static/avatar/152576561629AA1381-05C1-4242-9177-327D638007F4.jpeg'),
(14,'lililiang4','c518aeaafa2e428e06cb1f5609883e58','力量4',15130078689,NULL,1,1000,2,'https://cheyixiao.autoforce.net/static/users/152602264814529703-122C-43BA-8754-0BCC9251DA9E.jpeg'),
(15,'dongqq','417ed9b535b703ba024021fd9232dd46','董倩',NULL,NULL,1,1000,1,NULL),
(16,'wangdong','5adde99b7ebc205ce34677333ea989e2','王东',NULL,NULL,1,1000,1,'https://cheyixiao.autoforce.net/static/avatar/15257741732edce626c1b8cb30bf24d3a7023562dd.jpg'),
(17,'cheshi777','49909b4c62da19a8d732798030e96a51','测试6734',1513036789,NULL,2,5000,1,'https://cheyixiao.autoforce.net/static/users/1526039850image.jpg'),
(18,'wangzhaoyang','1a58d8e580065b5e7b413451a3a28151','汪兆阳',NULL,NULL,3,2000,1,NULL),
(19,'zhaohuixin','b345d0fc8c16bcc3c6a11d5689690b0e','赵慧鑫',18513119258,NULL,1,1000,1,NULL),
(20,'wujingwei','b82cd7b00b1bf8311ef15dbbfd03a817','武警卫',NULL,NULL,1,1000,2,NULL),
(21,'zhangyi','5823adef22d861b7fde194e87f05dfa1','zhangyi',0,NULL,4,3000,2,NULL),
(22,'ceshi1','5823adef22d861b7fde194e87f05dfa1','测试1',18501010101,NULL,1,1000,2,NULL),
(23,'lufei007','a7f170dbd203c56dece4b2cb5229a6e4','Jj',15130078689,NULL,2,5000,2,'https://cheyixiao.autoforce.net/static/users/1526204073657CA9FE-9C1F-4423-B9D5-32F4D1ED84AB.jpeg'),
(24,'lufei001','5823adef22d861b7fde194e87f05dfa1','Uii',0,NULL,2,5000,2,NULL),
(25,'lufei002','5823adef22d861b7fde194e87f05dfa1','Fff',0,NULL,2,5000,2,NULL),
(26,'lufei003','5823adef22d861b7fde194e87f05dfa1','Hji',0,NULL,2,5000,2,NULL),
(27,'lufei004','5823adef22d861b7fde194e87f05dfa1','Jfjf',0,NULL,2,5000,2,NULL),
(28,'lufei005','5823adef22d861b7fde194e87f05dfa1','Jcj',0,NULL,2,5000,2,NULL),
(29,'lufei006','5823adef22d861b7fde194e87f05dfa1','Kdkd',0,NULL,2,5000,2,NULL),
(30,'lufei100','5823adef22d861b7fde194e87f05dfa1','Jjh',0,NULL,4,3000,2,NULL);


insert into devices(id, name,dealer_id,expire_at) values(1, 'pad1',1000,'2019-01-01');
insert into devices(id, name,dealer_id,expire_at) values(3, 'pad3',2000,'2019-01-01');
insert into devices(id, name,dealer_id,expire_at) values(4, 'pad4',3000,'2019-01-01');
insert into devices(id, name,dealer_id,expire_at) values(5, 'pad5',4000,'2019-01-01');
insert into devices(id, name,dealer_id,expire_at) values(2, 'pad2',5000,'2019-01-01');

insert into dealers(id,name, company,address) values(1000,'车势科技','长安cs15车势4s店','北京朝阳区东大桥尚都北塔');
insert into dealers(id,name, company,address) values(2000,'北京车势科技','车势4s店','北京朝阳区东大桥尚都北塔');
insert into dealers(id,name, company,address) values(3000,'车势科技3','北京车势科技有限公司','北京朝阳区东大桥尚都北塔');
insert into dealers(id,name, company,address) values(4000,'车势科技1','北京车势科技有限公司1','北京朝阳区东大桥尚都北塔A座');
insert into dealers(id,name, company,address) values(5000,'车势科技2','北京车势科技有限公司2','北京朝阳区东大桥尚都北塔A座1001');