CREATE TABLE cheyixiao.quote (
    id INT NOT NULL primary key auto_increment,
    find_id INT NULL DEFAULT NULL,
    saler_id INT NULL DEFAULT NULL,
    location INT NULL DEFAULT NULL,
    quote VARCHAR(45) NULL DEFAULT NULL,
    end_time datetime NULL DEFAULT NULL,
    remark VARCHAR(256) NULL DEFAULT NULL,
    updated_at timestamp not null default current_timestamp on update CURRENT_TIMESTAMP,
    created_at timestamp not null default current_timestamp,
    index(find_id,saler_id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
