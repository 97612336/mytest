create table if not exists devices(
    id int not null primary key auto_increment,
    name varchar(32),
    dealer_id int,
    expire_at datetime,
    updated_at timestamp not null default current_timestamp,
    created_at timestamp not null default current_timestamp on update CURRENT_TIMESTAMP
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;