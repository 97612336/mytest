alter table `cheyixiao`.`specs` drop `is_hot`;
