CREATE TABLE `cheyixiao`.`activity_score` (
  id INT NOT NULL primary key auto_increment,
  saler_id INT NULL DEFAULT NULL,
  join_time TIMESTAMP NULL DEFAULT NULL,
  score INT(11) NULL DEFAULT 0,
   updated_at timestamp not null default current_timestamp on update CURRENT_TIMESTAMP,
  created_at timestamp not null default current_timestamp,
  index(saler_id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
