update cheyixiao.series set brand_id=1 where name like "%朗行%";
delete from cheyixiao.series where id=32;
delete from cheyixiao.specs where series_id=32;