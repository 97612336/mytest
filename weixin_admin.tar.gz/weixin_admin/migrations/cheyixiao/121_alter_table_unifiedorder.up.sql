alter table unifiedorder add column pay_type int default 0;
alter table unifiedorder modify bill_id int null;