alter table cheyixiao.quote add info_origin tinyint not null default 0 after remark;
