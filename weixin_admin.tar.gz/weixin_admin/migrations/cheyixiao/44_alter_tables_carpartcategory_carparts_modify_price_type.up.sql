alter table car_part_category modify price int;
alter table car_parts modify price int;