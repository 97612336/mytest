ALTER TABLE cheyixiao.stock_loans ADD COLUMN `saler_id` INT NULL DEFAULT NULL AFTER `id`;
ALTER TABLE cheyixiao.bill_loans ADD COLUMN `saler_id` INT NULL DEFAULT NULL AFTER `id`;