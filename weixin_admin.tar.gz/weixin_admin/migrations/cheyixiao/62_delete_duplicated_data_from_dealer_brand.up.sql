DELETE FROM dealer_brand where dealer_id = 1000 and id not in
(select id from (select min(id) as id from dealer_brand where
dealer_id=1000 group by brand_id) as b)  ;