update car_color set color="rgb(20,53,148)" where car_id=33412 and ename="Color_00";
update car_color set color="rgb(97,3,3)" where car_id=33412 and ename="Color_02";
update car_color set color="rgb(29,62,105)" where car_id=33412 and ename="Color_03";
update car_color set color="rgb(191,141,50)" where car_id=33412 and ename="Color_05";
update car_color set color="rgb(230,232,250)" where car_id=33412 and ename="Color_06";
update car_color set color="rgb(96,95,87)" where car_id=33412 and ename="Color_07";
