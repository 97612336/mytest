update car_color set color="rgb(135,37,51)" where car_id=29522 and ename="Color_00";
update car_color set color="rgb(187,107,37)" where car_id=29522 and ename="Color_02";
update car_color set color="rgb(191,164,48)" where car_id=29522 and ename="Color_03";
update car_color set color="rgb(113,123,140)" where car_id=29522 and ename="Color_04";
update car_color set color="rgb(107,159,66)" where car_id=29522 and ename="Color_05";
update car_color set color="rgb(166,57,104)" where car_id=29522 and ename="Color_07";
update car_color set color="rgb(50,94,175)" where car_id=29522 and ename="Color_08";
update car_color set color="rgb(220,123,73)" where car_id=29522 and ename="Color_10";

update car_color set color="rgb(106,97,101)" where car_id=32048 and ename="Color_00";
update car_color set color="rgb(76,116,170)" where car_id=32048 and ename="Color_02";
update car_color set color="rgb(190,92,98)" where car_id=32048 and ename="Color_05";

update car_color set color="rgb(170,175,186)" where car_id=30268 and ename="Color_00";
update car_color set color="rgb(250,250,250)" where car_id=30268 and ename="Color_01";
update car_color set color="rgb(231,231,231)" where car_id=30268 and ename="Color_02";
update car_color set color="rgb(230,232,250)" where car_id=30268 and ename="Color_03";
update car_color set color="rgb(36,42,84)" where car_id=30268 and ename="Color_04";
update car_color set color="rgb(54,74,100)" where car_id=30268 and ename="Color_05";

update car_color set color="rgb(67,61,60)" where car_id=33371 and ename="Color_00";
update car_color set color="rgb(115,125,116)" where car_id=33371 and ename="Color_03";
update car_color set color="rgb(104,37,36)" where car_id=33371 and ename="Color_04";
update car_color set color="rgb(81,100,134)" where car_id=33371 and ename="Color_05";

update car_color set color="rgb(167,127,109)" where car_id=32713 and ename="Color_01";
update car_color set color="rgb(171,159,141)" where car_id=32713 and ename="Color_02";
update car_color set color="rgb(27,95,148)" where car_id=32713 and ename="Color_03";
update car_color set color="rgb(225,35,58)" where car_id=32713 and ename="Color_04";
