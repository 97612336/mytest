alter table salers drop index `index_dealer_id`;
