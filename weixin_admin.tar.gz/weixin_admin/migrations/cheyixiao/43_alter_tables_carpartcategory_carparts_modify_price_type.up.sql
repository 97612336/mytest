alter table car_part_category modify price decimal(9,2);
alter table car_parts modify price decimal(9,2);