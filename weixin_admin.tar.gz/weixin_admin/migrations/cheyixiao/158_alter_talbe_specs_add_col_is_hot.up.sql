alter table `cheyixiao`.`specs` add `is_hot` tinyint default 0 after `name`;
