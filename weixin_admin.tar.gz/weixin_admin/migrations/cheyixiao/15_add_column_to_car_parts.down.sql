alter table car_parts drop column upline_at;
alter table car_parts drop column downline_at;