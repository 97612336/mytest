create table if not exists series(
    id int not null primary key auto_increment,
    brand_id int not null,
    logo varchar(255),
    name varchar(64),
    resource_url varchar(256),
    index `ix_brand_id`(brand_id)
)engine=InnoDB default charset=utf8mb4;