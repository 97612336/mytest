update car_color set car_id=28237 where car_id=28327;

update car_wheels set car_id=28237 where car_id=28327;

update hotpoints set car_id=28237 where car_id=28327;
