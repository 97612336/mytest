delete from cheyixiao.specs where id in(25893,33445,28723,31790,32776,33393,31001,31628,
32257,33229,32223,32102,33341,34200,30204,34353,30199);

delete from cheyixiao.dealer_spec where car_id in(25893,33445,28723,31790,32776,33393,31001,31628,
32257,33229,32223,32102,33341,34200,30204,34353,30199);

delete from cheyixiao.series where id between 168 and 184;

insert into specs(id, series_id, name, logo,guide_price, look_way) values
(32223,57,"阿特兹 2018款 2.5L 蓝天至尊版","https://cheyixiao.autoforce.net/static/series/car_32223.png","23.78万",2),
(31628,63,"宝骏310 2017款 1.5L 自动豪华型","https://cheyixiao.autoforce.net/static/series/car_31628.png","6.08万",2),
(32257,65,"宝骏530 2018款 1.5T DCT旗舰型","https://cheyixiao.autoforce.net/static/series/car_32257.png","11.58万",2);
