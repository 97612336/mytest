alter table car_part_category modify price float;
alter table car_parts modify price float;