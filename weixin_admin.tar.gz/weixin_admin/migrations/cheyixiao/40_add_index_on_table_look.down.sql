alter table look drop index `index_saler_id`;
