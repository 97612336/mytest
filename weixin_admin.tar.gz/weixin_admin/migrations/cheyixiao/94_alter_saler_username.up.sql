alter table salers modify username varchar(32)  binary not null;
