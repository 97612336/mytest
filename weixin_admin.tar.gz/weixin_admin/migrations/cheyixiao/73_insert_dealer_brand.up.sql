insert into dealer_brand(dealer_id, brand_id) values(1000,7),(1000,12),(1000,16),(1000,28),(1000,30),(1000,32);

insert into dealer_brand(dealer_id, brand_id) values(2000,7),(2000,12),(2000,16),(2000,28),(2000,30),(2000,32);

insert into dealer_brand(dealer_id, brand_id) values(3000,7),(3000,12),(3000,16),(3000,28),(3000,30),(3000,32);

insert into dealer_brand(dealer_id, brand_id) values(4000,7),(4000,12),(4000,16),(4000,28),(4000,30),(4000,32);

insert into dealer_brand(dealer_id, brand_id) values(5000,7),(5000,12),(5000,16),(5000,28),(5000,30),(5000,32);

insert into dealer_brand(dealer_id, brand_id) values(10001,7),(10001,12),(10001,16),(10001,28),(10001,30),(10001,32);

insert into dealer_brand(dealer_id, brand_id) values(10002,7),(10002,12),(10002,16),(10002,28),(10002,30),(10002,32);

insert into dealer_brand(dealer_id, brand_id) values(10003,7),(10003,12),(10003,16),(10003,28),(10003,30),(10003,32);

insert into dealer_brand(dealer_id, brand_id) values(10004,7),(10004,12),(10004,16),(10004,28),(10004,30),(10004,32);

insert into dealer_brand(dealer_id, brand_id) values(10005,7),(10005,12),(10005,16),(10005,28),(10005,30),(10005,32);

insert into dealer_brand(dealer_id, brand_id) values(10006,7),(10006,12),(10006,16),(10006,28),(10006,30),(10006,32);

insert into dealer_brand(dealer_id, brand_id) values(10007,7),(10007,12),(10007,16),(10007,28),(10007,30),(10007,32);

insert into dealer_brand(dealer_id, brand_id) values(10008,7),(10008,12),(10008,16),(10008,28),(10008,30),(10008,32);

insert into dealer_brand(dealer_id, brand_id) values(10009,7),(10009,12),(10009,16),(10009,28),(10009,30),(10009,32);

insert into dealer_brand(dealer_id, brand_id) values(10010,7),(10010,12),(10010,16),(10010,28),(10010,30),(10010,32);

insert into dealer_brand(dealer_id, brand_id) values(10011,7),(10011,12),(10011,16),(10011,28),(10011,30),(10011,32);

insert into dealer_brand(dealer_id, brand_id) values(10012,7),(10012,12),(10012,16),(10012,28),(10012,30),(10012,32);

insert into dealer_brand(dealer_id, brand_id) values(10013,7),(10013,12),(10013,16),(10013,28),(10013,30),(10013,32);