truncate table areas;


