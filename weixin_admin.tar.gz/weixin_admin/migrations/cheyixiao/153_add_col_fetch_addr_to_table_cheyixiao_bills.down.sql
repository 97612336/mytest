alter table `cheyixiao`.`bills` drop `fetch_addr`;
