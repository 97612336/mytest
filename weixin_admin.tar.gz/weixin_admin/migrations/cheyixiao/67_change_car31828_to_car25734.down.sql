update specs set id=31825,
name="雷克萨斯GS 2017款 300 F SPORT",
guide_price="49.90万"
 where id=25734;

update car_color set car_id=31828 where car_id=25734;
update car_wheels set car_id=31828 where car_id=25734;
update car_scheme set car_id=31828 where car_id=25734;
update dealer_spec set car_id=31828 where car_id=25734;
update focus_car set car_id=31828  where car_id=25734;
update hotpoints set car_id=31828 where car_id=25734;
update look set car_id=31828 where car_id=25734;
update user_status set car_id=31828 where car_id=25734;
update bills set car_id=31828 where car_id=25734;



