alter table bills add index `index_user_id`(`user_id`),
add index `index_saler_id`(`saler_id`);
