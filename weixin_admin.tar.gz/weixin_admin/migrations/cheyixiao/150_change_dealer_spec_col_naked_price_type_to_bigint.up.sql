alter table `cheyixiao`.`dealer_spec` modify `naked_price` float not null default 0 ;
