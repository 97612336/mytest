alter table focus_car drop index `index_saler_id`;
