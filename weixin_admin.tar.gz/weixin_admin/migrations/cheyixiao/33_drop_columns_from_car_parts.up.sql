alter table car_parts drop column upline_at,
drop column downline_at,
drop column status;

