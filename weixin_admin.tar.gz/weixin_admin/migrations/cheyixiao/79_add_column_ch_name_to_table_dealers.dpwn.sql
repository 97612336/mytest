
ALTER TABLE `dealers` DROP COLUMN `ch_name`;