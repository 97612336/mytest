alter table look add index `index_saler_id`(`saler_id`);
