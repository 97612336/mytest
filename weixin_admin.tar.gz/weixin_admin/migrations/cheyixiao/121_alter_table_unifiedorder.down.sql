alter table unifiedorder drop column pay_type;
alter table unifiedorder modify bill_id int not null;