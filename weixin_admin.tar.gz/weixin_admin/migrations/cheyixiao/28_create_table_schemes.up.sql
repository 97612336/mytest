create table if not exists schemes(
    id int not null primary key auto_increment,
    dealer_id int not null,
    cs_id int,
    name varchar(32) not null,
    price float not null,
    img_id int,
    created_at timestamp not null default current_timestamp,
    updated_at timestamp not null default current_timestamp on update current_timestamp,
    index `idx_dealer_id`(dealer_id)
)engine=InnoDB default charset=utf8mb4;