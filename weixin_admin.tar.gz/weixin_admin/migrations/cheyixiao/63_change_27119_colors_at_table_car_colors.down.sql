delete from car_color where car_id=27119;
insert into car_color(car_id, ename, name, color) values
(27119, 'Color_00', '大漠金', 'rgb(166,140,80)'),
(27119, 'Color_01', '皓月白', 'rgb(238,243,245)'),
(27119, 'Color_02', '烈焰红', 'rgb(231,70,28)'),
(27119, 'Color_03', '星空蓝', 'rgb(0,101,173)'),
(27119, 'Color_04', '旭日橙', 'rgb(178,29,51)');