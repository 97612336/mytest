CREATE TABLE cheyixiao.find_car (
    id INT NOT NULL primary key auto_increment,
    saler_id INT NULL DEFAULT NULL,
    spec_id INT NULL DEFAULT NULL,
    car_format VARCHAR(45) NULL DEFAULT NULL,
    color VARCHAR(45) NULL DEFAULT NULL,
    plate_city INT NULL DEFAULT NULL,
    fetch_area VARCHAR(256) NULL DEFAULT NULL,
    end_time datetime NULL DEFAULT NULL,
    order_fee INT NULL DEFAULT NULL,
    expect_price VARCHAR(45) NULL DEFAULT NULL,
    special_need VARCHAR(128) NULL DEFAULT NULL,
    remark VARCHAR(256) NULL DEFAULT NULL,
    status INT NULL DEFAULT 0,
    updated_at timestamp not null default current_timestamp on update CURRENT_TIMESTAMP,
    created_at timestamp not null default current_timestamp ,
    index(spec_id,saler_id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
