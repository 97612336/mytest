alter table specs drop column naked_price,
drop column status,
drop column nums;
