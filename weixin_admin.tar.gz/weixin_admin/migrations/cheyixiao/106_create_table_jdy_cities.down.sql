drop table `jdy_cities`;

