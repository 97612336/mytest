update car_color set color="rgb(200,0,0)" where car_id=29522 and ename="Color_00";
update car_color set color="rgb(199,70,0)" where car_id=29522 and ename="Color_02";
update car_color set color="rgb(243,235,23)" where car_id=29522 and ename="Color_03";
update car_color set color="rgb(73,73,73)" where car_id=29522 and ename="Color_04";
update car_color set color="rgb(91,171,5)" where car_id=29522 and ename="Color_05";
update car_color set color="rgb(0,0,0)" where car_id=29522 and ename="Color_07";
update car_color set color="rgb(0,32,79)" where car_id=29522 and ename="Color_08";
update car_color set color="rgb(252,111,45)" where car_id=29522 and ename="Color_10";

update car_color set color="rgb(72,40,7)" where car_id=32048 and ename="Color_00";
update car_color set color="rgb(63,99,131)" where car_id=32048 and ename="Color_02";
update car_color set color="rgb(137,3,10)" where car_id=32048 and ename="Color_05";

update car_color set color="rgb(35,42,48)" where car_id=30268 and ename="Color_00";
update car_color set color="rgb(216,202,180)" where car_id=30268 and ename="Color_01";
update car_color set color="rgb(245,245,245)" where car_id=30268 and ename="Color_02";
update car_color set color="rgb(231,231,231)" where car_id=30268 and ename="Color_03";
update car_color set color="rgb(231,232,250)" where car_id=30268 and ename="Color_04";
update car_color set color="rgb(36,34,36)" where car_id=30268 and ename="Color_05";

update car_color set color="rgb(128,110,80)" where car_id=33371 and ename="Color_00";
update car_color set color="rgb(67,67,67)" where car_id=33371 and ename="Color_03";
update car_color set color="rgb(166,0,0)" where car_id=33371 and ename="Color_04";
update car_color set color="rgb(35,120,187)" where car_id=33371 and ename="Color_05";

update car_color set color="rgb(100,67,54)" where car_id=32713 and ename="Color_01";
update car_color set color="rgb(169,142,88)" where car_id=32713 and ename="Color_02";
update car_color set color="rgb(35,52,184)" where car_id=32713 and ename="Color_03";
update car_color set color="rgb(211,32,41)" where car_id=32713 and ename="Color_04";
