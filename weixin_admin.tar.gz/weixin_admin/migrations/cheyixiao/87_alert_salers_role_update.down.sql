update salers set role=null where perm=2;
update salers set role=null where perm=1;

update salers set role=null where id=63;
update salers set role=null where id=65;