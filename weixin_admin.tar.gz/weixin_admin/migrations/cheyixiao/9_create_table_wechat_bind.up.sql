create table if not exists wechat_bind(
    id int not null primary key auto_increment,
    openid varchar(32),
    dealer_id int,
    saler_id int,
    updated_at timestamp not null default current_timestamp,
    created_at timestamp not null default current_timestamp on update CURRENT_TIMESTAMP,
    index(openid, dealer_id, saler_id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;