alter table specs drop column bg;
