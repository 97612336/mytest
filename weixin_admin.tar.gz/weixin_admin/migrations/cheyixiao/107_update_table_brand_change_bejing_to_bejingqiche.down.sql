update brands set name="北京",pinyin="beijing"
where name="北京汽车" and pinyin="beijingqiche";