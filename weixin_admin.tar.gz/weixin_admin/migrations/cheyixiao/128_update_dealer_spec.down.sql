DELETE FROM `cheyixiao`.`dealer_spec` WHERE `dealer_id`=1000;
DELETE FROM `cheyixiao`.`dealer_spec` WHERE `dealer_id`=10007;
DELETE FROM `cheyixiao`.`dealer_spec` WHERE `dealer_id`=10008;
DELETE FROM `cheyixiao`.`dealer_spec` WHERE `dealer_id`=10009;