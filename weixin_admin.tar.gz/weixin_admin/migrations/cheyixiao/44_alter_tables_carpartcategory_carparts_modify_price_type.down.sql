alter table car_part_category modify price decimal(11,2);
alter table car_parts modify price decimal(11,2);