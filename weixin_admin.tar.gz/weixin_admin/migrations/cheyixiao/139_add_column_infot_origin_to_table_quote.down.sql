alter table cheyixiao.quote drop column info_origin;
