delete from `salers` where id in (31,32,33,34,35);

update `salers` set phone=0 where id=18;

delete from devices where id in (6,7,8,9,10);

delete from dealers where id in (10001, 10002, 10003, 10004, 10005);

delete from dealer_brand where dealer_id in (2000, 10001, 10002, 10003, 10004, 10005);
