ALTER TABLE cheyixiao.bill_loans DROP COLUMN `saler_id`;
ALTER TABLE cheyixiao.stock_loans DROP COLUMN `saler_id`;