alter table car_part_category drop column car_id;
