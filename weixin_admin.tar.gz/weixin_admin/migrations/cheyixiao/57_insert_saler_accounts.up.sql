
INSERT INTO `salers`(username, password, name,phone,device_id,dealer_id,perm,avatar)
VALUES('zhaohailong','642abb2f6a58e1706e17bf10bcdd0191','赵海龙',15236507780,12,10007,1,NULL);

insert into devices(id, name,dealer_id,expire_at) values(12, 'pad12',10007,'2020-01-01');

insert into dealers(id,name, company,address) values(10007,'车势科技西北一区','北京车势科技有限公司','北京朝阳区东大桥尚都北塔A座1001');

insert into dealer_brand(dealer_id, brand_id, onsell) values(10007,20, 1),(10007,21, 1),(10007,6, 1),(10007,22,1),
(10007,27,1),(10007,11,1),(10007,18,1),(10007,31,1),(10007,29,1),(10007,24,1);

insert into dealer_spec(dealer_id, car_id, status) values(10007,30781, 2),(10007,28327, 2),(10007,30059, 2),(10007,31828,2),
(10007,31704,2),(10007,32522,2),(10007,32831,2),(10007,1003213,2),(10007,24967,2),(10007,28439,2),
(10007,27900,2),(10007,31215,2),(10007,30899,2),(10007,29443,2),(10007,31721,2),(10007,32004,2);


INSERT INTO `salers`(username, password, name,phone,device_id,dealer_id,perm,avatar)
VALUES('wangzhaopu','1d653032237293a451f50b27b92b5d13','汪照普',15236507780,13,10008,1,NULL);

insert into devices(id, name,dealer_id,expire_at) values(13, 'pad13',10008,'2020-01-01');

insert into dealers(id,name, company,address) values(10008,'车势科技西北二区','北京车势科技有限公司','北京朝阳区东大桥尚都北塔A座1001');

insert into dealer_brand(dealer_id, brand_id, onsell) values(10008,20, 1),(10008,21, 1),(10008,6, 1),(10008,22,1),
(10008,27,1),(10008,11,1),(10008,18,1),(10008,31,1),(10008,29,1),(10008,24,1);

insert into dealer_spec(dealer_id, car_id, status) values(10008,30781, 2),(10008,28327, 2),(10008,30059, 2),(10008,31828,2),
(10008,31704,2),(10008,32522,2),(10008,32831,2),(10008,1003213,2),(10008,24967,2),(10008,28439,2),
(10008,27900,2),(10008,31215,2),(10008,30899,2),(10008,29443,2),(10008,31721,2),(10008,32004,2);


INSERT INTO `salers`(username, password, name,phone,device_id,dealer_id,perm,avatar)
VALUES('yipei001','fef0b6b26fd452a4f19e1f2e213a88ef','易沛',15236507780,14,10009,1,NULL);

insert into devices(id, name,dealer_id,expire_at) values(14, 'pad14',10009,'2020-01-01');

insert into dealers(id,name, company,address) values(10009,'车势科技西北三区','北京车势科技有限公司','北京朝阳区东大桥尚都北塔A座1001');

insert into dealer_brand(dealer_id, brand_id, onsell) values(10009,20, 1),(10009,21, 1),(10009,6, 1),(10009,22,1),
(10009,27,1),(10009,11,1),(10009,18,1),(10009,31,1),(10009,29,1),(10009,24,1);

insert into dealer_spec(dealer_id, car_id, status) values(10009,30781, 2),(10009,28327, 2),(10009,30059, 2),(10009,31828,2),
(10009,31704,2),(10009,32522,2),(10009,32831,2),(10009,1003213,2),(10009,24967,2),(10009,28439,2),
(10009,27900,2),(10009,31215,2),(10009,30899,2),(10009,29443,2),(10009,31721,2),(10009,32004,2);

insert into dealer_brand(dealer_id, brand_id, onsell) values(1000,20, 1),(1000,21, 1),(1000,6, 1),(1000,22,1),
(1000,27,1),(1000,11,1),(1000,18,1),(1000,31,1),(1000,29,1),(1000,24,1);

insert into car_scheme(dealer_id, car_id, status) values(10009,30781, 2),(10009,28327, 2),(10009,30059, 2),(10009,31828,2),
(10009,31704,2),(10009,32522,2),(10009,32831,2),(10009,1003213,2),(10009,24967,2),(10009,28439,2),
(10009,27900,2),(10009,31215,2),(10009,30899,2),(10009,29443,2),(10009,31721,2),(10009,32004,2);