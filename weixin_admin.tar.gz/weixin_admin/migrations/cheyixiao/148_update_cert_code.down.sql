DELETE FROM `cheyixiao`.`dealer_spec` WHERE `dealer_id`=23369;
DELETE FROM `cheyixiao`.`dealer_spec` WHERE `dealer_id`=23370;
DELETE FROM `cheyixiao`.`dealer_spec` WHERE `dealer_id`=23371;
DELETE FROM `cheyixiao`.`dealer_spec` WHERE `dealer_id`=23372;
DELETE FROM `cheyixiao`.`dealer_spec` WHERE `dealer_id`=23373;
