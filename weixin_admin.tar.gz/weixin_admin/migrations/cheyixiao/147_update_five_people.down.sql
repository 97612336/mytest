update cheyixiao.salers set is_pay=0 where username="zhangjinwei";
update cheyixiao.salers set is_pay=0 where username="liubei";
update cheyixiao.salers set is_pay=0 where username="zhongwen";
update cheyixiao.salers set is_pay=0 where username="songtao";
update cheyixiao.salers set is_pay=0 where username="zhudaoyuan";