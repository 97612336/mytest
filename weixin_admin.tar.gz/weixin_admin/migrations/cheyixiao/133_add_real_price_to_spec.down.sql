ALTER TABLE `cheyixiao`.`specs` DROP COLUMN `real_price`;
