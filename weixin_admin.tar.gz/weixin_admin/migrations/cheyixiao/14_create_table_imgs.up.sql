create table if not exists imgs(
    id int not null primary key auto_increment,
    url varchar(128) not null,
    created_at timestamp not null default current_timestamp,
    updated_at timestamp not null default current_timestamp on update current_timestamp
)engine=InnoDB default charset=utf8mb4;