alter table user_status add end_status tinyint default null after car_id;


