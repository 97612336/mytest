alter table bills drop column order_fee;
alter table bills add column order_status int null default 0;