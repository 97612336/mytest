create table if not exists look(
    id int not null primary key auto_increment,
    user_id int,
    car_id int,
    saler_id int,
    ip varchar(16),
    action varchar(32),
    avalue varchar(16),
    updated_at timestamp not null default current_timestamp,
    created_at timestamp not null default current_timestamp on update CURRENT_TIMESTAMP,
    index(user_id, car_id, saler_id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;