update cheyixiao.series set brand_id=55 where brand_id=44;
delete from cheyixiao.brands where id=44;
