update car_color set name="塔希提金",
 color="rgb(209,194,179)"
 where car_id=31721 and ename="Color_06";

update car_color set name="凯撒金",
 color="rgb(151,151,151)"
 where car_id=31721 and ename="Color_03";