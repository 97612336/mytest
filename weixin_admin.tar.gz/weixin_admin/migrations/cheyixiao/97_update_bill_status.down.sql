update bills set order_status=0 where order_status = 0;
