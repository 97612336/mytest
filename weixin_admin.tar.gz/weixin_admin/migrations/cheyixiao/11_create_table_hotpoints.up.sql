create table if not exists hotpoints(
    id int not null primary key auto_increment,
    name varchar(64),
    ename varchar(32),
    car_id int,
    unique key `uk_ename` (ename)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;