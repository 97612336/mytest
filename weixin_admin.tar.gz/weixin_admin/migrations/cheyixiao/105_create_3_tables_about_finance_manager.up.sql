create table if not exists bill_loans
(id int not null primary key auto_increment,
info varchar(32) null comment "供应商信息(名称)",
short_name varchar(32) null comment "订单简称(订单贷)",
car_type tinyint null comment "车规类型",
car_id int null comment "车辆id",
car_color varchar(32) null comment "外观内饰颜色",
car_num int null comment "车辆数量",
car_price int not null default 0 comment "单辆车合同价格",
contract_fee int not null default 0 comment "合同金额(订单贷)",
payed int not null default 0 comment "已支付金额(订单贷)",
pay_in int not null default 0 comment "垫资金额",
ratio tinyint not null default 0 comment "贷款配比",
deposit int not null default 0 comment "实际打款保证金",
pic_purchase varchar(128) null comment "采购合同照片url(订单贷)",
pic_payed varchar(128) null comment "已支付凭证照片url(订单贷)",
pic_procedure varchar(128) null comment "手续函照片url(订单贷)",
updated_at timestamp not null default current_timestamp on update CURRENT_TIMESTAMP,
created_at timestamp not null default current_timestamp
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

create table if not exists stock_loans
(id int not null primary key auto_increment,
info varchar(32) null comment "供应商信息(名称)",
total_fee int null default null comment "总金额(库融贷)",
pay_in int null default null comment "垫资金额",
ratio tinyint null default null comment "贷款配比",
deposit int null default null comment "实际打款保证金",
pic_cert varchar(128) null default null comment "车辆合格证照片url(库融贷)",
pic_invoice varchar(128) null default null comment "发票照片url(库融贷)",
updated_at timestamp not null default current_timestamp on update CURRENT_TIMESTAMP,
created_at timestamp not null default current_timestamp
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

create table if not exists stock_loans_cars
(id int not null primary key auto_increment,
sl_id int null comment "库融贷订单id",
car_id int null comment "库融贷订单内车型id",
car_type tinyint null comment "车辆类型",
car_color varchar(32) null default null comment "车辆颜色",
car_price int not null default 0 comment "车辆价格",
car_num int not null default 0 comment "车辆数量",
updated_at timestamp not null default current_timestamp on update CURRENT_TIMESTAMP,
created_at timestamp not null default current_timestamp,
key index_sl_id (sl_id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;





