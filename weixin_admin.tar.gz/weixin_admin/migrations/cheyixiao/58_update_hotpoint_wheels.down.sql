update car_wheels set logo='https://cheyixiao.autoforce.net/static/wheels/28237/wheel_01.png' where car_id=28327 and ename='Wheel_01';
update car_wheels set logo='https://cheyixiao.autoforce.net/static/wheels/28237/wheel_02.png' where car_id=28327 and ename='Wheel_02';

update hotpoints set ename='28237_2' where id=49;
update hotpoints set ename='28237_16' where id=50;
update hotpoints set ename='28237_12' where id=51;
update hotpoints set ename='28237_30' where id=52;
update hotpoints set ename='28237_25' where id=53;
update hotpoints set ename='28237_31' where id=54;
update hotpoints set ename='28237_9' where id=55;
update hotpoints set ename='28237_4' where id=56;