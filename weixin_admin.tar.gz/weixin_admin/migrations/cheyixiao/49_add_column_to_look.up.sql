alter table look add column lon varchar(32);

alter table look add column lat varchar(32);