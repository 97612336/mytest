update cheyixiao.car_wheels set ename="Wheel_01" where car_id=33371 and name="19寸overland";
