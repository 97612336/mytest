CREATE TABLE cheyixiao.login_record (
    id INT NOT NULL primary key auto_increment,
    saler_id int not null,
    ip varchar(16) not null,
    style int not null,
    updated_at timestamp not null default current_timestamp on update CURRENT_TIMESTAMP,
    created_at timestamp not null default current_timestamp
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
