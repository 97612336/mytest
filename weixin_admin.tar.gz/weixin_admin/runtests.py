#!/usr/bin/env python
# coding=utf-8

from __future__ import absolute_import, print_function
import unittest


def all():
    return unittest.defaultTestLoader.discover('tests')

if __name__ == '__main__':
    import tornado.testing
    import tests
    tests.dbSetUp()
    tornado.testing.main()
    tests.dbTearDown()
