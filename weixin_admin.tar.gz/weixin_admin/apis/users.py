# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT
)
from .models import Models


class Users(Base, TimestampMixin):
	__tablename__ = 'users'
	id = Column(Integer, primary_key=True, nullable=False)
	openid = Column(String(32), nullable=False, unique=True, index=True)
	nickname = Column(String(64), nullable=False)
	name = Column(String(32))
	phone = Column(BIGINT)
	pic = Column(String(256))
	utype = Column(Integer)
	note = Column(String(256))
	is_test = Column(Integer)
	remark = Column(String(256))


Models.reg('users', Users)
