# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT
)
from .models import Models


class StockLoans(Base, TimestampMixin):
	__tablename__ = 'stock_loans'
	id = Column(Integer, primary_key=True, nullable=False)
	info = Column(String(32))
	total_fee = Column(Integer, default=0)
	pay_in = Column(Integer, default=0)
	ratio = Column(Integer, default=0)
	deposit = Column(Integer, default=0)
	pic_cert = Column(String(128))
	pic_invoice = Column(String(128))
	saler_id = Column(Integer)
	status = Column(Integer, default=0)


Models.reg('stock_loans', StockLoans)