# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT
)
from .models import Models


class Dealers(Base, TimestampMixin):
	__tablename__ = 'dealers'
	id = Column(Integer, primary_key=True, nullable=False)
	name = Column(String(64), unique=True)
	company = Column(String(128))
	address = Column(String(255))
	call = Column(String(32))
	contacts = Column(String(16))
	ch_name = Column(String(64))
	phone = Column(BIGINT)
	pic = Column(String(64))
	bus_licence = Column(String(64))
	code_certificate = Column(String(64))
	ID_card = Column(String(64))
	d_type = Column(Integer)
	status = Column(Integer)
	perm = Column(Integer)
	pic_door = Column(String(256))
	pic_show = Column(String(256))
	pic_rest = Column(String(256))
	pic_other = Column(String(256))
	region = Column(String(16))


Models.reg('dealers', Dealers)