# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT
)
from .models import Models
from sqlalchemy import DECIMAL

class DealerSpec(Base, TimestampMixin):
	__tablename__ = 'dealer_spec'
	id = Column(Integer, primary_key=True, nullable=False)
	dealer_id = Column(Integer)
	car_id = Column(Integer)
	naked_price = Column(DECIMAL(9, 2), nullable=False, default=0)
	nums = Column(Integer)
	status = Column(Integer)
Models.reg('dealer_spec', DealerSpec)