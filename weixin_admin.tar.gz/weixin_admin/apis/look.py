# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT
)
from .models import Models


class Look(Base, TimestampMixin):
	__tablename__ = 'look'
	id = Column(Integer, primary_key=True, nullable=False)
	user_id = Column(Integer, index=True)
	car_id = Column(Integer, index=True)
	saler_id = Column(Integer, index=True)
	action = Column(String(32))
	avalue = Column(String(16))
	ip = Column(String(16))
	lon = Column(String(32))
	lat = Column(String(32))

Models.reg('look', Look)