# coding=utf-8

from __future__ import absolute_import, print_function
import hashlib

from sqlalchemy import Float

from . import (
    Base,
    Column,
    Integer,
    String,
    TimestampMixin,
    text,
    TIMESTAMP,
    BIGINT,
    DateTime,

)
from .models import Models


class LogisticsBill(Base, TimestampMixin):
    __tablename__ = 'logistics_bill'
    id = Column(Integer, primary_key=True, nullable=False)
    city_id_begin = Column(Integer)
    city_id_end = Column(Integer)
    send_time = Column(DateTime)
    car_type = Column(Integer)
    car_price = Column(Integer)
    car_num = Column(Integer)
    receiver_name = Column(String(64))
    receiver_phone = Column(BIGINT)
    receiver_address = Column(String(256))
    is_invoice = Column(Integer)
    receiver_company = Column(String(128))
    tax_number = Column(String(45))
    sender_name = Column(String(64))
    sender_phone = Column(BIGINT)
    sender_address = Column(String(256))
    saler_id = Column(Integer)


Models.reg('logistics_bill', LogisticsBill)
