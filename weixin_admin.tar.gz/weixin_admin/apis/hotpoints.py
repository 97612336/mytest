# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT
)
from .models import Models


class Hotpoints(Base):
	__tablename__ = 'hotpoints'
	id = Column(Integer, primary_key=True, nullable=False)
	car_id = Column(Integer, index=True)
	name = Column(String(64))
	ename = Column(String(32))

Models.reg('hotpoints', Hotpoints)