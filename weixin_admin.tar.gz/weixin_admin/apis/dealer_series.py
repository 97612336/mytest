# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT
)
from .models import Models


class DealerSeries(Base, TimestampMixin):
	__tablename__ = 'dealer_series'
	id = Column(Integer, primary_key=True, nullable=False)
	dealer_id = Column(Integer)
	series_id = Column(Integer)

Models.reg('dealer_series', DealerSeries)