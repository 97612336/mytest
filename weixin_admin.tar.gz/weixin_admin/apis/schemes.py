# coding=utf-8

from __future__ import absolute_import, print_function
from sqlalchemy import DECIMAL
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT,
)
from .models import Models


class Schemes(Base, TimestampMixin):
	__tablename__ = 'schemes'

	id = Column(Integer, primary_key=True, nullable=False)
	dealer_id = Column(Integer, nullable=False)
	cs_id = Column(Integer)
	name = Column(String(32), nullable=False, default='')
	price = Column(DECIMAL(9, 2), nullable=False, default=0)
	img_id = Column(Integer)


Models.reg('schemes', Schemes)
