# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT
)
from .models import Models


class BillLoans(Base, TimestampMixin):
	__tablename__ = 'bill_loans'
	id = Column(Integer, primary_key=True, nullable=False)
	info = Column(String(32))
	short_name = Column(String(32))
	car_type = Column(Integer)
	car_id = Column(Integer)
	car_color = Column(String(32))
	car_num = Column(Integer)
	car_price = Column(Integer, default=0)
	contract_fee = Column(Integer, default=0)
	payed = Column(Integer, default=0)
	pay_in = Column(Integer, default=0)
	ratio = Column(Integer, default=0)
	deposit = Column(Integer, default=0)
	pic_purchase = Column(String(128))
	pic_payed = Column(String(128))
	pic_procedure = Column(String(128))
	saler_id = Column(Integer)
	status = Column(Integer, default=0)


Models.reg('bill_loans', BillLoans)