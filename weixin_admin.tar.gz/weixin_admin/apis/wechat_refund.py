# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT
)
from .models import Models


class WechatRefund(Base, TimestampMixin):
	__tablename__ = 'wechat_refund'
	id = Column(Integer, primary_key=True, nullable=False, autoincrement=True)
	total_fee = Column(Integer)
	fee_type = Column(String(16), default='CNY')
	out_trade_no = Column(String(32), unique=True)
	transaction_id = Column(String(32), unique=True, index=True)
	out_refund_no = Column(String(64), unique=True)
	refund_fee = Column(Integer)
	refund_id = Column(String(32))
	cash_fee = Column(Integer)
	cash_fee_type = Column(String(16), default='CNY')
	refund_status = Column(String(16))
	refund_account = Column(String(30))
	success_time = Column(String(20))
	refund_recv_account = Column(String(64))
	refund_request_source = Column(String(30))


Models.reg('wechat_refund', WechatRefund)