# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT
)
from .models import Models


class Brands(Base):
	__tablename__ = 'brands'
	id = Column(Integer, primary_key=True, nullable=False)
	name = Column(String(64))
	logo = Column(String(256))
	pinyin = Column(String(45))
	status = Column(Integer)

Models.reg('brands', Brands)