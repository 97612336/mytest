# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT
)
from .models import Models


class DealerBrand(Base, TimestampMixin):
	__tablename__ = 'dealer_brand'
	id = Column(Integer, primary_key=True, nullable=False)
	dealer_id = Column(Integer)
	brand_id = Column(Integer)
	onsell = Column(Integer, default=0)

Models.reg('dealer_brand', DealerBrand)