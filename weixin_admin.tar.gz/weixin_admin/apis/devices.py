# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	DateTime
)
from .models import Models


class Devices(Base, TimestampMixin):
	__tablename__ = 'devices'
	id = Column(Integer, primary_key=True, nullable=False)
	name = Column(String(32))
	dealer_id = Column(Integer)
	expire_at = Column(DateTime)


Models.reg('devices', Devices)