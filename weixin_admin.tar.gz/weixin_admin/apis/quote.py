# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
    Base,
    Column,
    Integer,
    String,
    TimestampMixin,
    text,
    TIMESTAMP,
    BIGINT,
    DateTime

)
from .models import Models


class Quote(Base, TimestampMixin):
    __tablename__ = 'quote'
    id = Column(Integer, primary_key=True, nullable=False)
    find_id = Column(Integer)
    saler_id = Column(Integer)
    location = Column(Integer)
    quote = Column(String(45))
    end_time = Column(DateTime)
    remark = Column(String(256))
    info_origin = Column(Integer, default=0)


Models.reg('quote', Quote)
