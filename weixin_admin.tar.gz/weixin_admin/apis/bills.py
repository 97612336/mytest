# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT
)
from .models import Models


class Bills(Base, TimestampMixin):
	__tablename__ = 'bills'
	id = Column(Integer, primary_key=True, nullable=False)
	user_id = Column(Integer)
	openid = Column(String(32))
	saler_id = Column(Integer)
	car_id = Column(Integer)
	color = Column(String(16))
	hub = Column(String(16))
	total_cost = Column(Integer)
	order_fee = Column(Integer)
	invoice = Column(String(128), default=None)
	dr_license = Column(String(128), default=None)
	i1 = Column(Integer)
	i2 = Column(Integer)
	i3 = Column(Integer)
	i4 = Column(Integer)
	i5 = Column(Integer)
	i6 = Column(Integer)
	i7 = Column(Integer)
	i8 = Column(Integer)
	i9 = Column(Integer)
	i10 = Column(Integer)
	i11 = Column(Integer)
	i12 = Column(Integer)
	i13 = Column(Integer)
	i14 = Column(Integer)
	i15 = Column(Integer)
	i16 = Column(Integer)
	is_test = Column(Integer)
	fetch_addr = Column(String)


Models.reg('bills', Bills)