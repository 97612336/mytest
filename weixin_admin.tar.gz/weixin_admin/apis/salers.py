# coding=utf-8

from __future__ import absolute_import, print_function
import hashlib
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT,
	DateTime
)
from .models import Models


class Salers(Base, TimestampMixin):
	__tablename__ = 'salers'
	id = Column(Integer, primary_key=True, nullable=False)
	username = Column(String(32), nullable=False, unique=True, index=True)
	password = Column(String(32), nullable=False)
	name = Column(String(32))
	phone = Column(BIGINT)
	device_id = Column(Integer)
	dealer_id = Column(Integer)
	perm = Column(Integer)
	avatar = Column(String(256))

	city = Column(Integer)
	role = Column(Integer)
	address = Column(String(256))
	brands = Column(String(32))
	cert_code = Column(Integer)
	reason = Column(String(128), default=None)
	ID_face = Column(String(128))
	ID_con = Column(String(128))
	is_pay = Column(Integer)
	reference = Column(String(128))
	@staticmethod
	def to_password(username=None, password=''):
		return hashlib.md5(
			(":saler:" + password).encode('utf-8')).hexdigest()


Models.reg('salers', Salers)