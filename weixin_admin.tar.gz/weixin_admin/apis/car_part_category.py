# coding=utf-8

from __future__ import absolute_import, print_function
from sqlalchemy import DECIMAL
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT,
	DateTime

)
from .models import Models


class CarPartCategory(Base, TimestampMixin):
	__tablename__ = 'car_part_category'

	id = Column(Integer, primary_key=True, nullable=False)
	dealer_id = Column(Integer, nullable=False)
	name = Column(String(32), nullable=False, default='')
	price = Column(DECIMAL(9, 2), nullable=False, default=0)
	img_id = Column(Integer)
	status = Column(Integer, nullable=False, default=1)
	upline_at = Column(DateTime)
	downline_at = Column(DateTime)


Models.reg('car_part_category',CarPartCategory)