# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT
)
from .models import Models


class StockLoansCars(Base, TimestampMixin):
	__tablename__ = 'stock_loans_cars'
	id = Column(Integer, primary_key=True, nullable=False)
	sl_id = Column(Integer)
	car_id = Column(Integer)
	car_type = Column(Integer)
	car_color = Column(String(32))
	car_price = Column(Integer, default=0)
	car_num = Column(Integer)


Models.reg('stock_loans_cars', StockLoansCars)