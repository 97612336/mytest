# coding=utf-8

from __future__ import absolute_import, print_function
from sqlalchemy import DECIMAL
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT,
)
from .models import Models


class CarScheme(Base, TimestampMixin):
	__tablename__ = 'car_scheme'

	id = Column(Integer, primary_key=True, nullable=False)
	car_id = Column(Integer)
	status = Column(Integer, nullable=False, default=1)
	dealer_id = Column(Integer, nullable=False)


Models.reg('car_scheme', CarScheme)