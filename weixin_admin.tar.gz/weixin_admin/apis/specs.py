# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT
)
from .models import Models
from sqlalchemy import DECIMAL


class Specs(Base, TimestampMixin):
	__tablename__ = 'specs'
	id = Column(Integer, primary_key=True, nullable=False)
	name = Column(String(64))
	logo = Column(String(256))
	series_id = Column(Integer)
	guide_price = Column(DECIMAL(9, 2), nullable=False, default=0)
	real_price = Column(String(45))
	bg = Column(String(16))
	look_way = Column(Integer)
	is_hot = Column(Integer, default=0)


Models.reg('specs', Specs)
