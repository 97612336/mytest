# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
    Base,
    Column,
    Integer,
    String,
    TimestampMixin,
    text,
    TIMESTAMP,
    BIGINT,
    DateTime

)
from .models import Models


class FindCar(Base):
    __tablename__ = 'find_car'
    id = Column(Integer, primary_key=True, nullable=False)
    saler_id = Column(Integer)
    spec_id = Column(Integer)
    car_format = Column(String(45))
    color = Column(String(45))
    plate_city = Column(Integer)
    fetch_area = Column(String(256))
    end_time = Column(DateTime)
    order_fee = Column(Integer)
    expect_price = Column(String(45))
    special_need = Column(String(128))
    remark = Column(String(256))
    status = Column(Integer, default=0)
    created_at = Column(TIMESTAMP)


Models.reg('find_car', FindCar)
