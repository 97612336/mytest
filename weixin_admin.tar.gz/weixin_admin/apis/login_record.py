# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT
)
from .models import Models


class LoginRecord(Base, TimestampMixin):
	__tablename__ = 'login_record'
	id = Column(Integer, primary_key=True, nullable=False)
	saler_id = Column(Integer, nullable=False)
	ip = Column(String(16), nullable=False)
	style = Column(Integer, nullable=False)


Models.reg('login_record', LoginRecord)