# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT
)
from .models import Models


class Series(Base):
	__tablename__ = 'series'
	id = Column(Integer, primary_key=True, nullable=False)
	name = Column(String(64))
	logo = Column(String(256))
	brand_id = Column(Integer)
	resource_url = Column(String(256))

Models.reg('series', Series)