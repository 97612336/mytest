from __future__ import absolute_import, print_function
from sqlalchemy import DECIMAL
from . import (
    Base,
    Column,
    Integer,
    String,
    TimestampMixin,
    text,
    TIMESTAMP,
    BIGINT,
    DateTime
)
from .models import Models


class Activity_score(Base, TimestampMixin):
    __tablename__ = 'activity_score'

    id = Column(Integer, primary_key=True, nullable=False)
    saler_id = Column(Integer)
    join_time = Column(DateTime)
    score = Column(Integer, default=0)
    updated_at = Column(DateTime)
    created_at = Column(DateTime)


Models.reg('activity_score', Activity_score)
