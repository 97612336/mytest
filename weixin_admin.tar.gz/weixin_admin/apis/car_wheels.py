# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT
)
from .models import Models


class CarWheels(Base):
	__tablename__ = 'car_wheels'
	id = Column(Integer, primary_key=True, nullable=False)
	car_id = Column(Integer, index=True)
	ename = Column(String(16))
	name = Column(String(32))
	logo = Column(String(256))

Models.reg('car_wheels', CarWheels)