# coding=utf-8

from __future__ import absolute_import, print_function
import glob
import os
import logging
import datetime

from inflection import tableize

from sqlalchemy.orm.interfaces import NOT_EXTENSION
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.ext.declarative import declared_attr
from sqlalchemy.ext.hybrid import (
    hybrid_property,
    hybrid_method,
    HYBRID_PROPERTY,
)
from sqlalchemy import (
    Index,
    Column,
    Integer,
    String,
    DATE,
    DateTime,
    TIMESTAMP,
    BOOLEAN,
    BIGINT,
    UniqueConstraint,
    ForeignKey,
)
from sqlalchemy.sql import func, text, exists
from sqlalchemy.orm import relationship
from sqlalchemy import literal


class Base(object):
    @declared_attr
    def __tablename__(cls):
        return tableize(cls.__name__)

    __table_args__ = {'mysql_engine': 'InnoDB'}

    def visual_items(self, name=None):
        if not hasattr(self, '__visual_items__'):
            self.__visual_items__ = {}
        if name is None:
            return self.__visual_items__
        return self.__visual_items__[name]

    def to_dict(self):
        o = {c.name: getattr(self, c.name) for c in self.__table__.columns}
        for i in self.__mapper__.all_orm_descriptors:
            if not i.is_attribute:
                continue
            if i.extension_type is HYBRID_PROPERTY:
                o[i.fget.__name__] = i.fget(self)
        o.update(self.visual_items())
        return o

    def __getitem__(self, name):
        if name in self.__table__.columns:
            return getattr(self, name)
        return self.visual_items(name)

    def __setitem__(self, name, v):
        if name in self.__table__.columns:
            setattr(self, name, v)
            return
        self.visual_items()[name] = v

    def get(self, name, defv):
        v = defv
        try:
            v = getattr(self, name)
        except BaseException:
            try:
                v = self.visual_items(name)
            except:
                pass
        if v is None:
            v = defv
        return v

    @classmethod
    def find_one_and_update(cls, session, query, update, upsert=False):
        res = session.query(cls).filter_by(**query).first()
        if not res:
            if upsert:
                if '$set' in update:
                    info = update['$set']
                    if "id" in info.keys():
                        if not info["id"]:
                            del info["id"]
                    for k, v in query.items():
                        if type(v) in [list, dict, tuple, set]:
                            continue
                        if k == "id" and not bool(v):
                            continue
                        info[k] = v
                    return cls.insert_one(session, info)
            return res
        if '$set' in update:
            update = update['$set']
            for k, v in update.items():
                setattr(res, k, v)
            session.commit()
        return res

    @classmethod
    def insert_one(cls, session, info):
        res = cls(**info)
        session.add(res)
        session.commit()
        return res

    @classmethod
    def insert_many(cls, session, info):
        res = cls(**info)
        session.add(res)
        return


    @classmethod
    def update_one(cls, session, query, update, upsert=False):
        if not upsert:
            if '$set' in update:
                update = update['$set']
            session.query(cls).filter_by(**query).update(update)
            session.commit()
            return
        return cls.find_one_and_update(session=session, query=query,
                                       update=update, upsert=upsert)

    @classmethod
    def update_many(cls, session, query, update):
        if '$set' in update:
            update = update['$set']
        session.query(cls).filter_by(**query).update(update)
        session.commit()


Base = declarative_base(cls=Base)


class TimestampMixin(object):
    @declared_attr
    def created_at(cls):
        return Column(
            TIMESTAMP,
            nullable=False,
            server_default=func.now(),
        )

    @declared_attr
    def updated_at(cls):
        return Column(
            TIMESTAMP,
            nullable=False,
            onupdate=func.now(),
            server_default=func.now(),
            server_onupdate=func.now(),
        )


class FakeDeleteMixin(object):
    @declared_attr
    def deleted_at(cls):
        return Column(
            TIMESTAMP,
            nullable=True,
        )


class MysqlModelProxy(object):
    def __init__(self, session, model):
        self._session = session
        self._model = model

    @property
    def model(self):
        return self._model

    @property
    def session(self):
        return self._session

    def query(self, *args, **kwargs):
        return self.session.query(self.model, *args, **kwargs)

    def update_one(self, query, update, upsert=False):
        return self.model.update_one(self.session, query, update, upsert)

    def update_many(self, query, update):
        return self.model.update_many(self.session, query, update)

    def find_one_and_update(self, query, update, upsert=False):
        return self.model.find_one_and_update(
            self.session, query, update, upsert)

    def find_one(self, query):
        return self.session.query(self.model).filter_by(**query).first()

    def insert_one(self, info):
        return self.model.insert_one(self.session, info)

    def insert_many(self, info):
        return self.model.insert_many(self.session, info)

    def __getattr__(self, name):
        return getattr(self.model, name)


for i in glob.glob(os.path.join(os.path.dirname(__file__), "*.py")):
    i = os.path.basename(i)[0:-3]
    if i.startswith('_'):
        continue
    __import__("{}.{}".format(__name__, i))
