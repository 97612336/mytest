# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT
)
from .models import Models


class FocusCar(Base, TimestampMixin):
	__tablename__ = 'focus_car'
	id = Column(Integer, primary_key=True, nullable=False)
	car_id = Column(Integer, nullable=False)
	saler_id = Column(Integer, nullable=False)
	user_id = Column(Integer, nullable=False)
	is_test = Column(Integer)

Models.reg('focus_car', FocusCar)