# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT

)
from .models import Models


class BillColumns(Base):
	__tablename__ = 'bill_columns'
	id = Column(Integer, primary_key=True, nullable=False)
	name = Column(String(32))
	ename = Column(String(32))


Models.reg('bill_columns', BillColumns)