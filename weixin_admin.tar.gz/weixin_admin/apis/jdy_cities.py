# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT
)
from .models import Models


class JdyCities(Base):
	__tablename__ = 'jdy_cities'
	id = Column(Integer, primary_key=True, nullable=False)
	province = Column(Integer)
	city = Column(String(32))
	c_pinyin = Column(String(64))
	p_pinyin = Column(String(32))


Models.reg('jdy_cities', JdyCities)