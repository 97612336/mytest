# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT
)
from .models import Models


class Parts_bill(Base, TimestampMixin):
	__tablename__ = 'parts_bill'
	id = Column(Integer, primary_key=True, nullable=False)
	category_id = Column(Integer)
	bill_id = Column(Integer)


Models.reg('parts_bill', Parts_bill)
