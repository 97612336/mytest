# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT
)
from .models import Models


class CarColor(Base):
	__tablename__ = 'car_color'
	id = Column(Integer, primary_key=True, nullable=False)
	name = Column(String(32))
	ename = Column(String(16))
	car_id = Column(Integer)
	color = Column(String(16))


Models.reg('car_color', CarColor)
