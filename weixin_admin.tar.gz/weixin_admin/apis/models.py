# coding=utf-8

from __future__ import absolute_import, print_function
import os
import logging
from . import Base, MysqlModelProxy


class Models(object):
    __models = {}

    def __init__(self, session):
        self._Session = session

    def get_model(self, name):
        return self.__models[name]

    @classmethod
    def reg(cls, name, clazz):
        if name in cls.__models:
            raise AttributeError(
                "Models already has model %r [%r] [%r]." % (
                    name, cls.__models[name], clazz))
        if not issubclass(clazz, Base):
            raise AttributeError("Models should only support Base model.")
        cls.__models[name] = clazz

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(
                "Models has no model %r. To access the %s"
                " model, use models[%r]." % (name, name, name))
        return self.__getitem__(name)

    def __getitem__(self, name):
        if name in Models.__models:
            cls = Models.__models[name]
            return MysqlModelProxy(self._Session(), cls)
        filename = os.path.join(
            os.path.dirname(__file__), "{}.py".format(name))
        if os.path.isfile(filename):
            raise AttributeError(
                "Models has no model %r."
                "Do you means %r, dot forgot import it" % (name, filename))
            return

        raise AttributeError("Models has no model %r." % name)
