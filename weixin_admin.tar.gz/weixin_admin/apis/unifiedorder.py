# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT
)
from .models import Models
from sqlalchemy import DECIMAL


class Unifiedorder(Base, TimestampMixin):
	__tablename__ = 'unifiedorder'
	id = Column(Integer, primary_key=True, nullable=False)
	prepay_id = Column(String(64))
	bill_id = Column(Integer)
	saler_id = Column(Integer)
	device_info = Column(String(32))
	trade_type = Column(String(16))
	total_fee = Column(Integer)
	fee_type = Column(String(16), default='CNY')
	time_start = Column(String(14))
	time_expire = Column(String(14))
	out_trade_no = Column(String(32), unique=True)
	product_id = Column(String(32))
	code_url = Column(String(64))
	transaction_id = Column(String(32))
	openid = Column(String(128))
	bank_type = Column(String(16))
	time_end = Column(String(14))
	pay_type = Column(Integer, default=0)
	remark = Column(String(128))


Models.reg('unifiedorder', Unifiedorder)