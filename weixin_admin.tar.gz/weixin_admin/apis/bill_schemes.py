# coding=utf-8

from __future__ import absolute_import, print_function
from sqlalchemy import DECIMAL
from . import (
    Base,
    Column,
    Integer,
    String,
    TimestampMixin,
    text,
    TIMESTAMP,
    BIGINT,
    DateTime
)
from .models import Models


class BillSchemes(Base, TimestampMixin):
    __tablename__ = 'bill_schemes'

    id = Column(Integer, primary_key=True, nullable=False)
    bill_id = Column(Integer, nullable=False)
    scheme_id = Column(Integer, nullable=False)


Models.reg('bill_schemes', BillSchemes)
