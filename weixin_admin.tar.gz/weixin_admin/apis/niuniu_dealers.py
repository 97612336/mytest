# coding=utf-8

from __future__ import absolute_import, print_function
from . import (
	Base,
	Column,
	Integer,
	String,
	TimestampMixin,
	text,
	TIMESTAMP,
	BIGINT
)
from .models import Models


class NiuNiuDealers(Base):
	__tablename__ = 'niuniu_dealers'
	id = Column(Integer, primary_key=True, nullable=False)
	company = Column(String(64))
	address = Column(String(128))
	phone = Column(String(32))
	phones = Column(String(125))
	main_brand = Column(String(32))
	area = Column(String(64))
	brand = Column(String(128))
	manager_mobile = Column(String(16))
	manager_name = Column(String(16))


Models.reg('niuniu_dealers', NiuNiuDealers)
