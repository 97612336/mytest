# coding=utf-8

from __future__ import absolute_import, print_function
from collections import namedtuple
import tornado
import tornado.websocket
from tornado.escape import json_decode, json_encode
from tornado.web import urlparse
from tornado import escape
from json import dumps
import datetime
import time
import logging
import os
import sys
import json
import verifycode
import copy
from collections import defaultdict
from session import SessionBaseHandler
import logging
from tornado.httputil import url_concat
import re
from apis import Base
from decimal import Decimal
import pymysql.cursors
import configparser
from tornado.httpclient import (AsyncHTTPClient, HTTPRequest)
from tornado.escape import json_decode
import datetime
from tornado.gen import coroutine
import string
import random
import hashlib
import xml.etree.ElementTree as ET


def default(obj):
	if isinstance(obj, Base):
		exclude = ['password']
		return {k: v for k, v in obj.to_dict().items() if v is not None and
				k not in exclude}
	elif isinstance(obj, Decimal):
		return str(obj)
	elif isinstance(obj, datetime.datetime):
		return obj.isoformat()
	elif isinstance(obj, datetime.date):
		return obj.isoformat()
	return json_encode(obj)


class BaseHandler(SessionBaseHandler):
	def prepare(self):
		if self.request.body and self.request.headers["Content-Type"].\
				startswith("application/json"):
			try:
				info = json_decode(self.request.body.decode('utf-8'))
				self.json_args = info
				json_info = {k: [str(v).replace("\'", '\"')] for k, v in info.items()}
				self.request.arguments.update(json_info)
			except BaseException:
				pass

		if self.is_ajax_request:
			self.redirect = self.fake_redirect

	def check_xsrf_cookie(self):
		if self.is_ajax_request:
			return
		super(BaseHandler, self).check_xsrf_cookie()

	def get_wx_pay_nonce_str(self):
		seed = "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
		nonce_list = []
		for i in range(32):
			nonce_list.append(random.choice(seed))
		nonce_str = ''.join(nonce_list)
		return nonce_str

	def get_wx_pay_sign(self, params):
		tem_list = []
		for key, value in params.items():
			tem_list.append('{}={}'.format(key, value))
		tem_list.sort()
		stringA = '&'.join(tem_list)
		ApiKey = os.getenv('CheXiaoYiMchKey', '')
		stringSignTemp = stringA + "&key={}".format(ApiKey)
		sign = hashlib.md5(stringSignTemp.encode('utf-8')).hexdigest().upper()
		return sign

	def gen_token(self, size=12, chars=string.ascii_letters + string.digits):
		return ''.join(random.choice(chars) for _ in range(size))

	def ukey(self, saler_id):
		return "saler:{}".format(saler_id)

	def skey(self, saler_id):
		return 'session:{}'.format(saler_id)

	def update_user_token(self, uid, token):
		key = self.ukey(uid)
		r = self.redis
		r.hset(key, 'token', token)

	@property
	def is_ajax_request(self):
		if not hasattr(self, '_is_ajax_request'):
			accepts = self.request.headers.get('Accept', '')
			self._is_ajax_request = accepts.find('application/json') == 0
		return self._is_ajax_request

	@property
	def db(self):
		return self.application.db

	@property
	def IP(self):
		return self.application.IP

	@property
	def DB(self):
		return self.application._Session

	def model(self, name):
		return self.db.get_model(name)

	def on_finish(self):
		super(BaseHandler, self).on_finish()
		self.DB.remove()

	@property
	def redis(self):
		return self.application._redis

	def write_error(self, status_code, **kwargs):
		super(BaseHandler, self).write_error(status_code, **kwargs)

	def xmlToDict(self, xml):
		"""将xml转为array"""
		dict_data = dict()
		root = ET.fromstring(xml)
		for child in root:
			value = child.text
			dict_data[child.tag] = value
		return dict_data

	def get_afsaas_connection(self):
		home = os.environ['HOME']
		inifile = '{}/.afsaas.cnf'.format(home)
		config = configparser.ConfigParser()
		config.read(inifile)
		user = config.get('client', 'user')
		password = config.get('client', 'password')
		host = config.get('client', 'host')
		config = {
			'host': host,
			'port': 3306,
			'user': user,
			'password': password,
			'db': 'afsaas',
			'charset': 'utf8mb4',
			'cursorclass': pymysql.cursors.DictCursor,
		}
		connection = pymysql.connect(**config)
		return connection

	def strip_nbsp(self, str):
		str_list = str.split('&nbsp;')
		result = ''
		for item in str_list:
			result += item
		return result

	def session_update_saler(self, info):
		saler_id = self.saler_id
		if not isinstance(info, dict):
			info = info.to_dict()
		info = {k: v for k, v in info.items() if v is not None}
		key = self.skey(saler_id)
		r = self.redis
		r.hmset(key, info)
		self.session = info

	def login_session_update(self, saler_id, info):
		if not isinstance(info, dict):
			info = info.to_dict()
		info = {k: v for k, v in info.items() if v is not None}
		key = self.skey(saler_id)
		r = self.redis
		r.hmset(key, info)
		self.session = info

	def session_saler_info(self, k, defv):
		key = self.skey(self.saler_id)
		r = self.redis
		value = r.hget(key, k)
		if not value:
			return defv
		return value

	@property
	def saler_id(self):
		if not hasattr(self, '_salerid'):
			try:
				saler_id = self.get_argument_int('Cyx_saler')
			except Exception as e:
				self.not_login()
				return 0
			self._salerid = saler_id
		return self._salerid

	@property
	def token(self):
		if not hasattr(self, '_token'):
			token = self.get_argument('Cyx_token', '')
			self._token = token
		return self._token

	def not_login(self):
		self.render_json({'code': 403, 'msg': '您还没登录'})
		self.finish()

	def int(self, v):
		if isinstance(v, int):
			return v
		if isinstance(v, float):
			return int(v)
		s = '0{}'.format(v)
		try:
			return int(s)
		except BaseException:
			return 0

	def get_argument_int(self, key, defval=0):

		return self.int(self.get_argument(key, defval))

	def toyears(self, d):
		try:
			if isinstance(d, datetime.datetime):
				return datetime.datetime.today().year - d.year
			elif isinstance(d, datetime.date):
				return datetime.datetime.today().year - d.year
			elif isinstance(d, str):
				year = int('0{}'.format(d.split('-')[0]))
				if year < 1990:
					return year
				return datetime.datetime.today().year - year
		except BaseException:
			pass
		return 0

	def today(self, fmt='%Y-%m-%d'):
		return datetime.date.today().strftime(fmt)

	def fmt(self, d, fmt='%Y-%m-%d'):
		if d is None:
			return ''
		try:
			return d.strftime(fmt)
		except Exception as e:
			logging.debug("fmt(%s) d %s fail %s", fmt, d, e)
		return ''

	def week_begin_end(self, d):
		d = d.replace(hour=0, minute=0, second=0, microsecond=0)
		w = d.isoweekday()
		if w > 0:
			w = w - 1
		elif w == 6:
			w = -1
		else:
			w = 0
		d = d - datetime.timedelta(days=w)
		seq = 1
		while True:
			e = d - datetime.timedelta(days=7 * seq)
			if e.month != d.month:
				break
			seq += 1
		e = d + datetime.timedelta(days=7)
		return (d, e, seq)

	def fmtweek(self, d):
		if d is None:
			d = datetime.datetime.today()
		wbe = self.week_begin_end(d)
		d = wbe[0]
		seq = wbe[2]
		return '{}月第{}周'.format(d.month, seq)

	def toweekday(self, d):
		days = '一二三四五六日'
		w = d.weekday()
		return days[w]

	def todayweekday(self):
		return self.toweekday(datetime.date.today())

	def getUser(self, uid):
		try:
			u = self.db.users.find_one({'id': int(uid)})
			if u:
				u['username'] = u.userinfo.username
				u['sex'] = u.userinfo.sex
				u['address'] = u.userinfo.address
			return u
		except Exception as e:
			logging.debug("get user fail %s", e)
		return None

	def color(self, c, factory_id):
		CarColor = self.model('car_color')
		session = self.DB()
		name = session.query(CarColor.name).\
			filter(CarColor.factory_id == factory_id).\
			filter(CarColor.ename == c).\
			first()
		if name:
			return name[0]
		return ''

	def scene(self, c, factory_id):
		Scenes = self.model('scenes')
		session = self.DB()
		name = session.query(Scenes.name).\
			filter(Scenes.factory_id == factory_id).\
			filter(Scenes.ename == c).\
			first()
		if name:
			return name[0]
		return ''

	@coroutine
	def get_access_token(self):
		appid = os.getenv('CheXiaoYiAppID', '')
		secret = os.getenv('CheXiaoYiAppSecret')
		redis = self.redis
		access_token_key = 'Chexiaoyi:access_token'
		url_access_token = 'https://api.weixin.qq.com/cgi-bin/token?' \
						   'grant_type=client_credential&appid={}' \
						   '&secret={}'.format(appid, secret)
		request = HTTPRequest(
			url=url_access_token,
			method='GET',
			connect_timeout=60,
			request_timeout=60,
		)
		client = AsyncHTTPClient()
		response = yield client.fetch(request)
		if response.error:
			logging.debug('access_token response.error:%s',
						  response.error)
			return
		else:
			body = json_decode(response.body)
			logging.debug('body:%s', body)
			access_token = body.get('access_token', '')
			self.redis.setex(access_token_key, 5400, access_token)
		return access_token

	def getCar(self, carid):
		if not carid:
			return None
		query = {'id': carid}
		car = self.db.spec.find_one(query)
		if not car:
			return None

		try:
			config = json.loads(car.config)
			for k, v in config.items():
				car[k] = v
		except BaseException:
			pass
		return car

	def ispage(self, expect_path, case_true, case_false):
		if self.request.path == expect_path:
			return case_true
		return case_false

	def static_url(self, path, *args, **kwargs):
		path = path.strip()
		return super(BaseHandler, self).static_url(path, *args, **kwargs)

	def fake_redirect(self, url, permanent=False, status=None):
		if self._headers_written:
			raise Exception("Cannot redirect after headers have been written")
		if status:
			self.set_status(status)
		url = escape.utf8(url)
		self.set_header("next_url", url)
		query = urlparse.urlsplit(url).query or ''
		args = urlparse.parse_qs(query)
		kwargs = {}
		for k, v in args.items():
			kwargs[escape.native_str(k)] = escape.native_str(v[0])
		self.render_json(kwargs)

	def render(self, *args, **kwargs):
		if self.is_ajax_request:
			self.render_json(kwargs)
			return
		super(BaseHandler, self).render(*args, **kwargs)

	def render_json(self, res):
		self.set_header("Content-Type", "application/json; charset=utf-8")
		self.write(dumps(res, default=default))

	def render_xml(self, *args, **kwargs):
		self.set_header('Content-Type', 'text/xml; charset="utf-8"')
		super(BaseHandler, self).render(*args, **kwargs)

	def query_replace(self, qs):
		q = '&' + self.request.query
		for k in qs.keys():
			q = re.sub(r'&{}=[^&]*'.format(k), '', q)
		path = url_concat('?', qs)[1:]
		q = path + '&' + q
		q = re.sub(r'&{2,}', '&', q)
		return q.strip('&')

	def hset_ex(self, r, key, field, value, ttl):
		if r is None:
			r = self.redis
		v = [int(datetime.datetime.now().timestamp()) + ttl, value]
		return r.hset(key, field, dumps(v, default=default))

	def hget_ex(self, r, key, field):
		ex_res = namedtuple("hget_ex", ["value", "ttl", "expires_at"])
		if r is None:
			r = self.redis
		res = r.hget(key, field)
		if res is None:
			return ex_res(None, -1, -1)

		try:
			v = json.loads(res)
			expires_at = int(v[0])
			ttl = expires_at - int(datetime.datetime.now().timestamp())
			if ttl < 0:
				r.hdel(key, field)
			return ex_res(v[1], ttl, expires_at)
		except Exception as e:
			logging.debug("hget_ex parse fail %s", e)
		return ex_res(None, -1, -1)


class LogoutHandler(BaseHandler):
	def get(self):
		keys = []
		for k in self.session.keys():
			if k[0] != '_':
				keys.append(k)
		for k in keys:
			self.session.delete(k)
		to = self.get_argument('to', '/')
		if len(to) < 1:
			self.redirect('/')
			return
		try:
			to = self.reverse_url(to)
			self.redirect(to)
		except BaseException:
			pass
		self.redirect(to)


class XSRFHandler(BaseHandler):
	def get(self):
		self.write(self.xsrf_token)


class VerifyHandler(BaseHandler):
	def get(self):
		mstream, strs = verifycode.generate_verify_image(save_img=False)
		self.session['verify'] = strs
		self.set_header('Content-Type', 'image/png')
		self.write(mstream.getvalue())


class FileuploadHandler(BaseHandler):
	ALLOWED_EXTENSIONS = set(['.pdf', '.png', '.jpg', '.jpeg', '.gif'])
	filenameprefix = ''

	def check_xsrf_cookie(self):
		pass

	def post(self):
		static_path = self.settings.get('static_path', '')
		if len(static_path) < 1:
			self.set_status(504)
			return

		upload_path = self.settings.get('upload_path', '')
		if len(upload_path) < 1:
			self.set_status(504)
			return

		prefix = ''
		if hasattr(self, 'upload_path'):
			prefix = self.upload_path

		yearstr = datetime.date.today().strftime("%Y")
		datestr = datetime.date.today().strftime("%m-%d")
		fullprefix = os.path.join(upload_path, prefix, yearstr, datestr)
		filepath = os.path.join(static_path, fullprefix)
		if not os.path.exists(filepath):
			os.makedirs(filepath)

		res = []
		files = self.request.files['file']
		for meta in files:
			fullname = os.path.basename(meta['filename'])
			fname, fext = os.path.splitext(fullname)
			fext = fext.strip().lower()
			if fext not in self.ALLOWED_EXTENSIONS:
				continue

			timestr = str(time.time())

			filename = self.filenameprefix + timestr + fext
			fullname = os.path.join(filepath, filename)
			showname = os.path.join(fullprefix, filename)
			with open(fullname, 'wb') as up:
				up.write(meta['body'])
			res.append({
				'file': showname,
				'caption': self.static_url(showname),
				'width': '120px',
			})
		self.render_json({'initialPreviewConfig': res})


class BaseWebSocketHandler(tornado.websocket.WebSocketHandler, BaseHandler):
	pass
