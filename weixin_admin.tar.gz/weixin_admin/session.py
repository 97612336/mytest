# -*- coding: utf-8 -*-
#
# Copyright @ 2017 Dejian Xu

from __future__ import (absolute_import, division, print_function,
                        with_statement)

import tornado.web
import torndsession.session
import torndsession.redissession


class RedisSession(torndsession.redissession.RedisSession):
    def save(self, session_id, session_data, expires=None):
        if not session_data:
            self.clear(session_id)
            return
        if len(session_data) == 1 and '__expires__' in session_data:
            self.clear(session_id)
            return
        super(RedisSession, self).save(session_id, session_data, expires)


class SessionManager(torndsession.session.SessionManager):
    pass


class SessionBaseHandler(tornado.web.RequestHandler):
    @property
    def session_back(self):
        if not hasattr(self, '__session_manager'):
            setattr(self, '__session_manager', SessionManager(self))
        return getattr(self, '__session_manager')

    def on_finish(self):
        if hasattr(self, '__session_manager'):
            getattr(self, '__session_manager').flush()
