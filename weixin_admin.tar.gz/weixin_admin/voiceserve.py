#!/usr/bin/env python
# coding=utf-8

from __future__ import absolute_import, print_function
import udpserver
import struct
import collections
from tornado.ioloop import PeriodicCallback

frameSize = 160


def mix(a, b):
    maxval = 0x7fff
    newval = a + b

    if newval > maxval:
        newval = maxval
    elif newval < -maxval:
        newval = -maxval
    return newval


def handle_user(myid, my, voices):
    voice = [0] * frameSize
    count = 0
    for uid, v in voices.items():
        if uid is myid:
            pass
        count += 1
        for i in range(frameSize):
            voice[i] = mix(voice[i], v[i])
    if count < 1:
        return
    my.push_voice(voice)


def handle_room(roomid, room):
    rlen = len(room)
    if rlen < 1:
        return
    voices = {}
    for uid, user in room.items():
        if len(user.voice) > 0:
            voices[uid] = user.voice.popleft()
    for uid, user in room.items():
        handle_user(uid, user, voices)


class VoiceServe(udpserver.UDPServer):
    def __init__(self, handler_class, io_loop=None):
        self.room = {}
        pcb = PeriodicCallback(self.push_voice, 25)
        pcb.start()
        self.pcb = pcb
        udpserver.UDPServer.__init__(self, handler_class, io_loop)

    def push_voice(self):
        handle_room('0', self.room)


baseid = 1
addresses = {}


class VoiceHandler(udpserver.UDPRequest):
    def initialize(self):
        global baseid
        self.id = baseid
        self.room = '0'
        baseid = baseid + 1
        self.voice = collections.deque(maxlen=100)

    def handle(self, data, address):
        global addresses
        if address not in addresses:
            addresses[address] = self
            print("new user", address)
        self.address = address
        self.server.room[self.id] = self
        voice = struct.unpack('<%dh' % frameSize, data)
        self.voice.append(voice)

    def push_voice(self, data):
        voice = struct.pack('<%dh' % frameSize, *data)
        try:
            self.sock.sendto(voice, self.address)
        except BaseException:
            pass

    def __del__(self):
        global addresses
        del addresses[self.address]
