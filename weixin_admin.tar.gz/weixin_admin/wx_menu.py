# coding: utf-8
import urllib
from tornado.httpclient import HTTPRequest
from tornado.httputil import urlencode
from urllib.request import urlopen
import logging
import os
from app import redis
from tornado.httpclient import (HTTPRequest, HTTPClient)
from tornado.escape import json_decode


class Menu(object):
    def __init__(self):
        pass

    def create(self):
        appid = os.getenv('CheXiaoYiAppID', '')
        secret = os.getenv('CheXiaoYiAppSecret')
        bill_redirect_url = 'https://cheyixiao.autoforce.net/v1/wx/bill'
        dealer_redirect_url = 'https://cheyixiao.autoforce.net/v1/wx/dealers/home'
        postJson = """
{
	"button":
	[
		{
			"name": "商户进入",
			"sub_button":
			[
				{
					"type": "click",
					"name": "车源服务",
					"key": "car_source"
				},
				{
					"type": "click",
					"name": "申请使用及续费",
					"key": "try_and_buy"
				},
				{
					"type": "view",
					"name": "全国4S店名录",
					"url": "https://open.weixin.qq.com/connect/oauth2/authorize?appid=%s&redirect_uri=%s&response_type=code&scope=snsapi_base&state=STATE#wechat_redirect"
				},
				{
					"type": "click",
					"name": "客服中心",
					"key": "customer_service"
				}
			]
		},
		{
			"name": "客户进入",
			"sub_button":
			[
				{
					"type": "view",
					"name": "    我的订单       ",
					"url": "https://open.weixin.qq.com/connect/oauth2/authorize?appid=%s&redirect_uri=%s&response_type=code&scope=snsapi_base&state=STATE#wechat_redirect"
				}
			]
		}
	]
}
					""" % (appid, dealer_redirect_url, appid, bill_redirect_url)
        access_token_key = 'Chexiaoyi:access_token'
        access_token = redis.get(access_token_key)
        if access_token:
            pass
        else:
            url_access_token = 'https://api.weixin.qq.com/cgi-bin/token?' \
                               'grant_type=client_credential&appid={}' \
                               '&secret={}'.format(appid, secret)
            request = HTTPRequest(
                url=url_access_token,
                method='GET',
                connect_timeout=60,
                request_timeout=60,
            )
            client = HTTPClient()
            response = client.fetch(request)
            if response.error:
                logging.debug('access_token response.error:', response.error)
            else:
                body = json_decode(response.body)
                access_token = body.get('access_token', '')
                redis.setex(access_token_key, 5400, access_token)
        postUrl = "https://api.weixin.qq.com/cgi-bin/menu/create?" \
                  "access_token=%s" % access_token
        urlresp = urlopen(postUrl, postJson.encode('utf-8'))
        print(urlresp.read())
