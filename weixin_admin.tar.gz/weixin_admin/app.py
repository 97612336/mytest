# coding=utf-8

from __future__ import absolute_import, print_function
import sys
from tornado.web import url

import tornado.web
from tornado.gen import coroutine
import tornado.ioloop
import os
import logging
import redis
import basehandler
from session import RedisSession
from apis.models import Models
import importlib

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm import scoped_session
from ipip.ipip import IPX

sys.path.append(os.path.abspath(os.path.join(
    os.path.dirname(__file__), "libs", "taobao")))


_initialize_hooks = set()


def on_appinit(func):
    global _initialize_hooks
    _initialize_hooks.add(func)
    return func


def loadhandlers(handlers, settings, dirname):
    for root, dirs, files in os.walk(dirname):
        if '__init__.py' not in files:
            continue
        for name in files:
            name, ext = os.path.splitext(name)
            if name.startswith('_'):
                continue
            if name == 'basehandler':
                continue
            if ext != '.py':
                continue
            pname = "{}.{}".format(root.replace(os.sep, '.'), name)
            mod = importlib.import_module(pname)
            __handlers = getattr(mod, "__handlers", None)
            if callable(__handlers):
                for h in __handlers(settings):
                    handlers.append(h)
    return handlers


redis = redis.StrictRedis(
    host=os.getenv('REDIS_HOST', 'localhost'),
    port=os.getenv('REDIS_PORT', 6379),
    db=os.getenv('REDIS_DB', 0),
    decode_responses=True)

default_mysql_uri = "mysql+pymysql:///cheyixiao?" + \
        "read_default_file=~/.afsaas.cnf&charset=utf8mb4"
engine = create_engine(
    os.getenv('MYSQL_URI', default_mysql_uri),
    pool_recycle=3600,
    echo=os.getenv('ECHO_SQL', False),
)
Session = scoped_session(
    sessionmaker(bind=engine, autoflush=False))
db = Models(Session)


class Application(tornado.web.Application):
    def __init__(self, **settings):

        self._redis = redis
        self._engine = engine
        self._Session = Session
        self.db = db
        self.IP = IPX
        session_settings = settings.get('session', {})
        if session_settings.get('driver', None) == 'redis':
            driver_settings = session_settings.get("driver_settings", {})
            if driver_settings:
                self.__cached_session_driver = RedisSession(**driver_settings)

        handlers = [
            (r'/verify', basehandler.VerifyHandler),
            (r'/xsrf', basehandler.XSRFHandler),
            url(r'/upload', basehandler.FileuploadHandler, name="fileupload"),
            url(r'/logout', basehandler.LogoutHandler, name="logout"),
            ]

        handlers = loadhandlers(handlers, settings, 'handler')

        tornado.web.Application.__init__(self, handlers, **settings)
        tornado.ioloop.IOLoop.current().spawn_callback(self.some_init_async)

    @coroutine
    def some_init_async(self):
        self.IP.load('ipip/17monipdb.datx')

    @property
    def redis(self):
        return self._redis

    def initialize(self):
        for cb in _initialize_hooks:
            cb(self)
