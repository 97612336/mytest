#!/usr/bin/python
# coding=utf-8

from __future__ import absolute_import, print_function
import sys
import tornado.ioloop
import tornado.httpserver
import signal
import time
import os
import logging
from tornado.options import options
import importlib
from app import Application
from wx_menu import Menu


MAX_WAIT_SECONDS_BEFORE_SHUTDOWN = 3


def sig_handler(sig, frame):
	logging.warning('Caught signal: %s', sig)
	tornado.ioloop.IOLoop.current().add_callback_from_signal(shutdown)


def shutdown():
	logging.info('Stopping http server')
	server.stop()

	logging.info('shutdown in %ss', MAX_WAIT_SECONDS_BEFORE_SHUTDOWN)
	io_loop = tornado.ioloop.IOLoop.current()

	io_loop.stop()
	logging.info('Shutdown')


def run_cmd(app, cmd):
	i = sys.argv.index('--cmd=' + cmd)
	argv = sys.argv[i+1:]
	logging.info('import module cmd.%s', cmd)
	handle = importlib.import_module('cmd.'+cmd)
	logging.info('run cmd.%s.main', cmd)
	handle.main(app, *argv)
	logging.info('cmd done')


def main(settings):
	global server

	app = Application(**settings)

	if len(options.cmd) > 0:
		run_cmd(app, options.cmd)
		return

	app.initialize()
	server = tornado.httpserver.HTTPServer(app, xheaders=True)
	server.listen(options.port)

	if options.prod:
		signal.signal(signal.SIGTERM, sig_handler)
		signal.signal(signal.SIGINT, sig_handler)
	logging.info('listening on %d' % options.port)
	tornado.ioloop.IOLoop.current().start()

if __name__ == "__main__":
	myMenu = Menu()
	try:
		myMenu.create()
	except Exception as e:
		print('error:', e)
	from settings import settings
	main(settings)

